package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.MoodType
import com.example.ui.AuraTab
import com.example.ui.AuraViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Aura", appName)
  }

  @Test
  fun `verify AuraViewModel moments and streak check in`() {
    val viewModel = AuraViewModel()
    assertEquals(AuraTab.FEED, viewModel.uiState.value.currentTab)
    assertFalse(viewModel.uiState.value.hasCheckedInToday)

    viewModel.checkInDaily()
    assertTrue(viewModel.uiState.value.hasCheckedInToday)
    assertEquals(2, viewModel.uiState.value.creationStreakDays)

    val firstMoment = viewModel.uiState.value.moments.first()
    val initialFeels = firstMoment.feelCount
    viewModel.toggleFeelMoment(firstMoment.id)
    assertEquals(initialFeels + 1, viewModel.uiState.value.moments.first().feelCount)
  }

  @Test
  fun `verify following system and reels system`() {
    val viewModel = AuraViewModel()
    
    // Verify following system
    val raySoul = viewModel.uiState.value.souls.first { it.name == "Ray" }
    assertFalse(raySoul.isFollowing)
    val initialFollowers = raySoul.followersCount

    viewModel.toggleFollowAuthor("Ray")
    val updatedRay = viewModel.uiState.value.souls.first { it.name == "Ray" }
    assertTrue(updatedRay.isFollowing)
    assertEquals(initialFollowers + 1, updatedRay.followersCount)

    // Verify reels system
    assertFalse(viewModel.uiState.value.reels.isEmpty())
    val firstReel = viewModel.uiState.value.reels.first()
    val initialReelFeels = firstReel.feelCount
    viewModel.toggleFeelReel(firstReel.id)
    assertEquals(initialReelFeels + 1, viewModel.uiState.value.reels.first().feelCount)

    // Verify creating new reel
    val initialCount = viewModel.uiState.value.reels.size
    viewModel.createReel(
      caption = "Midnight contemplation",
      audioTrack = "Lofi Rain",
      mood = MoodType.MIDNIGHT,
      visualRes = R.drawable.reel_midnight_fog
    )
    assertEquals(initialCount + 1, viewModel.uiState.value.reels.size)
    assertEquals(AuraTab.REELS, viewModel.uiState.value.currentTab)
  }

  @Test
  fun `verify calls, voice notes, search, and moment upload`() {
    val viewModel = AuraViewModel()

    // Test Search
    assertFalse(viewModel.uiState.value.isSearchOpen)
    viewModel.openSearch()
    assertTrue(viewModel.uiState.value.isSearchOpen)
    viewModel.closeSearch()
    assertFalse(viewModel.uiState.value.isSearchOpen)

    // Test Video & Voice Call
    viewModel.startCall(
      soulName = "Zainab",
      soulHandle = "@zainab",
      soulInitial = "Z",
      type = com.example.model.CallType.VIDEO
    )
    val call = viewModel.uiState.value.activeCall
    assertTrue(call != null)
    assertEquals("Zainab", call?.soulName)
    assertEquals(com.example.model.CallType.VIDEO, call?.type)
    viewModel.endCall()
    assertEquals(null, viewModel.uiState.value.activeCall)

    // Test Voice Note in Chat
    val firstThread = viewModel.uiState.value.threads.first()
    val initialMessagesCount = firstThread.messages.size
    viewModel.sendVoiceNote(firstThread.id, durationSec = 12)
    val updatedThread = viewModel.uiState.value.threads.first { it.id == firstThread.id }
    assertEquals(initialMessagesCount + 1, updatedThread.messages.size)
    assertTrue(updatedThread.messages.last().isVoiceNote)
    assertEquals(12, updatedThread.messages.last().voiceDurationSec)

    // Test Moment Creation with Media & Voice Note
    val initialMoments = viewModel.uiState.value.moments.size
    viewModel.createMoment(
      text = "Watching nocturnal rain",
      mood = MoodType.RAINY,
      mediaUri = "content://media/external/images/1",
      mediaType = "photo",
      isVoiceNote = true,
      voiceDurationSec = 8
    )
    assertEquals(initialMoments + 1, viewModel.uiState.value.moments.size)
    val created = viewModel.uiState.value.moments.first()
    assertTrue(created.isVoiceNote)
    assertEquals("photo", created.mediaType)
    assertEquals("content://media/external/images/1", created.mediaUri)
  }

  @Test
  fun `verify app opening animation and compose poetry screen`() {
    val viewModel = AuraViewModel()

    // Verify Opening Animation State & Dismissal
    assertTrue(viewModel.uiState.value.isOpeningAnimationVisible)
    viewModel.dismissOpeningAnimation()
    assertFalse(viewModel.uiState.value.isOpeningAnimationVisible)
    viewModel.replayOpeningAnimation()
    assertTrue(viewModel.uiState.value.isOpeningAnimationVisible)
    viewModel.dismissOpeningAnimation()

    // Verify Compose Poetry Open/Close
    assertFalse(viewModel.uiState.value.isComposePoetryOpen)
    viewModel.openComposePoetry()
    assertTrue(viewModel.uiState.value.isComposePoetryOpen)
    viewModel.closeComposePoetry()
    assertFalse(viewModel.uiState.value.isComposePoetryOpen)

    // Verify Publishing a Poem
    val initialMoments = viewModel.uiState.value.moments.size
    viewModel.publishPoem(
      title = "Quiet Midnight Rain",
      poemText = "Soft drops trace the glass,\nA calm sanctuary of light.",
      mood = MoodType.MIDNIGHT,
      fontOptionName = "PLAYFAIR",
      backdropRes = null
    )

    assertEquals(initialMoments + 1, viewModel.uiState.value.moments.size)
    val publishedPoem = viewModel.uiState.value.moments.first()
    assertTrue(publishedPoem.isPoetry)
    assertEquals("PLAYFAIR", publishedPoem.fontOptionName)
    assertEquals("QUIET MIDNIGHT RAIN", publishedPoem.ambientHeader)
    assertEquals("Poetry Composition", publishedPoem.shareType)
  }

  @Test
  fun `verify sign page, soul registration, and authentication`() {
    val viewModel = AuraViewModel()

    // Test Sign In Dialog Open / Close
    assertFalse(viewModel.uiState.value.isSignInDialogOpen)
    viewModel.openSignInDialog()
    assertTrue(viewModel.uiState.value.isSignInDialogOpen)
    viewModel.closeSignInDialog()
    assertFalse(viewModel.uiState.value.isSignInDialogOpen)

    // Test Custom Soul Sign In / Registration
    viewModel.signIn(
      name = "Zainab Al-Noor",
      handle = "@zainab_celestial",
      email = "zainab@aura.soul",
      archetype = "The Cosmic Dreamer",
      mood = MoodType.SUNSET,
      avatarUri = "content://media/external/images/dp_1"
    )

    val state = viewModel.uiState.value
    assertTrue(state.isSignedIn)
    assertFalse(state.isSignInDialogOpen)
    assertEquals("Zainab Al-Noor", state.userName)
    assertEquals("@zainab_celestial", state.userHandle)
    assertEquals("zainab@aura.soul", state.userEmail)
    assertEquals("The Cosmic Dreamer", state.userPersonalityArchetype)
    assertEquals(MoodType.SUNSET, state.userPrimaryMood)
    assertEquals("content://media/external/images/dp_1", state.userAvatarUri)

    // Test Sign Out
    viewModel.signOut()
    assertFalse(viewModel.uiState.value.isSignedIn)
    assertTrue(viewModel.uiState.value.isSignInDialogOpen)
  }

  @Test
  fun `verify edit profile name pictures and personality details`() {
    val viewModel = AuraViewModel()

    // Test Edit Profile Dialog Open / Close
    assertFalse(viewModel.uiState.value.isEditProfileDialogOpen)
    viewModel.openEditProfileDialog()
    assertTrue(viewModel.uiState.value.isEditProfileDialogOpen)
    viewModel.closeEditProfileDialog()
    assertFalse(viewModel.uiState.value.isEditProfileDialogOpen)

    // Update Profile Name, DP, Bio, and Personality Details
    viewModel.updateProfile(
      name = "Moosa Zahoor",
      handle = "@moosa_poet",
      bio = "Weaving quiet rhymes in the nocturnal rain.",
      avatarUri = "content://media/external/images/my_profile_dp",
      archetype = "The Nocturnal Poet",
      aesthetic = "Midnight rain, warm cinnamon tea & lofi frequencies",
      tags = listOf("Poetry", "Nocturnal Rain", "Lofi Beats", "Solitude"),
      primaryMood = MoodType.RAINY
    )

    val updatedState = viewModel.uiState.value
    assertFalse(updatedState.isEditProfileDialogOpen)
    assertEquals("Moosa Zahoor", updatedState.userName)
    assertEquals("@moosa_poet", updatedState.userHandle)
    assertEquals("Weaving quiet rhymes in the nocturnal rain.", updatedState.userBio)
    assertEquals("content://media/external/images/my_profile_dp", updatedState.userAvatarUri)
    assertEquals("The Nocturnal Poet", updatedState.userPersonalityArchetype)
    assertEquals("Midnight rain, warm cinnamon tea & lofi frequencies", updatedState.userPersonalityAesthetic)
    assertEquals(4, updatedState.userPersonalityTags.size)
    assertTrue(updatedState.userPersonalityTags.contains("Poetry"))
    assertEquals(MoodType.RAINY, updatedState.userPrimaryMood)

    // Test direct avatar update
    viewModel.updateAvatar("content://media/external/images/new_dp")
    assertEquals("content://media/external/images/new_dp", viewModel.uiState.value.userAvatarUri)
  }
}
