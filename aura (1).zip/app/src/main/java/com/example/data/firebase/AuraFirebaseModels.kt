package com.example.data.firebase

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class AuraFirebaseUser(
    @DocumentId val userId: String = "",
    val name: String = "",
    val handle: String = "",
    val email: String = "",
    val bio: String = "",
    val avatarUri: String? = null,
    val personalityArchetype: String = "The Nocturnal Poet",
    val personalityAesthetic: String = "Midnight rain, warm cinnamon tea & lofi frequencies",
    val personalityTags: List<String> = emptyList(),
    val primaryMood: String = "RAINY",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AuraFirebaseMoment(
    @DocumentId val id: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val authorHandle: String = "",
    val text: String = "",
    val mood: String = "RAINY",
    val mediaUri: String? = null,
    val mediaType: String? = null,
    val isVoiceNote: Boolean = false,
    val voiceDurationSec: Int = 0,
    val isPoetry: Boolean = false,
    val fontOptionName: String = "PLAYFAIR",
    val feelCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AuraFirebaseReel(
    @DocumentId val id: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val authorHandle: String = "",
    val caption: String = "",
    val audioTrack: String = "Lofi Rain Frequency",
    val mood: String = "RAINY",
    val feelCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null
)
