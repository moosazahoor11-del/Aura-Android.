package com.example.data.firebase

import android.content.Context
import android.util.Log
import com.example.R
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

private const val TAG = "AuraFirestoreRepo"

class AuraFirestoreRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    // User Profile
    fun observeUser(userId: String): Flow<AuraFirebaseUser?> = callbackFlow {
        if (userId.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }
        val docRef = db.collection("users").document(userId)
        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.w(TAG, "Error observing user profile", error)
                return@addSnapshotListener
            }
            if (snapshot != null && snapshot.exists()) {
                val user = snapshot.toObject(
                    AuraFirebaseUser::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                trySend(user)
            } else {
                trySend(null)
            }
        }
        awaitClose { listener.remove() }
    }

    suspend fun saveUser(user: AuraFirebaseUser) {
        require(user.userId.isNotBlank()) { "userId must not be blank" }
        val docRef = db.collection("users").document(user.userId)
        val snapshot = docRef.get().await()
        if (snapshot.exists()) {
            docRef.set(user.copy(updatedAt = null)).await()
        } else {
            docRef.set(user.copy(createdAt = null, updatedAt = null)).await()
        }
    }

    // Moments
    fun observeMoments(): Flow<List<AuraFirebaseMoment>> = callbackFlow {
        val collection = db.collection("moments")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(50)
        val listener = collection.addSnapshotListener { snapshots, error ->
            if (error != null) {
                Log.w(TAG, "Error observing moments", error)
                return@addSnapshotListener
            }
            if (snapshots != null) {
                val list = snapshots.toObjects(
                    AuraFirebaseMoment::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                trySend(list)
            }
        }
        awaitClose { listener.remove() }
    }

    suspend fun publishMoment(moment: AuraFirebaseMoment) {
        require(moment.id.isNotBlank()) { "Moment id must not be blank" }
        require(moment.authorId.isNotBlank()) { "Moment authorId must not be blank" }
        val docRef = db.collection("moments").document(moment.id)
        docRef.set(moment.copy(createdAt = null)).await()
    }

    suspend fun feelMoment(momentId: String) {
        require(momentId.isNotBlank()) { "Moment id must not be blank" }
        val docRef = db.collection("moments").document(momentId)
        docRef.update("feelCount", FieldValue.increment(1)).await()
    }

    // Motion Reels
    fun observeReels(): Flow<List<AuraFirebaseReel>> = callbackFlow {
        val collection = db.collection("reels")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(30)
        val listener = collection.addSnapshotListener { snapshots, error ->
            if (error != null) {
                Log.w(TAG, "Error observing reels", error)
                return@addSnapshotListener
            }
            if (snapshots != null) {
                val list = snapshots.toObjects(
                    AuraFirebaseReel::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
                trySend(list)
            }
        }
        awaitClose { listener.remove() }
    }

    suspend fun publishReel(reel: AuraFirebaseReel) {
        require(reel.id.isNotBlank()) { "Reel id must not be blank" }
        require(reel.authorId.isNotBlank()) { "Reel authorId must not be blank" }
        val docRef = db.collection("reels").document(reel.id)
        docRef.set(reel.copy(createdAt = null)).await()
    }

    suspend fun feelReel(reelId: String) {
        require(reelId.isNotBlank()) { "Reel id must not be blank" }
        val docRef = db.collection("reels").document(reelId)
        docRef.update("feelCount", FieldValue.increment(1)).await()
    }
}
