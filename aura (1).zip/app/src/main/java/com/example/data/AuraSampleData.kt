package com.example.data

import com.example.R
import com.example.model.AuraSymbol
import com.example.model.BondGardenItem
import com.example.model.BondStreakItem
import com.example.model.ChatMessage
import com.example.model.InboxThread
import com.example.model.Moment
import com.example.model.MoodType
import com.example.model.ReelItem
import com.example.model.SoulProfile
import com.example.model.Story
import com.example.model.ThoughtComment

object AuraSampleData {

    fun initialMoments(): List<Moment> = listOf(
        Moment(
            id = "m_1",
            authorName = "Naira's little universe",
            authorHandle = "@naira",
            authorInitial = "N",
            timeAgo = "12 minutes ago",
            shareType = "shared softly",
            mood = MoodType.RAINY,
            ambientHeader = "A MOMENT IN AMBIENT LIGHT",
            quoteText = "Some days, even the rain feels like a soft place to land.",
            captionText = "A quiet window, warm tea, and nowhere else I need to be right now. ☕",
            feelCount = 24,
            isFelt = false,
            isKept = false,
            isFollowingAuthor = true,
            drawableRes = R.drawable.ambient_rainy_glow,
            thoughts = listOf(
                ThoughtComment(
                    id = "tc_1",
                    author = "Zainab",
                    authorInitial = "Z",
                    text = "This brought me an instant exhale after a frantic workday. 🌧️",
                    timeAgo = "10m ago"
                ),
                ThoughtComment(
                    id = "tc_2",
                    author = "Ray",
                    authorInitial = "R",
                    text = "The cadence of rain on glass is the best rhythm.",
                    timeAgo = "4m ago"
                )
            )
        ),
        Moment(
            id = "m_2",
            authorName = "Ray's afterglow",
            authorHandle = "@ray_art",
            authorInitial = "R",
            timeAgo = "28 minutes ago",
            shareType = "a tiny poem",
            mood = MoodType.SUNSET,
            ambientHeader = "SUNSET GLOW / 18:42",
            quoteText = "Maybe the light returns in small ways first.",
            captionText = "Collecting the tiny good things before the day ends. 🌅",
            feelCount = 17,
            isFelt = false,
            isKept = false,
            isFollowingAuthor = false,
            drawableRes = R.drawable.ambient_sunset_glow,
            thoughts = listOf(
                ThoughtComment(
                    id = "tc_3",
                    author = "Ayan",
                    authorInitial = "A",
                    text = "Small ways are how the deepest changes start.",
                    timeAgo = "15m ago"
                )
            )
        ),
        Moment(
            id = "m_3",
            authorName = "Ayan's nocturnal orbit",
            authorHandle = "@ayan_midnight",
            authorInitial = "A",
            timeAgo = "1 hour ago",
            shareType = "midnight reflection",
            mood = MoodType.MIDNIGHT,
            ambientHeader = "LATE RESONANCE / 00:48",
            quoteText = "In the silence between midnight and morning, thoughts find their honest weight.",
            captionText = "Lo-fi vinyl, blue midnight fog outside, observing the sleeping world.",
            feelCount = 31,
            isFelt = true,
            isKept = true,
            isFollowingAuthor = true,
            drawableRes = null,
            thoughts = listOf(
                ThoughtComment(
                    id = "tc_4",
                    author = "Hira",
                    authorInitial = "H",
                    text = "That exact hour when the universe feels boundless.",
                    timeAgo = "45m ago"
                )
            )
        ),
        Moment(
            id = "m_4",
            authorName = "Elena's botanical sketchbook",
            authorHandle = "@elena_wild",
            authorInitial = "E",
            timeAgo = "2 hours ago",
            shareType = "spring fragment",
            mood = MoodType.BLOOMING,
            ambientHeader = "PETAL DRIFT / 11:15",
            quoteText = "Bloom where you were broken, not just where you were planted.",
            captionText = "Wild jasmine flowering by the stone steps. Little joys everywhere.",
            feelCount = 42,
            isFelt = false,
            isKept = false,
            isFollowingAuthor = false,
            drawableRes = null,
            thoughts = emptyList()
        )
    )

    fun initialReels(): List<ReelItem> = listOf(
        ReelItem(
            id = "reel_1",
            authorName = "Zainab",
            authorHandle = "@zainab_words",
            authorInitial = "Z",
            caption = "Watching nocturnal rain droplets trace neon reflections across the quiet boulevard. Some feelings only belong to 2 AM. 🌧️✨",
            audioTrack = "Rainfall in Shibuya · 432Hz Binaural",
            mood = MoodType.RAINY,
            feelCount = 1420,
            isFelt = false,
            isKept = false,
            isFollowingAuthor = true,
            drawableRes = R.drawable.reel_midnight_fog,
            thoughts = listOf(
                ThoughtComment("rc_1", "Ayan", "A", "This atmosphere is medicine for an overactive mind.", "12m ago"),
                ThoughtComment("rc_2", "Naira", "N", "The sound of rain in the dark heals everything.", "5m ago")
            )
        ),
        ReelItem(
            id = "reel_2",
            authorName = "Ray",
            authorHandle = "@ray_twilight",
            authorInitial = "R",
            caption = "The golden sun melted into the tide and washed away the day's noise. A quiet reminder that endings can be luminous. 🌅",
            audioTrack = "Pacific Golden Hour · Ambient Tape Echo",
            mood = MoodType.SUNSET,
            feelCount = 980,
            isFelt = false,
            isKept = false,
            isFollowingAuthor = false,
            drawableRes = R.drawable.reel_golden_dusk,
            thoughts = listOf(
                ThoughtComment("rc_3", "Hira", "H", "Breathtaking tones on the water!", "1h ago")
            )
        ),
        ReelItem(
            id = "reel_3",
            authorName = "Naira",
            authorHandle = "@naira_universe",
            authorInitial = "N",
            caption = "Muse tea by the rainy window. When the weather forces you to slow down, listen to the whisper. ☕🌧️",
            audioTrack = "Warm Chamomile & Window Rain · Lo-Fi Piano",
            mood = MoodType.RAINY,
            feelCount = 2840,
            isFelt = true,
            isKept = true,
            isFollowingAuthor = true,
            drawableRes = R.drawable.ambient_rainy_glow,
            thoughts = listOf(
                ThoughtComment("rc_4", "Zainab", "Z", "I want to live in this frame.", "30m ago")
            )
        ),
        ReelItem(
            id = "reel_4",
            authorName = "Hira",
            authorHandle = "@hira_glow",
            authorInitial = "H",
            caption = "City skyline breathing under purple twilight. Between day and night, the world takes a quiet pause. 🌇",
            audioTrack = "Evening Reverie · Cinematic Synth",
            mood = MoodType.SUNSET,
            feelCount = 760,
            isFelt = false,
            isKept = false,
            isFollowingAuthor = false,
            drawableRes = R.drawable.ambient_sunset_glow,
            thoughts = emptyList()
        )
    )

    fun initialStories(): List<Story> = listOf(
        Story(
            id = "s_1",
            authorName = "Zainab",
            authorInitial = "Z",
            circleTag = "rainy mood",
            mood = MoodType.RAINY,
            quote = "Raindrops tracing slow trajectories down the train window.",
            timeAgo = "15m ago",
            isViewed = false,
            drawableRes = R.drawable.ambient_rainy_glow
        ),
        Story(
            id = "s_2",
            authorName = "Hira",
            authorInitial = "H",
            circleTag = "golden hour",
            mood = MoodType.SUNSET,
            quote = "The street turned into molten copper for about six minutes.",
            timeAgo = "30m ago",
            isViewed = false,
            drawableRes = R.drawable.ambient_sunset_glow
        ),
        Story(
            id = "s_3",
            authorName = "Ayan",
            authorInitial = "A",
            circleTag = "late thoughts",
            mood = MoodType.MIDNIGHT,
            quote = "Stargazing from the rooftop, tracing constellations in quiet reverence.",
            timeAgo = "2h ago",
            isViewed = false,
            drawableRes = null
        ),
        Story(
            id = "s_4",
            authorName = "Ray",
            authorInitial = "R",
            circleTag = "little joys",
            mood = MoodType.BLOOMING,
            quote = "Found a handwritten note tucked inside a second-hand poetry book.",
            timeAgo = "3h ago",
            isViewed = true,
            drawableRes = null
        )
    )

    fun initialSouls(): List<SoulProfile> = listOf(
        SoulProfile(
            id = "soul_1",
            name = "Zainab",
            handle = "@zainab_words",
            initial = "Z",
            bio = "Poetry, rain walks, and quiet little moments.",
            moodCategory = MoodType.RAINY,
            helloSent = true,
            isFollowing = true,
            followersCount = 342,
            frequencyVibe = "98% frequency match"
        ),
        SoulProfile(
            id = "soul_2",
            name = "Ayan",
            handle = "@ayan_midnight",
            initial = "A",
            bio = "Late night thoughts, lo-fi playlists, and stargazing.",
            moodCategory = MoodType.MIDNIGHT,
            helloSent = true,
            isFollowing = true,
            followersCount = 289,
            frequencyVibe = "95% frequency match"
        ),
        SoulProfile(
            id = "soul_3",
            name = "Hira",
            handle = "@hira_glow",
            initial = "H",
            bio = "Golden-hour photography and small wins.",
            moodCategory = MoodType.SUNSET,
            helloSent = true,
            isFollowing = false,
            followersCount = 412,
            frequencyVibe = "92% frequency match"
        ),
        SoulProfile(
            id = "soul_4",
            name = "Ray",
            handle = "@ray_art",
            initial = "R",
            bio = "Art, new ideas, and finding beauty in ordinary days.",
            moodCategory = MoodType.BLOOMING,
            helloSent = false,
            isFollowing = false,
            followersCount = 180,
            frequencyVibe = "89% frequency match"
        ),
        SoulProfile(
            id = "soul_5",
            name = "Kaelen",
            handle = "@kaelen_ambient",
            initial = "K",
            bio = "Ambient synthesizers, tea rituals, and poetic architecture.",
            moodCategory = MoodType.SERENE,
            helloSent = false,
            isFollowing = false,
            followersCount = 224,
            frequencyVibe = "94% frequency match"
        ),
        SoulProfile(
            id = "soul_6",
            name = "Mira",
            handle = "@mira_twilight",
            initial = "M",
            bio = "Quiet mornings, written letters, and twilight clouds.",
            moodCategory = MoodType.RAINY,
            helloSent = false,
            isFollowing = false,
            followersCount = 195,
            frequencyVibe = "91% frequency match"
        )
    )

    fun initialThreads(): List<InboxThread> = listOf(
        InboxThread(
            id = "th_1",
            personName = "Zainab",
            personInitial = "Z",
            moodTitle = "Rainy thoughts",
            mood = MoodType.RAINY,
            lastSnippet = "That line about the rain felt familiar 🌧️",
            unread = false,
            messages = listOf(
                ChatMessage(
                    id = "msg_1",
                    senderName = "Zainab",
                    text = "Hello! I saw your recent moment about ambient rain light.",
                    time = "10:14 AM",
                    isFromMe = false
                ),
                ChatMessage(
                    id = "msg_2",
                    senderName = "You",
                    text = "It felt like time stopped for a moment while the tea brewed.",
                    time = "10:18 AM",
                    isFromMe = true
                ),
                ChatMessage(
                    id = "msg_3",
                    senderName = "Zainab",
                    text = "That line about the rain felt familiar 🌧️. Have you read Mary Oliver's rain poems?",
                    time = "10:22 AM",
                    isFromMe = false
                ),
                ChatMessage(
                    id = "msg_vn_1",
                    senderName = "Zainab",
                    text = "Voice note · Rain cadence reading",
                    time = "10:25 AM",
                    isFromMe = false,
                    isVoiceNote = true,
                    voiceDurationSec = 14
                )
            )
        ),
        InboxThread(
            id = "th_2",
            personName = "Ayan",
            personInitial = "A",
            moodTitle = "Midnight talks",
            mood = MoodType.MIDNIGHT,
            lastSnippet = "Send me that lo-fi playlist when you can. 🎧",
            unread = true,
            messages = listOf(
                ChatMessage(
                    id = "msg_4",
                    senderName = "Ayan",
                    text = "Stargazing tonight was unbelievable. Zero light pollution.",
                    time = "Yesterday",
                    isFromMe = false
                ),
                ChatMessage(
                    id = "msg_5",
                    senderName = "Ayan",
                    text = "Send me that lo-fi playlist when you can. 🎧",
                    time = "1:15 AM",
                    isFromMe = false
                )
            )
        ),
        InboxThread(
            id = "th_3",
            personName = "Hira",
            personInitial = "H",
            moodTitle = "Golden hour",
            mood = MoodType.SUNSET,
            lastSnippet = "The sky looked unreal today 🌇",
            unread = false,
            messages = listOf(
                ChatMessage(
                    id = "msg_6",
                    senderName = "Hira",
                    text = "The sky looked unreal today 🌇. Captured some film shots from the bridge.",
                    time = "Yesterday",
                    isFromMe = false
                ),
                ChatMessage(
                    id = "msg_7",
                    senderName = "You",
                    text = "Can't wait to see your next aura visual card!",
                    time = "Yesterday",
                    isFromMe = true
                )
            )
        )
    )

    fun initialStreaks(): List<BondStreakItem> = listOf(
        BondStreakItem(
            id = "st_1",
            friendName = "Zainab",
            friendInitial = "Z",
            streakCount = 3,
            statusText = "Aura sent today · waiting for their Aura",
            sentToday = true,
            friendRepliedToday = false
        ),
        BondStreakItem(
            id = "st_2",
            friendName = "Ayan",
            friendInitial = "A",
            streakCount = 2,
            statusText = "Aura sent today · streak active! 🔥",
            sentToday = true,
            friendRepliedToday = true
        ),
        BondStreakItem(
            id = "st_3",
            friendName = "Hira",
            friendInitial = "H",
            streakCount = 0,
            statusText = "Send a creative moment to start today's streak",
            sentToday = false,
            friendRepliedToday = false
        )
    )

    fun initialBonds(): List<BondGardenItem> = listOf(
        BondGardenItem(
            id = "bg_1",
            friendName = "Zainab",
            ideaText = "A rainy-night poem, a photo pair of evening tea and misty streets",
            createdAgo = "2 days ago",
            bloomingStep = 3
        ),
        BondGardenItem(
            id = "bg_2",
            friendName = "Ayan",
            ideaText = "Late night lo-fi track exchange and midnight observations",
            createdAgo = "Yesterday",
            bloomingStep = 2
        )
    )

    fun symbols(): List<AuraSymbol> = listOf(
        AuraSymbol(
            key = "mood",
            title = "Mood",
            subtitle = "Feeling of the moment",
            description = "A delicate rain drop or subtle cloud expressing internal weather without performance or noise.",
            symbolChar = "☔"
        ),
        AuraSymbol(
            key = "bond",
            title = "Bond",
            subtitle = "Shared connection",
            description = "Intertwined loops representing reciprocal presence, shared reflections, and unspoken understanding.",
            symbolChar = "♾️"
        ),
        AuraSymbol(
            key = "aura_id",
            title = "Aura ID",
            subtitle = "Discovery identity",
            description = "A 24-hour rotating identifier allowing gentle discovery while protecting your permanent privacy.",
            symbolChar = "🛡️"
        ),
        AuraSymbol(
            key = "create",
            title = "Create",
            subtitle = "Creative instinctive",
            description = "A blooming cosmic burst for synthesizing feelings, poetry, and cinematic fragments.",
            symbolChar = "✨"
        ),
        AuraSymbol(
            key = "private",
            title = "Private",
            subtitle = "Protected space",
            description = "A serene crescent sanctuary where your kept thoughts remain sacred to you alone.",
            symbolChar = "🌙"
        ),
        AuraSymbol(
            key = "discover",
            title = "Discover",
            subtitle = "New connections",
            description = "Resonance compass to find souls vibrating at your current frequency.",
            symbolChar = "🧭"
        )
    )
}
