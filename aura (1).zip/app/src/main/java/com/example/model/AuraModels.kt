package com.example.model

import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.AuraEmerald
import com.example.ui.theme.AuraGold
import com.example.ui.theme.AuraRose
import com.example.ui.theme.AuraSkyBlue
import com.example.ui.theme.AuraVioletPrimary

enum class MoodType(
    val title: String,
    val circleLabel: String,
    val symbolEmoji: String,
    val accentColor: Color,
    val tagText: String
) {
    RAINY(
        title = "Rainy & reflective",
        circleLabel = "rainy mood",
        symbolEmoji = "☔",
        accentColor = AuraSkyBlue,
        tagText = "+ reflective"
    ),
    SUNSET(
        title = "Sunset & hopeful",
        circleLabel = "golden hour",
        symbolEmoji = "🌅",
        accentColor = AuraGold,
        tagText = "+ hopeful"
    ),
    MIDNIGHT(
        title = "Midnight & inward",
        circleLabel = "late thoughts",
        symbolEmoji = "🌙",
        accentColor = AuraVioletPrimary,
        tagText = "+ inward"
    ),
    BLOOMING(
        title = "Blooming & bright",
        circleLabel = "little joys",
        symbolEmoji = "🌸",
        accentColor = AuraRose,
        tagText = "+ bright"
    ),
    SERENE(
        title = "Ambient & serene",
        circleLabel = "quiet peace",
        symbolEmoji = "✨",
        accentColor = AuraEmerald,
        tagText = "+ serene"
    );

    val label: String get() = circleLabel
    val symbol: String get() = symbolEmoji
}

data class ThoughtComment(
    val id: String,
    val author: String,
    val authorInitial: String,
    val text: String,
    val timeAgo: String
)

data class Moment(
    val id: String,
    val authorName: String,
    val authorHandle: String = "@naira",
    val authorInitial: String,
    val timeAgo: String,
    val shareType: String,
    val mood: MoodType,
    val ambientHeader: String,
    val quoteText: String,
    val captionText: String,
    val feelCount: Int,
    val isFelt: Boolean = false,
    val isKept: Boolean = false,
    val isFollowingAuthor: Boolean = false,
    @DrawableRes val drawableRes: Int? = null,
    val mediaUri: String? = null,
    val mediaType: String? = null, // "photo", "video"
    val isVoiceNote: Boolean = false,
    val voiceDurationSec: Int = 0,
    val fontOptionName: String = "PLAYFAIR",
    val isPoetry: Boolean = false,
    val thoughts: List<ThoughtComment> = emptyList()
)

data class Story(
    val id: String,
    val authorName: String,
    val authorInitial: String,
    val circleTag: String,
    val mood: MoodType,
    val quote: String,
    val timeAgo: String,
    val isViewed: Boolean = false,
    @DrawableRes val drawableRes: Int? = null
)

data class SoulProfile(
    val id: String,
    val name: String,
    val handle: String = "@soul",
    val initial: String,
    val bio: String,
    val moodCategory: MoodType,
    val helloSent: Boolean = false,
    val isFollowing: Boolean = false,
    val followersCount: Int = 120,
    val frequencyVibe: String = "94% resonance"
)

data class ReelItem(
    val id: String,
    val authorName: String,
    val authorHandle: String,
    val authorInitial: String,
    val caption: String,
    val audioTrack: String,
    val mood: MoodType,
    val feelCount: Int,
    val isFelt: Boolean = false,
    val isKept: Boolean = false,
    val isFollowingAuthor: Boolean = false,
    @DrawableRes val drawableRes: Int,
    val mediaUri: String? = null,
    val thoughts: List<ThoughtComment> = emptyList()
)

data class ChatMessage(
    val id: String,
    val senderName: String,
    val text: String,
    val time: String,
    val isFromMe: Boolean,
    val isVoiceNote: Boolean = false,
    val voiceDurationSec: Int = 0,
    val mediaUri: String? = null,
    val mediaType: String? = null // "photo", "video"
)

enum class CallType {
    VOICE,
    VIDEO
}

data class ActiveCall(
    val id: String,
    val soulName: String,
    val soulHandle: String,
    val soulInitial: String,
    val type: CallType,
    val durationSeconds: Int = 0,
    val isMuted: Boolean = false,
    val isCameraOn: Boolean = true,
    val isSpeakerOn: Boolean = false
)

data class InboxThread(
    val id: String,
    val personName: String,
    val personInitial: String,
    val moodTitle: String,
    val mood: MoodType,
    val lastSnippet: String,
    val unread: Boolean = false,
    val messages: List<ChatMessage> = emptyList()
)

data class BondStreakItem(
    val id: String,
    val friendName: String,
    val friendInitial: String,
    val streakCount: Int,
    val statusText: String,
    val sentToday: Boolean,
    val friendRepliedToday: Boolean
)

data class BondGardenItem(
    val id: String,
    val friendName: String,
    val ideaText: String,
    val createdAgo: String,
    val bloomingStep: Int = 1
)

data class AuraSymbol(
    val key: String,
    val title: String,
    val subtitle: String,
    val description: String,
    val symbolChar: String
)
