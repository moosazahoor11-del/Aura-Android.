package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val AuraColorScheme = darkColorScheme(
    primary = AuraVioletPrimary,
    onPrimary = AuraBackground,
    primaryContainer = AuraSurfaceHighlight,
    onPrimaryContainer = AuraLavender,
    secondary = AuraVioletSecondary,
    onSecondary = AuraBackground,
    secondaryContainer = AuraSurfaceElevated,
    onSecondaryContainer = AuraTextSecondary,
    tertiary = AuraGold,
    onTertiary = AuraBackground,
    background = AuraBackground,
    onBackground = AuraTextPrimary,
    surface = AuraSurface,
    onSurface = AuraTextPrimary,
    surfaceVariant = AuraSurfaceElevated,
    onSurfaceVariant = AuraTextSecondary,
    outline = AuraBorder,
    outlineVariant = AuraBorderLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    // Aura is an immersive dark nocturnal experience matching the Connected Soul prototype
    MaterialTheme(
        colorScheme = AuraColorScheme,
        typography = Typography,
        content = content
    )
}
