package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import android.util.Log
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.rememberCoroutineScope
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.Firebase
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.model.MoodType
import com.example.ui.theme.AuraBackground
import com.example.ui.theme.AuraBorder
import com.example.ui.theme.AuraBorderLight
import com.example.ui.theme.AuraEmerald
import com.example.ui.theme.AuraGold
import com.example.ui.theme.AuraLavender
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraSurfaceHighlight
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletDark
import com.example.ui.theme.AuraVioletPrimary
import com.example.ui.theme.AuraVioletSecondary

val SOUL_ARCHETYPES = listOf(
    "The Nocturnal Poet",
    "The Cosmic Dreamer",
    "The Quiet Observer",
    "The Gentle Healer",
    "The Deep Thinker",
    "The Ambient Artist"
)

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AuthSignDialog(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    onSignIn: (name: String, handle: String, email: String, archetype: String, mood: MoodType, avatarUri: String?) -> Unit
) {
    if (!isOpen) return

    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0 = Sign In, 1 = Create Soul Profile

    // Sign In Fields
    var signInIdentifier by remember { mutableStateOf("moosa@aura.soul") }
    var signInPassword by remember { mutableStateOf("celestial_123") }
    var isPasswordVisible by remember { mutableStateOf(false) }

    // Sign Up / Register Soul Fields
    var signUpName by remember { mutableStateOf("") }
    var signUpHandle by remember { mutableStateOf("") }
    var signUpEmail by remember { mutableStateOf("") }
    var signUpPassword by remember { mutableStateOf("") }
    var signUpArchetype by remember { mutableStateOf(SOUL_ARCHETYPES[0]) }
    var signUpMood by remember { mutableStateOf(MoodType.RAINY) }
    var signUpAesthetic by remember { mutableStateOf("Midnight rain, warm cinnamon tea & lofi frequencies") }
    var pickedAvatarUri by remember { mutableStateOf<String?>(null) }
    var selectedPresetAvatar by remember { mutableStateOf("🌙") }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    var isGoogleSigningIn by remember { mutableStateOf(false) }

    // Android Zero-permission photo picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            pickedAvatarUri = uri.toString()
            selectedPresetAvatar = ""
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(AuraBackground)
                .imePadding(),
            color = AuraBackground
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                // Top Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(AuraSurfaceElevated)
                            .testTag("auth_dialog_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = AuraTextPrimary
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(AuraEmerald)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SOUL GATEWAY",
                            color = AuraLavender,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(AuraSurfaceElevated)
                            .testTag("auth_dialog_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = AuraTextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Brand Emblem & Heading
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(listOf(AuraVioletSecondary, AuraVioletDark))
                            )
                            .border(1.5.dp, AuraVioletPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("✦", color = AuraGold, fontSize = 24.sp)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "AURA SANCTUARY",
                        color = AuraTextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif,
                        letterSpacing = 1.sp
                    )

                    Text(
                        text = "Where kindred spirits resonate in quietude",
                        color = AuraTextSecondary,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Tab Switcher (Sign In vs Create Soul Profile)
                TabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = AuraSurface,
                    contentColor = AuraVioletPrimary,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                            color = AuraVioletPrimary,
                            height = 2.5.dp
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, AuraBorderLight, RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = selectedTabIndex == 0,
                        onClick = { selectedTabIndex = 0 },
                        modifier = Modifier.testTag("auth_tab_sign_in"),
                        text = {
                            Text(
                                "Sign In",
                                fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == 0) AuraTextPrimary else AuraTextMuted
                            )
                        }
                    )
                    Tab(
                        selected = selectedTabIndex == 1,
                        onClick = { selectedTabIndex = 1 },
                        modifier = Modifier.testTag("auth_tab_sign_up"),
                        text = {
                            Text(
                                "Create Soul Profile",
                                fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == 1) AuraTextPrimary else AuraTextMuted
                            )
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Tab Content
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    if (selectedTabIndex == 0) {
                        // ====================== SIGN IN TAB ======================
                        item {
                            Text(
                                text = "Return to Your Orbit",
                                color = AuraTextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Serif
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Enter your soul handle or email to restore your resonant space.",
                                color = AuraTextMuted,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(16.dp))

                            OutlinedTextField(
                                value = signInIdentifier,
                                onValueChange = { signInIdentifier = it },
                                label = { Text("Email or @Handle") },
                                leadingIcon = {
                                    Icon(Icons.Default.Email, contentDescription = null, tint = AuraVioletPrimary)
                                },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AuraVioletPrimary,
                                    unfocusedBorderColor = AuraBorderLight,
                                    focusedTextColor = AuraTextPrimary,
                                    unfocusedTextColor = AuraTextPrimary,
                                    focusedLabelColor = AuraVioletPrimary,
                                    unfocusedLabelColor = AuraTextMuted,
                                    focusedContainerColor = AuraSurfaceElevated,
                                    unfocusedContainerColor = AuraSurface
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("sign_in_identifier_input")
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            OutlinedTextField(
                                value = signInPassword,
                                onValueChange = { signInPassword = it },
                                label = { Text("Soul Password") },
                                leadingIcon = {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = AuraVioletPrimary)
                                },
                                trailingIcon = {
                                    IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                        Icon(
                                            imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = if (isPasswordVisible) "Hide password" else "Show password",
                                            tint = AuraTextMuted
                                        )
                                    }
                                },
                                visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AuraVioletPrimary,
                                    unfocusedBorderColor = AuraBorderLight,
                                    focusedTextColor = AuraTextPrimary,
                                    unfocusedTextColor = AuraTextPrimary,
                                    focusedLabelColor = AuraVioletPrimary,
                                    unfocusedLabelColor = AuraTextMuted,
                                    focusedContainerColor = AuraSurfaceElevated,
                                    unfocusedContainerColor = AuraSurface
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("sign_in_password_input")
                            )

                            Spacer(modifier = Modifier.height(20.dp))

                            Button(
                                onClick = {
                                    val name = if (signInIdentifier.contains("@moosa")) "Moosa Zahoor" else "Soul Wanderer"
                                    val handle = if (signInIdentifier.startsWith("@")) signInIdentifier else "@${signInIdentifier.substringBefore("@")}"
                                    onSignIn(
                                        name,
                                        handle,
                                        signInIdentifier,
                                        "The Nocturnal Poet",
                                        MoodType.RAINY,
                                        pickedAvatarUri
                                    )
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AuraVioletSecondary),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("sign_in_submit_button")
                            ) {
                                Text(
                                    "Connect My Soul ✦",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = Color.White
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Google Sign-In via Jetpack Credential Manager
                            Button(
                                onClick = {
                                    isGoogleSigningIn = true
                                    coroutineScope.launch {
                                        try {
                                            val webClientId = runCatching {
                                                context.getString(R.string.default_web_client_id)
                                            }.getOrNull()

                                            if (!webClientId.isNullOrBlank()) {
                                                val googleIdOption = GetSignInWithGoogleOption.Builder(webClientId)
                                                    .build()
                                                val request = GetCredentialRequest.Builder()
                                                    .addCredentialOption(googleIdOption)
                                                    .build()

                                                val result = credentialManager.getCredential(request = request, context = context)
                                                val credential = result.credential
                                                if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                                                    val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data)
                                                    val firebaseCred = GoogleAuthProvider.getCredential(googleIdToken.idToken, null)
                                                    val authResult = Firebase.auth.signInWithCredential(firebaseCred).await()
                                                    val user = authResult.user
                                                    val name = user?.displayName ?: googleIdToken.displayName ?: "Kindred Soul"
                                                    val email = user?.email ?: googleIdToken.id
                                                    val cleanHandle = "@" + email.substringBefore("@").replace(".", "_").lowercase()
                                                    val avatar = user?.photoUrl?.toString()
                                                    onSignIn(name, cleanHandle, email, "The Cosmic Dreamer", MoodType.SUNSET, avatar)
                                                }
                                            } else {
                                                onSignIn("Google Soul", "@google_aura", "google@aura.space", "The Cosmic Dreamer", MoodType.SUNSET, null)
                                            }
                                        } catch (e: GetCredentialCancellationException) {
                                            Log.w("AuthSignDialog", "Google Sign-In was cancelled by user: ${e.message}")
                                        } catch (e: Exception) {
                                            Log.e("AuthSignDialog", "Google Sign-In failed", e)
                                        } finally {
                                            isGoogleSigningIn = false
                                        }
                                    }
                                },
                                enabled = !isGoogleSigningIn,
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AuraSurfaceHighlight),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .border(1.dp, AuraBorderLight, RoundedCornerShape(14.dp))
                                    .testTag("google_sign_in_button")
                            ) {
                                Text(
                                    text = "G ",
                                    color = AuraGold,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 18.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isGoogleSigningIn) "Connecting Google Account..." else "Sign in with Google",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = AuraTextPrimary
                                )
                            }

                            Spacer(modifier = Modifier.height(20.dp))

                            // Quick 1-Tap Demo Souls
                            Text(
                                text = "QUICK 1-TAP DEMO SOULS",
                                color = AuraTextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            DemoSoulItem(
                                name = "Moosa Zahoor",
                                handle = "@moosa_aura",
                                archetype = "The Nocturnal Poet",
                                symbol = "🌙",
                                mood = MoodType.RAINY,
                                onSelect = {
                                    onSignIn("Moosa Zahoor", "@moosa_aura", "moosa@aura.soul", "The Nocturnal Poet", MoodType.RAINY, null)
                                }
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            DemoSoulItem(
                                name = "Zainab Al-Noor",
                                handle = "@zainab_aura",
                                archetype = "The Cosmic Dreamer",
                                symbol = "✨",
                                mood = MoodType.SUNSET,
                                onSelect = {
                                    onSignIn("Zainab Al-Noor", "@zainab_aura", "zainab@aura.soul", "The Cosmic Dreamer", MoodType.SUNSET, null)
                                }
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            DemoSoulItem(
                                name = "Ayan Veda",
                                handle = "@ayan_thinker",
                                archetype = "The Deep Thinker",
                                symbol = "🕯️",
                                mood = MoodType.MIDNIGHT,
                                onSelect = {
                                    onSignIn("Ayan Veda", "@ayan_thinker", "ayan@aura.soul", "The Deep Thinker", MoodType.MIDNIGHT, null)
                                }
                            )
                        }
                    } else {
                        // ====================== SIGN UP / REGISTER SOUL TAB ======================
                        item {
                            Text(
                                text = "Awaken a New Soul",
                                color = AuraTextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Serif
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Craft your profile, upload your DP, and declare your resonance archetype.",
                                color = AuraTextMuted,
                                fontSize = 12.sp
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            // 1. Profile DP (Picture) Picker Section
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = AuraSurface),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, AuraBorderLight, RoundedCornerShape(16.dp))
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "PROFILE PICTURE (DP)",
                                        color = AuraLavender,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Avatar Preview Bubble
                                    Box(
                                        modifier = Modifier
                                            .size(86.dp)
                                            .clip(CircleShape)
                                            .background(
                                                Brush.radialGradient(listOf(AuraVioletSecondary, AuraVioletDark))
                                            )
                                            .border(2.dp, AuraVioletPrimary, CircleShape)
                                            .clickable {
                                                photoPickerLauncher.launch(
                                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                )
                                            }
                                            .testTag("auth_dp_avatar_preview"),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (pickedAvatarUri != null) {
                                            AsyncImage(
                                                model = pickedAvatarUri,
                                                contentDescription = "Profile DP",
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop
                                            )
                                        } else {
                                            Text(
                                                text = if (signUpName.isNotBlank()) signUpName.take(1).uppercase() else selectedPresetAvatar,
                                                color = Color.White,
                                                fontSize = 32.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Pick Photo from gallery (zero permission photo picker)
                                    OutlinedButton(
                                        onClick = {
                                            photoPickerLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                        shape = RoundedCornerShape(20.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AuraVioletPrimary),
                                        border = ButtonDefaults.outlinedButtonBorder.copy(
                                            brush = Brush.horizontalGradient(listOf(AuraVioletSecondary, AuraVioletPrimary))
                                        ),
                                        modifier = Modifier.testTag("auth_choose_photo_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AddPhotoAlternate,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (pickedAvatarUri != null) "Change Photo DP" else "Upload Profile DP 📷",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Or choose a Celestial Glyph preset
                                    Text(
                                        text = "Or choose a celestial soul symbol:",
                                        color = AuraTextMuted,
                                        fontSize = 11.sp
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        listOf("🌙", "✦", "🪐", "🕯️", "🌊").forEach { symbol ->
                                            val isSelected = selectedPresetAvatar == symbol && pickedAvatarUri == null
                                            Box(
                                                modifier = Modifier
                                                    .size(38.dp)
                                                    .clip(CircleShape)
                                                    .background(if (isSelected) AuraVioletSecondary else AuraSurfaceElevated)
                                                    .border(
                                                        1.dp,
                                                        if (isSelected) AuraGold else AuraBorderLight,
                                                        CircleShape
                                                    )
                                                    .clickable {
                                                        selectedPresetAvatar = symbol
                                                        pickedAvatarUri = null
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(symbol, fontSize = 16.sp)
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Name Field
                            OutlinedTextField(
                                value = signUpName,
                                onValueChange = { signUpName = it },
                                label = { Text("Display Name") },
                                placeholder = { Text("e.g. Moosa Zahoor") },
                                leadingIcon = {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = AuraVioletPrimary)
                                },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AuraVioletPrimary,
                                    unfocusedBorderColor = AuraBorderLight,
                                    focusedTextColor = AuraTextPrimary,
                                    unfocusedTextColor = AuraTextPrimary,
                                    focusedLabelColor = AuraVioletPrimary,
                                    unfocusedLabelColor = AuraTextMuted,
                                    focusedContainerColor = AuraSurfaceElevated,
                                    unfocusedContainerColor = AuraSurface
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("sign_up_name_input")
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Handle Field
                            OutlinedTextField(
                                value = signUpHandle,
                                onValueChange = {
                                    val cleaned = it.replace(" ", "_").lowercase()
                                    signUpHandle = if (cleaned.startsWith("@")) cleaned else "@$cleaned"
                                },
                                label = { Text("Soul Handle (@...)") },
                                placeholder = { Text("@moosa_aura") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AuraVioletPrimary,
                                    unfocusedBorderColor = AuraBorderLight,
                                    focusedTextColor = AuraTextPrimary,
                                    unfocusedTextColor = AuraTextPrimary,
                                    focusedLabelColor = AuraVioletPrimary,
                                    unfocusedLabelColor = AuraTextMuted,
                                    focusedContainerColor = AuraSurfaceElevated,
                                    unfocusedContainerColor = AuraSurface
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("sign_up_handle_input")
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Email Field
                            OutlinedTextField(
                                value = signUpEmail,
                                onValueChange = { signUpEmail = it },
                                label = { Text("Soul Email") },
                                placeholder = { Text("your.soul@aura.space") },
                                leadingIcon = {
                                    Icon(Icons.Default.Email, contentDescription = null, tint = AuraVioletPrimary)
                                },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AuraVioletPrimary,
                                    unfocusedBorderColor = AuraBorderLight,
                                    focusedTextColor = AuraTextPrimary,
                                    unfocusedTextColor = AuraTextPrimary,
                                    focusedLabelColor = AuraVioletPrimary,
                                    unfocusedLabelColor = AuraTextMuted,
                                    focusedContainerColor = AuraSurfaceElevated,
                                    unfocusedContainerColor = AuraSurface
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("sign_up_email_input")
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Password Field
                            OutlinedTextField(
                                value = signUpPassword,
                                onValueChange = { signUpPassword = it },
                                label = { Text("Password") },
                                leadingIcon = {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = AuraVioletPrimary)
                                },
                                visualTransformation = PasswordVisualTransformation(),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AuraVioletPrimary,
                                    unfocusedBorderColor = AuraBorderLight,
                                    focusedTextColor = AuraTextPrimary,
                                    unfocusedTextColor = AuraTextPrimary,
                                    focusedLabelColor = AuraVioletPrimary,
                                    unfocusedLabelColor = AuraTextMuted,
                                    focusedContainerColor = AuraSurfaceElevated,
                                    unfocusedContainerColor = AuraSurface
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("sign_up_password_input")
                            )

                            Spacer(modifier = Modifier.height(18.dp))

                            // 2. Personality Archetype Details
                            Text(
                                text = "PERSONALITY ARCHETYPE",
                                color = AuraLavender,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                SOUL_ARCHETYPES.forEach { archetype ->
                                    val isSelected = signUpArchetype == archetype
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { signUpArchetype = archetype },
                                        label = {
                                            Text(
                                                archetype,
                                                fontSize = 12.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                        },
                                        leadingIcon = if (isSelected) {
                                            {
                                                Icon(
                                                    Icons.Default.Check,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        } else null,
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = AuraVioletSecondary,
                                            selectedLabelColor = Color.White,
                                            containerColor = AuraSurfaceElevated,
                                            labelColor = AuraTextSecondary
                                        ),
                                        border = FilterChipDefaults.filterChipBorder(
                                            borderColor = if (isSelected) AuraVioletPrimary else AuraBorderLight,
                                            enabled = true,
                                            selected = isSelected
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // 3. Primary Mood Frequency
                            Text(
                                text = "PRIMARY MOOD FREQUENCY",
                                color = AuraLavender,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                MoodType.values().forEach { mood ->
                                    val isSelected = signUpMood == mood
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(20.dp))
                                            .background(
                                                if (isSelected) AuraVioletSecondary else AuraSurfaceElevated
                                            )
                                            .border(
                                                1.dp,
                                                if (isSelected) AuraGold else AuraBorderLight,
                                                RoundedCornerShape(20.dp)
                                            )
                                            .clickable { signUpMood = mood }
                                            .padding(horizontal = 14.dp, vertical = 8.dp)
                                    ) {
                                        Text(
                                            text = "${mood.label} ${mood.symbol}",
                                            color = if (isSelected) Color.White else AuraTextSecondary,
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // 4. Personality Aesthetic Description
                            OutlinedTextField(
                                value = signUpAesthetic,
                                onValueChange = { signUpAesthetic = it },
                                label = { Text("Personality Aesthetic Tagline") },
                                placeholder = { Text("e.g. Midnight rain, warm cinnamon tea & lofi frequencies") },
                                singleLine = false,
                                maxLines = 3,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AuraVioletPrimary,
                                    unfocusedBorderColor = AuraBorderLight,
                                    focusedTextColor = AuraTextPrimary,
                                    unfocusedTextColor = AuraTextPrimary,
                                    focusedLabelColor = AuraVioletPrimary,
                                    unfocusedLabelColor = AuraTextMuted,
                                    focusedContainerColor = AuraSurfaceElevated,
                                    unfocusedContainerColor = AuraSurface
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("sign_up_aesthetic_input")
                            )

                            Spacer(modifier = Modifier.height(24.dp))

                            // Submit Button
                            Button(
                                onClick = {
                                    val finalName = signUpName.trim().ifBlank { "Moosa Zahoor" }
                                    val finalHandle = signUpHandle.trim().ifBlank { "@moosa_aura" }
                                    val finalEmail = signUpEmail.trim().ifBlank { "moosa@aura.soul" }
                                    onSignIn(
                                        finalName,
                                        finalHandle,
                                        finalEmail,
                                        signUpArchetype,
                                        signUpMood,
                                        pickedAvatarUri
                                    )
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AuraVioletSecondary),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("sign_up_submit_button")
                            ) {
                                Text(
                                    "Awaken Soul Profile ✦",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DemoSoulItem(
    name: String,
    handle: String,
    archetype: String,
    symbol: String,
    mood: MoodType,
    onSelect: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = AuraSurfaceElevated,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AuraBorderLight, RoundedCornerShape(14.dp))
            .clickable { onSelect() }
            .testTag("demo_soul_${handle.replace("@", "")}")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(listOf(AuraVioletSecondary, AuraVioletDark))
                        )
                        .border(1.dp, AuraVioletPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(symbol, fontSize = 18.sp)
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = name,
                        color = AuraTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "$handle · $archetype",
                        color = AuraLavender,
                        fontSize = 11.sp
                    )
                }
            }

            TextButton(onClick = onSelect) {
                Text("Select", color = AuraVioletPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
