package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.CallType
import com.example.model.ChatMessage
import com.example.model.InboxThread
import com.example.ui.theme.AuraBackground
import com.example.ui.theme.AuraBorder
import com.example.ui.theme.AuraBorderLight
import com.example.ui.theme.AuraLavender
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraSurfaceHighlight
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletDark
import com.example.ui.theme.AuraVioletPrimary
import com.example.ui.theme.AuraVioletSecondary
import kotlinx.coroutines.delay

@Composable
fun ChatConversationSheet(
    thread: InboxThread?,
    onClose: () -> Unit,
    onSendMessage: (String) -> Unit,
    onSendVoiceNote: (durationSec: Int) -> Unit,
    onSendMediaMessage: (mediaUri: String, type: String) -> Unit,
    onStartCall: (CallType) -> Unit,
    modifier: Modifier = Modifier
) {
    if (thread == null) return

    var draftMessage by remember { mutableStateOf("") }
    var isRecordingVoiceNote by remember { mutableStateOf(false) }
    var recordingSeconds by remember { mutableIntStateOf(0) }
    var attachMenuExpanded by remember { mutableStateOf(false) }

    // Android Zero-permission Photo Picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onSendMediaMessage(uri.toString(), "photo")
        }
    }

    // Voice note recording timer
    LaunchedEffect(isRecordingVoiceNote) {
        if (isRecordingVoiceNote) {
            recordingSeconds = 0
            while (isRecordingVoiceNote) {
                delay(1000)
                recordingSeconds++
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AuraBackground)
            .statusBarsPadding()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("chat_conversation_sheet")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header with Person info + Call & Video Call Buttons
            Surface(
                color = AuraSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, AuraBorder, RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onClose, modifier = Modifier.size(34.dp)) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = AuraTextPrimary
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(listOf(AuraVioletSecondary, AuraVioletDark))
                                )
                                .border(1.dp, thread.mood.accentColor, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = thread.personInitial,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = thread.personName,
                                color = AuraTextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${thread.moodTitle} · Connected",
                                color = thread.mood.accentColor,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Voice and Video call action buttons
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Voice Call Button
                        IconButton(
                            onClick = { onStartCall(CallType.VOICE) },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(AuraSurfaceElevated)
                                .testTag("start_voice_call_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Call,
                                contentDescription = "Voice Call",
                                tint = AuraLavender,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Video Call Button
                        IconButton(
                            onClick = { onStartCall(CallType.VIDEO) },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(AuraSurfaceElevated)
                                .testTag("start_video_call_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = "Video Call",
                                tint = AuraVioletPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            // Message History
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(14.dp))
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "A quieter kind of conversation 💜 · End-to-end quietude",
                            color = AuraTextMuted,
                            fontSize = 11.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                items(thread.messages) { msg ->
                    val isMe = msg.isFromMe
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            shape = RoundedCornerShape(
                                topStart = 16.dp,
                                topEnd = 16.dp,
                                bottomStart = if (isMe) 16.dp else 4.dp,
                                bottomEnd = if (isMe) 4.dp else 16.dp
                            ),
                            color = if (isMe) AuraVioletDark else AuraSurfaceElevated,
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = Brush.horizontalGradient(
                                    listOf(
                                        if (isMe) AuraVioletSecondary else AuraBorder,
                                        if (isMe) AuraVioletDark else AuraBorderLight
                                    )
                                )
                            ),
                            modifier = Modifier.fillMaxWidth(0.84f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                if (msg.isVoiceNote) {
                                    // Voice Note Player Bubble
                                    VoiceNotePlayerBubble(
                                        durationSec = msg.voiceDurationSec,
                                        isMe = isMe
                                    )
                                } else if (msg.mediaUri != null) {
                                    // Photo / Video Attachment Message
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(160.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(AuraSurfaceHighlight)
                                    ) {
                                        Image(
                                            painter = painterResource(id = R.drawable.reel_midnight_fog),
                                            contentDescription = "Media attachment",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                    if (msg.text.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(text = msg.text, color = Color.White, fontSize = 13.sp)
                                    }
                                } else {
                                    // Standard text message
                                    Text(
                                        text = msg.text,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        lineHeight = 18.sp
                                    )
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = msg.time,
                                    color = if (isMe) AuraLavender.copy(alpha = 0.7f) else AuraTextMuted,
                                    fontSize = 10.sp,
                                    modifier = Modifier.align(Alignment.End)
                                )
                            }
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(14.dp)) }
            }

            // Voice Note Live Recording Bar (if active)
            AnimatedVisibility(
                visible = isRecordingVoiceNote,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Surface(
                    color = AuraSurfaceElevated,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AuraVioletPrimary, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE11D48))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Recording voice note...",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = String.format("%02d:%02d", recordingSeconds / 60, recordingSeconds % 60),
                                color = AuraVioletPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { isRecordingVoiceNote = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Cancel", tint = AuraTextMuted)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            IconButton(
                                onClick = {
                                    isRecordingVoiceNote = false
                                    onSendVoiceNote(recordingSeconds.coerceAtLeast(2))
                                },
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(AuraVioletSecondary)
                                    .testTag("send_voice_note_button")
                            ) {
                                Icon(Icons.Default.Check, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }

            // Composer bar
            if (!isRecordingVoiceNote) {
                Surface(
                    color = AuraSurface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.8.dp, AuraBorder, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Media Attach Button
                        Box {
                            IconButton(
                                onClick = { attachMenuExpanded = true },
                                modifier = Modifier.size(36.dp).testTag("chat_attach_media_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AddPhotoAlternate,
                                    contentDescription = "Attach photo or video",
                                    tint = AuraVioletPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            DropdownMenu(
                                expanded = attachMenuExpanded,
                                onDismissRequest = { attachMenuExpanded = false },
                                modifier = Modifier.background(AuraSurfaceElevated)
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Pick Photo from Gallery", color = AuraTextPrimary) },
                                    onClick = {
                                        attachMenuExpanded = false
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Pick Video Reel from Gallery", color = AuraTextPrimary) },
                                    onClick = {
                                        attachMenuExpanded = false
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                        )
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Attach Ambient Rain Visual 🌧️", color = AuraTextPrimary) },
                                    onClick = {
                                        attachMenuExpanded = false
                                        onSendMediaMessage("preset_ambient_rain", "photo")
                                    }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        OutlinedTextField(
                            value = draftMessage,
                            onValueChange = { draftMessage = it },
                            placeholder = {
                                Text(
                                    text = "A quiet reflection...",
                                    color = AuraTextMuted,
                                    fontSize = 13.sp
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_input_field"),
                            shape = RoundedCornerShape(20.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = AuraTextPrimary,
                                unfocusedTextColor = AuraTextPrimary,
                                focusedContainerColor = AuraSurfaceElevated,
                                unfocusedContainerColor = AuraSurfaceElevated,
                                focusedBorderColor = AuraVioletPrimary,
                                unfocusedBorderColor = AuraBorder
                            )
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        if (draftMessage.isNotBlank()) {
                            IconButton(
                                onClick = {
                                    onSendMessage(draftMessage)
                                    draftMessage = ""
                                },
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(AuraVioletSecondary)
                                    .testTag("send_chat_message_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Send message",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        } else {
                            // Record Voice Note Button
                            IconButton(
                                onClick = { isRecordingVoiceNote = true },
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(AuraSurfaceHighlight)
                                    .testTag("record_voice_note_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Record Voice Note",
                                    tint = AuraVioletPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VoiceNotePlayerBubble(
    durationSec: Int,
    isMe: Boolean
) {
    var isPlaying by remember { mutableStateOf(false) }
    var playbackProgress by remember { mutableStateOf(0f) }

    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            val totalMillis = durationSec * 1000L
            val step = 100L
            var current = 0L
            while (current < totalMillis && isPlaying) {
                delay(step)
                current += step
                playbackProgress = current.toFloat() / totalMillis
            }
            isPlaying = false
            playbackProgress = 0f
        }
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(if (isMe) AuraVioletSecondary else AuraSurfaceHighlight)
                .clickable { isPlaying = !isPlaying },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            LinearProgressIndicator(
                progress = { if (isPlaying) playbackProgress else 0.35f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = if (isMe) AuraLavender else AuraVioletPrimary,
                trackColor = Color.White.copy(alpha = 0.2f)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (isPlaying) "Playing voice note..." else "Voice note",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = String.format("0:%02d", durationSec),
                    color = AuraLavender,
                    fontSize = 10.sp
                )
            }
        }
    }
}
