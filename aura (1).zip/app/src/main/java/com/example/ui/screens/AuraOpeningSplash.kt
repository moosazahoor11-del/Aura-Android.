package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.AuraBackground
import com.example.ui.theme.AuraBorder
import com.example.ui.theme.AuraBorderLight
import com.example.ui.theme.AuraGold
import com.example.ui.theme.AuraLavender
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletDark
import com.example.ui.theme.AuraVioletPrimary
import com.example.ui.theme.AuraVioletSecondary
import com.example.ui.theme.CinzelFontFamily
import com.example.ui.theme.PlayfairDisplayFontFamily
import kotlinx.coroutines.delay

@Composable
fun AuraOpeningSplash(
    onEnter: () -> Unit,
    modifier: Modifier = Modifier
) {
    var stage by remember { mutableStateOf(0) } // 0: initial, 1: symbol glow, 2: title, 3: quote & button

    val infiniteTransition = rememberInfiniteTransition(label = "celestial_breathing")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val haloRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(18000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "halo_rotation"
    )

    val letterSpacingAnim = remember { Animatable(1.5f) }

    LaunchedEffect(Unit) {
        stage = 1
        delay(450)
        stage = 2
        letterSpacingAnim.animateTo(
            targetValue = 5.5f,
            animationSpec = tween(1200, easing = FastOutSlowInEasing)
        )
        stage = 3
        delay(2200)
        onEnter()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AuraBackground)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onEnter() }
            .testTag("app_opening_animation_screen"),
        contentAlignment = Alignment.Center
    ) {
        // Ambient background celestial radial lights
        Box(
            modifier = Modifier
                .size(340.dp)
                .scale(pulseScale)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            AuraVioletPrimary.copy(alpha = 0.28f),
                            AuraVioletDark.copy(alpha = 0.15f),
                            Color.Transparent
                        )
                    )
                )
        )

        // Outer Rotating Star Ring
        Box(
            modifier = Modifier
                .size(240.dp)
                .rotate(haloRotation)
                .border(
                    width = 1.2.dp,
                    brush = Brush.sweepGradient(
                        listOf(
                            AuraVioletPrimary.copy(alpha = 0.5f),
                            AuraGold.copy(alpha = 0.7f),
                            AuraLavender.copy(alpha = 0.2f),
                            AuraVioletPrimary.copy(alpha = 0.5f)
                        )
                    ),
                    shape = CircleShape
                )
        )

        // Middle Counter-rotating Celestial Orbit
        Box(
            modifier = Modifier
                .size(190.dp)
                .rotate(-haloRotation * 0.7f)
                .border(
                    width = 0.8.dp,
                    brush = Brush.sweepGradient(
                        listOf(
                            Color.Transparent,
                            AuraVioletSecondary.copy(alpha = 0.6f),
                            AuraGold.copy(alpha = 0.4f),
                            Color.Transparent
                        )
                    ),
                    shape = CircleShape
                )
        )

        // Center Brand Column
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 28.dp)
        ) {
            // Glowing Symbol Core
            AnimatedVisibility(
                visible = stage >= 1,
                enter = scaleIn(initialScale = 0.6f, animationSpec = tween(700)) + fadeIn(tween(600)),
                exit = fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(AuraVioletDark, AuraVioletPrimary)
                            )
                        )
                        .border(
                            width = 2.dp,
                            brush = Brush.linearGradient(
                                listOf(AuraGold, AuraVioletSecondary)
                            ),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.aura_icon),
                        contentDescription = "Aura Symbol",
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Brand Title "A U R A"
            AnimatedVisibility(
                visible = stage >= 2,
                enter = fadeIn(tween(600)) + scaleIn(initialScale = 0.85f, animationSpec = tween(600)),
                exit = fadeOut()
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "A U R A",
                        color = AuraTextPrimary,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = CinzelFontFamily,
                        letterSpacing = letterSpacingAnim.value.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "CONNECTED SOUL",
                        color = AuraGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 3.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Cinematic Tagline
            AnimatedVisibility(
                visible = stage >= 3,
                enter = fadeIn(tween(800)),
                exit = fadeOut()
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "A cinematic space for feelings, poetry,\nand connected souls.",
                        color = AuraTextSecondary,
                        fontSize = 14.sp,
                        fontFamily = PlayfairDisplayFontFamily,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 22.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(36.dp))

                    // Minimalist Skip / Enter Sanctuary Button
                    OutlinedButton(
                        onClick = onEnter,
                        shape = RoundedCornerShape(24.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = AuraSurfaceElevated.copy(alpha = 0.7f),
                            contentColor = AuraLavender
                        ),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = Brush.horizontalGradient(listOf(AuraBorder, AuraVioletSecondary))
                        ),
                        modifier = Modifier
                            .height(42.dp)
                            .testTag("enter_sanctuary_button")
                    ) {
                        Text(
                            text = "Enter Sanctuary ✨",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Bottom subtle caption
        Text(
            text = "Tap anywhere to continue",
            color = AuraTextMuted.copy(alpha = 0.6f),
            fontSize = 11.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(bottom = 20.dp)
        )
    }
}
