package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.Moment
import com.example.ui.components.AuraBottomNav
import com.example.ui.components.AuraTopBar
import com.example.ui.components.CreateMomentDialog
import com.example.ui.components.ThoughtCommentsSheet
import com.example.ui.screens.AuraOpeningSplash
import com.example.ui.screens.AuthSignDialog
import com.example.ui.screens.CallScreen
import com.example.ui.screens.ChatConversationSheet
import com.example.ui.screens.ComposePoetryScreen
import com.example.ui.screens.CreateReelDialog
import com.example.ui.screens.DiscoverScreen
import com.example.ui.screens.EditProfileDialog
import com.example.ui.screens.FeedScreen
import com.example.ui.screens.FollowingListDialog
import com.example.ui.screens.InboxScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ReelsScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.StoryViewerDialog
import com.example.ui.screens.StudioScreen
import com.example.ui.theme.AuraBackground
import com.example.ui.theme.AuraBorderLight
import com.example.ui.theme.AuraLavender
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletDark
import com.example.ui.theme.AuraVioletPrimary
import com.example.ui.theme.AuraVioletSecondary

@Composable
fun AuraApp(
    viewModel: AuraViewModel = viewModel(),
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()

    // Handle Android system back button cleanly
    BackHandler(
        enabled = uiState.isOpeningAnimationVisible ||
                uiState.isComposePoetryOpen ||
                uiState.isSignInDialogOpen ||
                uiState.isEditProfileDialogOpen ||
                uiState.activeCall != null ||
                uiState.isSearchOpen ||
                uiState.activeThreadId != null ||
                uiState.activeStoryId != null ||
                uiState.isCreateMomentDialogOpen ||
                uiState.isCreateReelDialogOpen ||
                uiState.isFollowingListDialogOpen ||
                uiState.isFollowersListDialogOpen ||
                uiState.selectedReelForThoughts != null ||
                uiState.selectedSymbol != null ||
                uiState.isDemoAccountModalOpen ||
                uiState.currentTab != AuraTab.FEED
    ) {
        when {
            uiState.isOpeningAnimationVisible -> viewModel.dismissOpeningAnimation()
            uiState.isComposePoetryOpen -> viewModel.closeComposePoetry()
            uiState.isSignInDialogOpen -> viewModel.closeSignInDialog()
            uiState.isEditProfileDialogOpen -> viewModel.closeEditProfileDialog()
            uiState.activeCall != null -> viewModel.endCall()
            uiState.isSearchOpen -> viewModel.closeSearch()
            uiState.activeThreadId != null -> viewModel.closeThread()
            uiState.activeStoryId != null -> viewModel.closeStory()
            uiState.selectedReelForThoughts != null -> viewModel.closeReelThoughts()
            uiState.isCreateMomentDialogOpen -> viewModel.closeCreateMomentDialog()
            uiState.isCreateReelDialogOpen -> viewModel.closeCreateReelDialog()
            uiState.isFollowingListDialogOpen -> viewModel.closeFollowingList()
            uiState.isFollowersListDialogOpen -> viewModel.closeFollowersList()
            uiState.selectedSymbol != null -> viewModel.selectSymbol(null)
            uiState.isDemoAccountModalOpen -> viewModel.toggleDemoAccountModal(false)
            uiState.currentTab != AuraTab.FEED -> viewModel.selectTab(AuraTab.FEED)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AuraBackground)
    ) {
        Scaffold(
            topBar = {
                AuraTopBar(
                    onAvatarClick = { viewModel.selectTab(AuraTab.ME) },
                    onSignInClick = { viewModel.openSignInDialog() },
                    onSearchClick = { viewModel.openSearch() },
                    userAvatarUri = uiState.userAvatarUri,
                    userName = uiState.userName,
                    isSignedIn = uiState.isSignedIn,
                    modifier = Modifier.statusBarsPadding()
                )
            },
            bottomBar = {
                AuraBottomNav(
                    currentTab = uiState.currentTab,
                    onTabSelected = { viewModel.selectTab(it) }
                )
            },
            containerColor = AuraBackground
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                Crossfade(
                    targetState = uiState.currentTab,
                    label = "tab_crossfade"
                ) { tab ->
                    when (tab) {
                        AuraTab.FEED -> FeedScreen(
                            moments = uiState.moments,
                            stories = uiState.stories,
                            feedStreamMode = uiState.feedStreamMode,
                            onStreamModeChange = { viewModel.setFeedStreamMode(it) },
                            onFollowAuthor = { viewModel.toggleFollowAuthor(it) },
                            onFeelMoment = { viewModel.toggleFeelMoment(it) },
                            onKeepMoment = { viewModel.toggleKeepMoment(it) },
                            onAddThought = { mId, text -> viewModel.addThought(mId, text) },
                            onOpenCreateMoment = { viewModel.openCreateMomentDialog() },
                            onOpenStory = { viewModel.openStory(it) },
                            onNavigateToReels = { viewModel.selectTab(AuraTab.REELS) },
                            onOpenComposePoetry = { viewModel.openComposePoetry() }
                        )

                        AuraTab.REELS -> ReelsScreen(
                            reels = uiState.reels,
                            onFeelReel = { viewModel.toggleFeelReel(it) },
                            onKeepReel = { viewModel.toggleKeepReel(it) },
                            onFollowAuthor = { viewModel.toggleFollowAuthor(it) },
                            onOpenThoughts = { viewModel.openReelThoughts(it) },
                            onOpenCreateReel = { viewModel.openCreateReelDialog() }
                        )

                        AuraTab.DISCOVER -> DiscoverScreen(
                            souls = uiState.souls,
                            selectedFilter = uiState.discoverFilter,
                            onFilterChange = { viewModel.setDiscoverFilter(it) },
                            onSendHello = { viewModel.sendHello(it) },
                            onSelectSoul = { viewModel.selectSoul(it) },
                            onToggleFollowSoul = { viewModel.toggleFollowSoul(it) }
                        )

                        AuraTab.STUDIO -> StudioScreen(
                            prompt = uiState.studioPrompt,
                            onPromptChange = { viewModel.updateStudioPrompt(it) },
                            selectedMood = uiState.studioMood,
                            onMoodChange = { viewModel.updateStudioMood(it) },
                            selectedVisualRes = uiState.studioVisualRes,
                            onVisualChange = { viewModel.updateStudioVisual(it) },
                            isSynthesizing = uiState.isSynthesizing,
                            synthesizedMoment = uiState.synthesizedMoment,
                            onSynthesize = { viewModel.synthesizeMoment() },
                            onPublish = { viewModel.publishSynthesizedMoment() },
                            onRandomSpark = { viewModel.setRandomStudioSpark() }
                        )

                        AuraTab.INBOX -> InboxScreen(
                            threads = uiState.threads,
                            onOpenThread = { viewModel.openThread(it) }
                        )

                        AuraTab.ME -> ProfileScreen(
                            userName = uiState.userName,
                            userBio = uiState.userBio,
                            momentsCount = uiState.moments.size,
                            keptCount = uiState.moments.count { it.isKept },
                            followingCount = uiState.souls.count { it.isFollowing },
                            followersCount = 142,
                            onOpenFollowing = { viewModel.openFollowingList() },
                            onOpenFollowers = { viewModel.openFollowersList() },
                            creationStreakDays = uiState.creationStreakDays,
                            hasCheckedInToday = uiState.hasCheckedInToday,
                            onCheckIn = { viewModel.checkInDaily() },
                            bondStreaks = uiState.bondStreaks,
                            onSendAura = { viewModel.sendAuraToFriend(it) },
                            onSimulateReply = { viewModel.simulateFriendReply() },
                            onResetStreaks = { viewModel.resetDemoStreaks() },
                            bondGarden = uiState.bondGarden,
                            onCreateBond = { friend, idea -> viewModel.createBond(friend, idea) },
                            rotatingAuraId = uiState.rotatingAuraId,
                            auraIdTimeRemaining = uiState.auraIdTimeRemaining,
                            onRotateAuraId = { viewModel.rotateAuraIdNow() },
                            onUpdateBio = { viewModel.updateBio(it) },
                            selectedSymbol = uiState.selectedSymbol,
                            onSelectSymbol = { viewModel.selectSymbol(it) },
                            onReplayOpeningAnimation = { viewModel.replayOpeningAnimation() },
                            onOpenComposePoetry = { viewModel.openComposePoetry() },
                            userHandle = uiState.userHandle,
                            userAvatarUri = uiState.userAvatarUri,
                            userPersonalityArchetype = uiState.userPersonalityArchetype,
                            userPersonalityAesthetic = uiState.userPersonalityAesthetic,
                            userPersonalityTags = uiState.userPersonalityTags,
                            userPrimaryMood = uiState.userPrimaryMood,
                            isSignedIn = uiState.isSignedIn,
                            onOpenEditProfile = { viewModel.openEditProfileDialog() },
                            onOpenSignIn = { viewModel.openSignInDialog() }
                        )
                    }
                }
            }
        }

        // Active Chat Conversation Overlay
        if (uiState.activeThreadId != null) {
            val activeThread = uiState.threads.find { it.id == uiState.activeThreadId }
            ChatConversationSheet(
                thread = activeThread,
                onClose = { viewModel.closeThread() },
                onSendMessage = { text ->
                    uiState.activeThreadId?.let { tid ->
                        viewModel.sendChatMessage(tid, text)
                    }
                },
                onSendVoiceNote = { durationSec ->
                    uiState.activeThreadId?.let { tid ->
                        viewModel.sendVoiceNote(tid, durationSec)
                    }
                },
                onSendMediaMessage = { mediaUri, type ->
                    uiState.activeThreadId?.let { tid ->
                        viewModel.sendMediaMessage(tid, mediaUri, type)
                    }
                },
                onStartCall = { callType ->
                    activeThread?.let { t ->
                        viewModel.startCall(
                            soulName = t.personName,
                            soulHandle = "@${t.personName.lowercase()}_soul",
                            soulInitial = t.personInitial,
                            type = callType
                        )
                    }
                }
            )
        }

        // Active Call Overlay (Video & Voice Call)
        if (uiState.activeCall != null) {
            CallScreen(
                call = uiState.activeCall,
                onEndCall = { viewModel.endCall() }
            )
        }

        // Search Overlay
        if (uiState.isSearchOpen) {
            SearchScreen(
                souls = uiState.souls,
                moments = uiState.moments,
                reels = uiState.reels,
                onClose = { viewModel.closeSearch() },
                onSelectSoul = { soul ->
                    viewModel.closeSearch()
                    viewModel.selectSoul(soul.id)
                    viewModel.selectTab(AuraTab.DISCOVER)
                },
                onSelectMoment = { moment ->
                    viewModel.closeSearch()
                    viewModel.selectTab(AuraTab.FEED)
                },
                onSelectReel = { reel ->
                    viewModel.closeSearch()
                    viewModel.selectTab(AuraTab.REELS)
                },
                onFollowSoul = { soulId ->
                    viewModel.toggleFollowSoul(soulId)
                }
            )
        }

        // Active Story Viewer Overlay
        if (uiState.activeStoryId != null) {
            val activeStory = uiState.stories.find { it.id == uiState.activeStoryId }
            StoryViewerDialog(
                story = activeStory,
                onDismiss = { viewModel.closeStory() },
                onNext = { viewModel.nextStory() },
                onPrev = { viewModel.prevStory() }
            )
        }

        // Create Moment Modal Dialog
        CreateMomentDialog(
            isOpen = uiState.isCreateMomentDialogOpen,
            onDismiss = { viewModel.closeCreateMomentDialog() },
            onSave = { text, mood, mediaUri, mediaType, isVoiceNote, voiceSec ->
                viewModel.createMoment(
                    text = text,
                    mood = mood,
                    mediaUri = mediaUri,
                    mediaType = mediaType,
                    isVoiceNote = isVoiceNote,
                    voiceDurationSec = voiceSec
                )
            }
        )

        // Create Reel Modal Dialog
        CreateReelDialog(
            isOpen = uiState.isCreateReelDialogOpen,
            onDismiss = { viewModel.closeCreateReelDialog() },
            onCreate = { caption, audio, mood, visual ->
                viewModel.createReel(caption, audio, mood, visual)
            }
        )

        // Following List Dialog
        FollowingListDialog(
            isOpen = uiState.isFollowingListDialogOpen,
            title = "Following Souls",
            souls = uiState.souls.filter { it.isFollowing },
            onToggleFollow = { viewModel.toggleFollowSoul(it) },
            onDismiss = { viewModel.closeFollowingList() }
        )

        // Followers List Dialog
        FollowingListDialog(
            isOpen = uiState.isFollowersListDialogOpen,
            title = "Soul Followers",
            souls = uiState.souls,
            onToggleFollow = { viewModel.toggleFollowSoul(it) },
            onDismiss = { viewModel.closeFollowersList() }
        )

        // Thoughts Bottom Sheet for Reel
        if (uiState.selectedReelForThoughts != null) {
            val selectedReel = uiState.selectedReelForThoughts!!
            // Adapt reel to ThoughtCommentsSheet format
            val tempMoment = Moment(
                id = selectedReel.id,
                authorName = selectedReel.authorName,
                authorInitial = selectedReel.authorInitial,
                timeAgo = "Reel thoughts",
                shareType = "Motion Aura",
                mood = selectedReel.mood,
                ambientHeader = selectedReel.audioTrack,
                quoteText = selectedReel.caption,
                captionText = selectedReel.audioTrack,
                feelCount = selectedReel.feelCount,
                thoughts = selectedReel.thoughts
            )
            ThoughtCommentsSheet(
                moment = tempMoment,
                onDismiss = { viewModel.closeReelThoughts() },
                onAddThought = { text ->
                    viewModel.addReelThought(selectedReel.id, text)
                }
            )
        }

        // Sign In / Persona Demo Modal
        if (uiState.isDemoAccountModalOpen) {
            Dialog(onDismissRequest = { viewModel.toggleDemoAccountModal(false) }) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = AuraSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AuraBorderLight, RoundedCornerShape(20.dp))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Aura Soul Identity",
                                color = AuraTextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Serif
                            )
                            IconButton(onClick = { viewModel.toggleDemoAccountModal(false) }) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = AuraTextMuted)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "You are currently signed in as Soul \"M\". In this demo, your account identity is protected with your 24-hour rotating Aura ID.",
                            color = AuraTextSecondary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = AuraSurfaceElevated,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(Brush.radialGradient(listOf(AuraVioletSecondary, AuraVioletDark))),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("M", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text("Active Soul · ${uiState.rotatingAuraId}", color = AuraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("Status: Connected softly ✨", color = AuraVioletPrimary, fontSize = 11.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = { viewModel.toggleDemoAccountModal(false) },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AuraVioletSecondary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Continue Journey", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Fullscreen Compose Poetry Screen Overlay
        if (uiState.isComposePoetryOpen) {
            ComposePoetryScreen(
                onClose = { viewModel.closeComposePoetry() },
                onPublish = { title, poemText, mood, fontName, backdropRes ->
                    viewModel.publishPoem(
                        title = title,
                        poemText = poemText,
                        mood = mood,
                        fontOptionName = fontName,
                        backdropRes = backdropRes
                    )
                }
            )
        }

        // Sign In & Soul Registration Dialog
        AuthSignDialog(
            isOpen = uiState.isSignInDialogOpen,
            onDismiss = { viewModel.closeSignInDialog() },
            onSignIn = { name, handle, email, archetype, mood, avatarUri ->
                viewModel.signIn(name, handle, email, archetype, mood, avatarUri)
            }
        )

        // Edit Profile & Personality Dialog
        EditProfileDialog(
            isOpen = uiState.isEditProfileDialogOpen,
            currentName = uiState.userName,
            currentHandle = uiState.userHandle,
            currentBio = uiState.userBio,
            currentAvatarUri = uiState.userAvatarUri,
            currentArchetype = uiState.userPersonalityArchetype,
            currentAesthetic = uiState.userPersonalityAesthetic,
            currentTags = uiState.userPersonalityTags,
            currentMood = uiState.userPrimaryMood,
            onDismiss = { viewModel.closeEditProfileDialog() },
            onSave = { name, handle, bio, avatarUri, archetype, aesthetic, tags, mood ->
                viewModel.updateProfile(name, handle, bio, avatarUri, archetype, aesthetic, tags, mood)
            }
        )

        // App Opening Animation Splash Overlay
        if (uiState.isOpeningAnimationVisible) {
            AuraOpeningSplash(
                onEnter = { viewModel.dismissOpeningAnimation() }
            )
        }
    }
}
