package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PersonOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import com.example.R
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.AuraSymbol
import com.example.model.Moment
import com.example.model.MoodType
import com.example.ui.AuraTab
import com.example.ui.theme.AuraBackground
import com.example.ui.theme.AuraBorder
import com.example.ui.theme.AuraBorderLight
import com.example.ui.theme.AuraCardGradientEnd
import com.example.ui.theme.AuraCardGradientStart
import com.example.ui.theme.AuraGold
import com.example.ui.theme.AuraLavender
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraSurfaceHighlight
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletDark
import com.example.ui.theme.AuraVioletPrimary
import com.example.ui.theme.AuraVioletSecondary

@Composable
fun AuraTopBar(
    onAvatarClick: () -> Unit,
    onSignInClick: () -> Unit,
    onSearchClick: () -> Unit = {},
    userAvatarUri: String? = null,
    userName: String = "Moosa Zahoor",
    isSignedIn: Boolean = true,
    modifier: Modifier = Modifier
) {
    Surface(
        color = AuraBackground,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.testTag("aura_brand_logo")
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(AuraVioletDark, AuraVioletPrimary)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "A",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        fontFamily = FontFamily.Serif
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "AURA",
                        color = AuraTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "CONNECTED SOUL",
                        color = AuraTextMuted,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Search Button
                IconButton(
                    onClick = onSearchClick,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(AuraSurfaceElevated)
                        .testTag("top_search_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = AuraVioletPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Sign In / Status button
                OutlinedButton(
                    onClick = onSignInClick,
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = AuraLavender
                    ),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = Brush.horizontalGradient(listOf(AuraBorderLight, AuraVioletSecondary))
                    ),
                    modifier = Modifier
                        .height(34.dp)
                        .testTag("top_sign_in_button")
                ) {
                    Icon(
                        imageVector = if (isSignedIn) Icons.Default.AutoAwesome else Icons.Default.Star,
                        contentDescription = null,
                        tint = if (isSignedIn) AuraGold else AuraVioletPrimary,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isSignedIn) "Soul Orbit" else "Sign in",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Profile Avatar Bubble with custom DP or initial
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(AuraVioletSecondary, AuraVioletDark)
                            )
                        )
                        .border(1.5.dp, AuraVioletPrimary, CircleShape)
                        .clickable { onAvatarClick() }
                        .testTag("top_avatar_button"),
                    contentAlignment = Alignment.Center
                ) {
                    if (!userAvatarUri.isNullOrBlank()) {
                        AsyncImage(
                            model = userAvatarUri,
                            contentDescription = "Profile DP",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Text(
                            text = if (userName.isNotBlank()) userName.take(1).uppercase() else "A",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AuraBottomNav(
    currentTab: AuraTab,
    onTabSelected: (AuraTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = AuraSurface,
        shadowElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .border(width = 0.8.dp, color = AuraBorder, shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            AuraTab.values().forEach { tab ->
                val isSelected = tab == currentTab
                val icon: ImageVector = when (tab) {
                    AuraTab.FEED -> Icons.Default.Home
                    AuraTab.REELS -> Icons.Default.PlayArrow
                    AuraTab.DISCOVER -> Icons.Default.Explore
                    AuraTab.STUDIO -> Icons.Default.AutoAwesome
                    AuraTab.INBOX -> Icons.Default.MailOutline
                    AuraTab.ME -> Icons.Default.PersonOutline
                }

                val iconColor by animateColorAsState(
                    targetValue = if (isSelected) AuraVioletPrimary else AuraTextMuted,
                    label = "tab_color"
                )

                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onTabSelected(tab) }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                        .testTag("nav_tab_${tab.name.lowercase()}"),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(if (isSelected) 36.dp else 28.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isSelected) AuraSurfaceHighlight else Color.Transparent
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = tab.label,
                            tint = iconColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Text(
                        text = tab.label,
                        color = iconColor,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

@Composable
fun MomentCard(
    moment: Moment,
    onFeelClick: () -> Unit,
    onKeepClick: () -> Unit,
    onThoughtClick: () -> Unit,
    onFollowClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, AuraBorder, RoundedCornerShape(16.dp))
            .testTag("moment_card_${moment.id}"),
        colors = CardDefaults.cardColors(containerColor = AuraSurface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header: Author, Time, Shared softly, Follow button, Mood Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(AuraVioletSecondary, AuraVioletDark)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = moment.authorInitial,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = moment.authorName,
                                color = AuraTextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                            if (!moment.authorName.contains("universe", ignoreCase = true) && !moment.authorName.contains("You", ignoreCase = true)) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (moment.isFollowingAuthor) "Following" else "+ Follow",
                                    color = if (moment.isFollowingAuthor) AuraLavender.copy(alpha = 0.7f) else AuraVioletPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { onFollowClick() }
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                        .testTag("follow_moment_author_${moment.id}")
                                )
                            }
                        }
                        Text(
                            text = "${moment.timeAgo} · ${moment.shareType}",
                            color = AuraTextMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                // Mood Pill Tag
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = moment.mood.accentColor.copy(alpha = 0.15f),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = Brush.horizontalGradient(
                            listOf(
                                moment.mood.accentColor.copy(alpha = 0.5f),
                                moment.mood.accentColor.copy(alpha = 0.2f)
                            )
                        )
                    )
                ) {
                    Text(
                        text = moment.mood.tagText,
                        color = moment.mood.accentColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Ambient Quote & Visual Frame
            Card(
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, AuraBorderLight, RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(containerColor = AuraSurfaceElevated)
            ) {
                Box(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Background image if provided
                    if (moment.drawableRes != null) {
                        Image(
                            painter = painterResource(id = moment.drawableRes),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                        )
                        // Dark scrim overlay for legibility
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color(0x990B0713),
                                            Color(0xDD0B0713)
                                        )
                                    )
                                )
                        )
                    } else {
                        // Ambient gradient background
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.linearGradient(
                                        listOf(AuraCardGradientStart, AuraCardGradientEnd)
                                    )
                                )
                                .padding(vertical = 24.dp)
                        )
                    }

                    // Content on top of background
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = moment.ambientHeader,
                            color = AuraTextSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )
                        val poemFontFamily = when (moment.fontOptionName) {
                            "PLAYFAIR" -> com.example.ui.theme.PlayfairDisplayFontFamily
                            "CINZEL" -> com.example.ui.theme.CinzelFontFamily
                            "CAVEAT" -> com.example.ui.theme.CaveatFontFamily
                            "CORMORANT" -> com.example.ui.theme.CormorantGaramondFontFamily
                            "SERIF" -> FontFamily.Serif
                            "MODERN" -> FontFamily.Default
                            else -> FontFamily.Serif
                        }

                        if (moment.isPoetry) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = AuraVioletDark.copy(alpha = 0.5f),
                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                    brush = Brush.horizontalGradient(listOf(AuraGold.copy(alpha = 0.5f), AuraVioletSecondary))
                                )
                            ) {
                                Text(
                                    text = "POETRY COMPOSITION · ${moment.fontOptionName}",
                                    color = AuraGold,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        Text(
                            text = moment.quoteText,
                            color = Color.White,
                            fontSize = if (moment.isPoetry) 19.sp else 17.sp,
                            fontWeight = FontWeight.Medium,
                            lineHeight = if (moment.isPoetry) 28.sp else 24.sp,
                            fontFamily = poemFontFamily
                        )

                        // Voice Note Audio Player inside Moment Card
                        if (moment.isVoiceNote) {
                            var isPlayingVoice by remember { mutableStateOf(false) }
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = AuraSurface.copy(alpha = 0.85f),
                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                    brush = Brush.horizontalGradient(listOf(AuraBorder, AuraVioletSecondary))
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .background(AuraVioletSecondary)
                                            .clickable { isPlayingVoice = !isPlayingVoice }
                                            .testTag("play_moment_voice_${moment.id}"),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isPlayingVoice) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            contentDescription = if (isPlayingVoice) "Pause Voice Note" else "Play Voice Note",
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.GraphicEq,
                                                contentDescription = null,
                                                tint = if (isPlayingVoice) AuraVioletPrimary else AuraTextMuted,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (isPlayingVoice) "Playing aura recording..." else "Voice Note",
                                                color = AuraTextPrimary,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "0:${String.format("%02d", moment.voiceDurationSec.coerceAtLeast(4))} · 432Hz",
                                            color = AuraTextMuted,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }
                        }

                        // Media attachment badge inside Moment Card
                        if (moment.mediaUri != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = AuraSurface.copy(alpha = 0.7f),
                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                    brush = Brush.horizontalGradient(listOf(AuraBorderLight, AuraBorderLight))
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (moment.mediaType == "video") Icons.Default.Videocam else Icons.Default.AddPhotoAlternate,
                                        contentDescription = null,
                                        tint = AuraLavender,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (moment.mediaType == "video") "Attached Video Clip" else "Attached Photo",
                                        color = AuraLavender,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Caption Text
            Text(
                text = moment.captionText,
                color = AuraTextSecondary,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                modifier = Modifier.padding(horizontal = 2.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Interactive Bottom Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Feel this (like/resonance)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { onFeelClick() }
                        .background(
                            if (moment.isFelt) AuraVioletDark.copy(alpha = 0.35f) else Color.Transparent
                        )
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("feel_moment_button_${moment.id}")
                ) {
                    Icon(
                        imageVector = if (moment.isFelt) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Feel this",
                        tint = if (moment.isFelt) AuraVioletPrimary else AuraTextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Feel this ${moment.feelCount}",
                        color = if (moment.isFelt) AuraVioletPrimary else AuraTextMuted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Leave a thought
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { onThoughtClick() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("thought_button_${moment.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.ChatBubbleOutline,
                        contentDescription = "Leave a thought",
                        tint = AuraTextMuted,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (moment.thoughts.isNotEmpty()) "Thoughts (${moment.thoughts.size})" else "Leave a thought",
                        color = AuraTextMuted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Keep this moment (save/bookmark)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { onKeepClick() }
                        .background(
                            if (moment.isKept) AuraSurfaceHighlight else Color.Transparent
                        )
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("keep_moment_button_${moment.id}")
                ) {
                    Icon(
                        imageVector = if (moment.isKept) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        contentDescription = "Keep this moment",
                        tint = if (moment.isKept) AuraGold else AuraTextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (moment.isKept) "Kept" else "Keep",
                        color = if (moment.isKept) AuraGold else AuraTextMuted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
fun CreateMomentDialog(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    onSave: (text: String, mood: MoodType, mediaUri: String?, mediaType: String?, isVoiceNote: Boolean, voiceSec: Int) -> Unit
) {
    if (!isOpen) return

    var momentText by remember { mutableStateOf("") }
    var selectedMood by remember { mutableStateOf(MoodType.RAINY) }
    var moodMenuExpanded by remember { mutableStateOf(false) }

    var attachedMediaUri by remember { mutableStateOf<String?>(null) }
    var attachedMediaType by remember { mutableStateOf<String?>(null) } // "photo" or "video"
    var isRecordingVoice by remember { mutableStateOf(false) }
    var voiceSeconds by remember { mutableIntStateOf(0) }
    var hasRecordedVoice by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            attachedMediaUri = uri.toString()
            attachedMediaType = "photo"
            hasRecordedVoice = false
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            attachedMediaUri = uri.toString()
            attachedMediaType = "video"
            hasRecordedVoice = false
        }
    }

    // Voice note recording timer
    LaunchedEffect(isRecordingVoice) {
        if (isRecordingVoice) {
            voiceSeconds = 0
            while (isRecordingVoice) {
                delay(1000)
                voiceSeconds++
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AuraSurface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AuraBorderLight, RoundedCornerShape(20.dp))
                .testTag("create_moment_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Create a moment",
                            color = AuraTextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "A quiet space for real feeling.",
                            color = AuraTextMuted,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = AuraTextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = momentText,
                    onValueChange = { momentText = it },
                    placeholder = {
                        Text(
                            text = if (hasRecordedVoice) "Voice frequency attached. Add optional thoughts..."
                            else if (attachedMediaUri != null) "Media attached. Add feeling or poetry..."
                            else "A small moment, a real feeling...",
                            color = AuraTextMuted,
                            fontSize = 14.sp
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .testTag("moment_input_text"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = AuraTextPrimary,
                        unfocusedTextColor = AuraTextPrimary,
                        focusedContainerColor = AuraSurfaceElevated,
                        unfocusedContainerColor = AuraSurfaceElevated,
                        focusedBorderColor = AuraVioletPrimary,
                        unfocusedBorderColor = AuraBorder
                    )
                )

                // Voice Recording Live Indicator
                if (isRecordingVoice) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF2A1015),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = Brush.horizontalGradient(listOf(Color(0xFFE53935), Color(0xFFFF5252)))
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFFF5252))
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Recording Voice Note... 0:${String.format("%02d", voiceSeconds)}",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            TextButton(
                                onClick = {
                                    isRecordingVoice = false
                                    hasRecordedVoice = true
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Done", color = Color(0xFFFF8A80), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                } else if (hasRecordedVoice) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = AuraSurfaceElevated,
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = Brush.horizontalGradient(listOf(AuraBorder, AuraVioletSecondary))
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Mic, contentDescription = null, tint = AuraVioletPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Voice Note Attached (0:${String.format("%02d", voiceSeconds.coerceAtLeast(3))})",
                                    color = AuraLavender,
                                    fontSize = 12.sp
                                )
                            }
                            IconButton(onClick = { hasRecordedVoice = false; voiceSeconds = 0 }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Remove voice note", tint = AuraTextMuted, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }

                // Media Attachment Indicator
                if (attachedMediaUri != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = AuraSurfaceElevated,
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = Brush.horizontalGradient(listOf(AuraBorder, AuraVioletSecondary))
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (attachedMediaType == "video") Icons.Default.Videocam else Icons.Default.AddPhotoAlternate,
                                    contentDescription = null,
                                    tint = AuraVioletPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (attachedMediaType == "video") "Video Clip Attached ✓" else "Photo Attached ✓",
                                    color = AuraLavender,
                                    fontSize = 12.sp
                                )
                            }
                            IconButton(onClick = { attachedMediaUri = null; attachedMediaType = null }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Remove media", tint = AuraTextMuted, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Media & Voice Tool Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Upload Photo
                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = AuraSurfaceElevated, contentColor = AuraLavender),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = Brush.horizontalGradient(listOf(AuraBorder, AuraBorderLight))
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .testTag("upload_photo_moment_button")
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = AuraVioletPrimary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ Photo", fontSize = 11.sp, maxLines = 1)
                    }

                    // Upload Video
                    OutlinedButton(
                        onClick = {
                            videoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = AuraSurfaceElevated, contentColor = AuraLavender),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = Brush.horizontalGradient(listOf(AuraBorder, AuraBorderLight))
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp)
                            .testTag("upload_video_moment_button")
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = null, tint = AuraVioletPrimary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("+ Video", fontSize = 11.sp, maxLines = 1)
                    }

                    // Record Voice Note
                    OutlinedButton(
                        onClick = {
                            if (!isRecordingVoice) {
                                isRecordingVoice = true
                            } else {
                                isRecordingVoice = false
                                hasRecordedVoice = true
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (isRecordingVoice) Color(0xFF3B1218) else AuraSurfaceElevated,
                            contentColor = if (isRecordingVoice) Color(0xFFFF5252) else AuraLavender
                        ),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = Brush.horizontalGradient(
                                listOf(
                                    if (isRecordingVoice) Color(0xFFFF5252) else AuraBorder,
                                    if (isRecordingVoice) Color(0xFFFF1744) else AuraBorderLight
                                )
                            )
                        ),
                        modifier = Modifier
                            .weight(1.1f)
                            .height(34.dp)
                            .testTag("record_voice_note_button")
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = null, tint = if (isRecordingVoice) Color(0xFFFF5252) else AuraVioletPrimary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isRecordingVoice) "Stop" else "+ Voice Note", fontSize = 11.sp, maxLines = 1)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Mood selector dropdown
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Mood",
                        color = AuraTextMuted,
                        fontSize = 13.sp
                    )

                    Box {
                        OutlinedButton(
                            onClick = { moodMenuExpanded = true },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = AuraSurfaceElevated,
                                contentColor = AuraLavender
                            ),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = Brush.horizontalGradient(listOf(AuraBorder, AuraVioletSecondary))
                            ),
                            modifier = Modifier.testTag("mood_selector_button")
                        ) {
                            Text(
                                text = "${selectedMood.symbolEmoji}  ${selectedMood.title}",
                                fontSize = 13.sp
                            )
                        }

                        DropdownMenu(
                            expanded = moodMenuExpanded,
                            onDismissRequest = { moodMenuExpanded = false },
                            modifier = Modifier.background(AuraSurfaceElevated)
                        ) {
                            MoodType.values().forEach { mood ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = "${mood.symbolEmoji}  ${mood.title}",
                                            color = AuraTextPrimary,
                                            fontSize = 13.sp
                                        )
                                    },
                                    onClick = {
                                        selectedMood = mood
                                        moodMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = onDismiss,
                        colors = ButtonDefaults.textButtonColors(contentColor = AuraTextMuted)
                    ) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (momentText.isNotBlank() || attachedMediaUri != null || hasRecordedVoice) {
                                onSave(
                                    momentText,
                                    selectedMood,
                                    attachedMediaUri,
                                    attachedMediaType,
                                    hasRecordedVoice,
                                    voiceSeconds.coerceAtLeast(3)
                                )
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AuraVioletSecondary,
                            contentColor = Color.White
                        ),
                        modifier = Modifier.testTag("save_moment_button")
                    ) {
                        Text(
                            text = "Save moment",
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CreateMomentDialog(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    onSave: (text: String, mood: MoodType) -> Unit
) {
    CreateMomentDialog(
        isOpen = isOpen,
        onDismiss = onDismiss,
        onSave = { text, mood, _, _, _, _ -> onSave(text, mood) }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThoughtCommentsSheet(
    moment: Moment?,
    onDismiss: () -> Unit,
    onAddThought: (String) -> Unit
) {
    if (moment == null) return

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var newThought by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = AuraSurface,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .windowInsetsPadding(WindowInsets.navigationBars)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Thoughts on this moment",
                    color = AuraTextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = AuraTextMuted)
                }
            }

            Text(
                text = "\"${moment.quoteText}\"",
                color = AuraLavender,
                fontSize = 13.sp,
                fontFamily = FontFamily.Serif,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Comments List
            if (moment.thoughts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No thoughts left yet. Be the first gentle voice.",
                        color = AuraTextMuted,
                        fontSize = 13.sp
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 240.dp)
                ) {
                    items(moment.thoughts) { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(AuraSurfaceHighlight),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = item.authorInitial,
                                    color = AuraLavender,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = item.author,
                                        color = AuraTextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = item.timeAgo,
                                        color = AuraTextMuted,
                                        fontSize = 10.sp
                                    )
                                }
                                Text(
                                    text = item.text,
                                    color = AuraTextSecondary,
                                    fontSize = 13.sp,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Input field
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = newThought,
                    onValueChange = { newThought = it },
                    placeholder = { Text("Leave a gentle thought...", color = AuraTextMuted, fontSize = 13.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("thought_comment_input"),
                    shape = RoundedCornerShape(20.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = AuraTextPrimary,
                        unfocusedTextColor = AuraTextPrimary,
                        focusedContainerColor = AuraSurfaceElevated,
                        unfocusedContainerColor = AuraSurfaceElevated,
                        focusedBorderColor = AuraVioletPrimary,
                        unfocusedBorderColor = AuraBorder
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (newThought.isNotBlank()) {
                            onAddThought(newThought)
                            newThought = ""
                        }
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(AuraVioletSecondary)
                        .testTag("submit_thought_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send thought",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun SymbolDetailDialog(
    symbol: AuraSymbol?,
    onDismiss: () -> Unit
) {
    if (symbol == null) return

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AuraSurface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AuraBorderLight, RoundedCornerShape(20.dp))
                .padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(listOf(AuraVioletSecondary, AuraVioletDark))
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = symbol.symbolChar,
                        fontSize = 28.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = symbol.title,
                    color = AuraTextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = symbol.subtitle,
                    color = AuraVioletPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = symbol.description,
                    color = AuraTextSecondary,
                    fontSize = 14.sp,
                    lineHeight = 20.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AuraSurfaceHighlight)
                ) {
                    Text("Understood", color = AuraLavender)
                }
            }
        }
    }
}
