package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.model.MoodType
import com.example.model.ReelItem
import com.example.ui.components.ThoughtCommentsSheet
import com.example.ui.theme.AuraBackground
import com.example.ui.theme.AuraBorder
import com.example.ui.theme.AuraBorderLight
import com.example.ui.theme.AuraGold
import com.example.ui.theme.AuraLavender
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraSurfaceHighlight
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletDark
import com.example.ui.theme.AuraVioletPrimary
import com.example.ui.theme.AuraVioletSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ReelsScreen(
    reels: List<ReelItem>,
    onFeelReel: (String) -> Unit,
    onKeepReel: (String) -> Unit,
    onFollowAuthor: (String) -> Unit,
    onOpenThoughts: (ReelItem) -> Unit,
    onOpenCreateReel: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedReelTab by remember { mutableStateOf("For you") } // "For you", "Following"

    val displayedReels = remember(reels, selectedReelTab) {
        if (selectedReelTab == "Following") {
            val followingOnly = reels.filter { it.isFollowingAuthor }
            if (followingOnly.isEmpty()) reels else followingOnly
        } else {
            reels
        }
    }

    val pagerState = rememberPagerState(pageCount = { displayedReels.size })

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("reels_screen")
    ) {
        if (displayedReels.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No reels in this stream yet.",
                    color = AuraTextMuted,
                    fontSize = 14.sp
                )
            }
        } else {
            VerticalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize()
            ) { page ->
                val reel = displayedReels[page]
                ReelPageItem(
                    reel = reel,
                    onFeel = { onFeelReel(reel.id) },
                    onKeep = { onKeepReel(reel.id) },
                    onFollow = { onFollowAuthor(reel.authorName) },
                    onThoughts = { onOpenThoughts(reel) }
                )
            }
        }

        // Top Navigation overlay (For you / Following & Create Reel)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Following",
                    color = if (selectedReelTab == "Following") Color.White else Color.White.copy(alpha = 0.6f),
                    fontSize = 15.sp,
                    fontWeight = if (selectedReelTab == "Following") FontWeight.Bold else FontWeight.Medium,
                    modifier = Modifier
                        .clickable { selectedReelTab = "Following" }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("reels_tab_following")
                )

                Text(
                    text = "|",
                    color = Color.White.copy(alpha = 0.4f),
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )

                Text(
                    text = "For You",
                    color = if (selectedReelTab == "For you") Color.White else Color.White.copy(alpha = 0.6f),
                    fontSize = 15.sp,
                    fontWeight = if (selectedReelTab == "For you") FontWeight.Bold else FontWeight.Medium,
                    modifier = Modifier
                        .clickable { selectedReelTab = "For you" }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("reels_tab_for_you")
                )
            }

            // Create Reel button
            OutlinedButton(
                onClick = onOpenCreateReel,
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = Color.Black.copy(alpha = 0.5f),
                    contentColor = Color.White
                ),
                border = ButtonDefaults.outlinedButtonBorder.copy(
                    brush = Brush.horizontalGradient(listOf(AuraVioletSecondary, AuraVioletPrimary))
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                modifier = Modifier
                    .height(32.dp)
                    .testTag("create_reel_top_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("New Reel", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun ReelPageItem(
    reel: ReelItem,
    onFeel: () -> Unit,
    onKeep: () -> Unit,
    onFollow: () -> Unit,
    onThoughts: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isPlaying by remember { mutableStateOf(true) }
    var showHeartBurst by remember { mutableStateOf(false) }
    var showShareNotice by remember { mutableStateOf(false) }
    var captionExpanded by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()
    val rotation = remember { Animatable(0f) }

    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            rotation.animateTo(
                targetValue = rotation.value + 360f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 4000, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                )
            )
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = {
                        if (!reel.isFelt) onFeel()
                        showHeartBurst = true
                        coroutineScope.launch {
                            delay(800)
                            showHeartBurst = false
                        }
                    },
                    onTap = {
                        isPlaying = !isPlaying
                    }
                )
            }
    ) {
        // Reel Video / Visual Artwork
        Image(
            painter = painterResource(id = reel.drawableRes),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Dark Vignette Gradients for readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.Black.copy(alpha = 0.55f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.85f)
                        )
                    )
                )
        )

        // Heart Burst Animation on Double Tap
        AnimatedVisibility(
            visible = showHeartBurst,
            enter = scaleIn(tween(250)) + fadeIn(),
            exit = scaleOut(tween(350)) + fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Icon(
                imageVector = Icons.Default.Favorite,
                contentDescription = null,
                tint = AuraVioletPrimary,
                modifier = Modifier.size(90.dp)
            )
        }

        // Pause indicator if paused
        if (!isPlaying) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .align(Alignment.Center),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Paused",
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        // Bottom Details & Floating Action Rail
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(horizontal = 16.dp, vertical = 24.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left info (Author, Caption, Sound, Mood)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 16.dp)
            ) {
                // Author row with follow button
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = reel.authorName,
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = reel.authorHandle,
                        color = AuraLavender.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    // Follow Button
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (reel.isFollowingAuthor) Color.Black.copy(alpha = 0.4f) else AuraVioletSecondary,
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = Brush.horizontalGradient(
                                listOf(
                                    if (reel.isFollowingAuthor) AuraBorderLight else AuraVioletPrimary,
                                    AuraVioletSecondary
                                )
                            )
                        ),
                        modifier = Modifier
                            .clickable { onFollow() }
                            .testTag("reel_follow_button_${reel.id}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            if (reel.isFollowingAuthor) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = AuraLavender,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Following",
                                    color = AuraLavender,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Follow",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Caption
                Text(
                    text = reel.caption,
                    color = Color.White.copy(alpha = 0.95f),
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    maxLines = if (captionExpanded) 6 else 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.clickable { captionExpanded = !captionExpanded }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Audio Track Pill
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.Black.copy(alpha = 0.5f)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = AuraVioletPrimary,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = reel.audioTrack,
                            color = Color.White,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Right Action Rail (Avatar, Feel, Thoughts, Keep, Share, Disc)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Creator Avatar
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(listOf(AuraVioletSecondary, AuraVioletDark))
                        )
                        .border(1.5.dp, AuraVioletPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = reel.authorInitial,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }

                // Feel Button
                ReelActionButton(
                    icon = if (reel.isFelt) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    label = "${reel.feelCount}",
                    tint = if (reel.isFelt) AuraVioletPrimary else Color.White,
                    onClick = onFeel,
                    testTag = "reel_feel_button_${reel.id}"
                )

                // Thoughts Button
                ReelActionButton(
                    icon = Icons.Default.ChatBubble,
                    label = "${reel.thoughts.size}",
                    tint = Color.White,
                    onClick = onThoughts,
                    testTag = "reel_thought_button_${reel.id}"
                )

                // Keep Button
                ReelActionButton(
                    icon = if (reel.isKept) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    label = if (reel.isKept) "Kept" else "Keep",
                    tint = if (reel.isKept) AuraGold else Color.White,
                    onClick = onKeep,
                    testTag = "reel_keep_button_${reel.id}"
                )

                // Share Button
                ReelActionButton(
                    icon = Icons.Default.Share,
                    label = "Echo",
                    tint = Color.White,
                    onClick = {
                        showShareNotice = true
                        coroutineScope.launch {
                            delay(1500)
                            showShareNotice = false
                        }
                    },
                    testTag = "reel_share_button_${reel.id}"
                )

                // Rotating Audio Vinyl Disc
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .rotate(rotation.value)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(listOf(AuraSurfaceHighlight, Color.Black))
                        )
                        .border(1.dp, AuraVioletSecondary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = null,
                        tint = AuraVioletPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // Shared Notice Toast
        AnimatedVisibility(
            visible = showShareNotice,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 60.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = AuraSurfaceElevated,
                border = ButtonDefaults.outlinedButtonBorder.copy(
                    brush = Brush.horizontalGradient(listOf(AuraBorder, AuraVioletSecondary))
                )
            ) {
                Text(
                    text = "Aura Reel echoed to your circle ✨",
                    color = AuraLavender,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun ReelActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(CircleShape)
            .clickable { onClick() }
            .padding(4.dp)
            .testTag(testTag)
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.45f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun CreateReelDialog(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    onCreate: (caption: String, audioTrack: String, mood: MoodType, visualRes: Int) -> Unit
) {
    if (!isOpen) return

    var caption by remember { mutableStateOf("") }
    var audioTrack by remember { mutableStateOf("Ambient Rain & Piano · 432Hz") }
    var selectedMood by remember { mutableStateOf(MoodType.RAINY) }
    var selectedVisual by remember { mutableStateOf(R.drawable.reel_midnight_fog) }
    var moodMenuExpanded by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AuraSurface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AuraBorderLight, RoundedCornerShape(20.dp))
                .testTag("create_reel_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Create Aura Reel",
                        color = AuraTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Add, contentDescription = "Close", tint = AuraTextMuted, modifier = Modifier.rotate(45f))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it },
                    placeholder = { Text("What movement or feeling does this hold?...", color = AuraTextMuted, fontSize = 13.sp) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .testTag("reel_caption_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = AuraTextPrimary,
                        unfocusedTextColor = AuraTextPrimary,
                        focusedContainerColor = AuraSurfaceElevated,
                        unfocusedContainerColor = AuraSurfaceElevated,
                        focusedBorderColor = AuraVioletPrimary,
                        unfocusedBorderColor = AuraBorder
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = audioTrack,
                    onValueChange = { audioTrack = it },
                    label = { Text("Ambient Audio Track", color = AuraTextMuted, fontSize = 11.sp) },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = AuraTextPrimary,
                        unfocusedTextColor = AuraTextPrimary,
                        focusedContainerColor = AuraSurfaceElevated,
                        unfocusedContainerColor = AuraSurfaceElevated,
                        focusedBorderColor = AuraVioletPrimary,
                        unfocusedBorderColor = AuraBorder
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Visual Theme Chooser & Upload
                var hasCustomUpload by remember { mutableStateOf(false) }
                val reelPickerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.PickVisualMedia()
                ) { uri: Uri? ->
                    if (uri != null) {
                        hasCustomUpload = true
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Atmospheric Backdrop", color = AuraTextMuted, fontSize = 12.sp)
                    TextButton(
                        onClick = {
                            reelPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                            )
                        },
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text(
                            text = if (hasCustomUpload) "Uploaded from Gallery ✓" else "+ Upload from Gallery",
                            color = AuraVioletPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val visuals = listOf(
                        "Midnight Rain" to R.drawable.reel_midnight_fog,
                        "Golden Tide" to R.drawable.reel_golden_dusk
                    )
                    visuals.forEach { (name, res) ->
                        val isSelected = selectedVisual == res && !hasCustomUpload
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) AuraVioletSecondary else AuraSurfaceElevated,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    selectedVisual = res
                                    hasCustomUpload = false
                                }
                        ) {
                            Text(
                                text = name,
                                color = if (isSelected) Color.White else AuraTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                modifier = Modifier.padding(vertical = 10.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = AuraTextMuted)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (caption.isNotBlank()) {
                                onCreate(caption, audioTrack, selectedMood, selectedVisual)
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AuraVioletSecondary),
                        modifier = Modifier.testTag("publish_reel_button")
                    ) {
                        Text("Publish Reel", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
