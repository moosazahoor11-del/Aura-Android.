package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Moment
import com.example.model.Story
import com.example.ui.FeedStreamMode
import com.example.ui.components.MomentCard
import com.example.ui.components.ThoughtCommentsSheet
import com.example.ui.theme.AuraBackground
import com.example.ui.theme.AuraBorder
import com.example.ui.theme.AuraBorderLight
import com.example.ui.theme.AuraGold
import com.example.ui.theme.AuraLavender
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraSurfaceHighlight
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletDark
import com.example.ui.theme.AuraVioletPrimary
import com.example.ui.theme.AuraVioletSecondary

@Composable
fun FeedScreen(
    moments: List<Moment>,
    stories: List<Story>,
    feedStreamMode: FeedStreamMode,
    onStreamModeChange: (FeedStreamMode) -> Unit,
    onFollowAuthor: (String) -> Unit,
    onFeelMoment: (String) -> Unit,
    onKeepMoment: (String) -> Unit,
    onAddThought: (String, String) -> Unit,
    onOpenCreateMoment: () -> Unit,
    onOpenStory: (String) -> Unit,
    onNavigateToReels: () -> Unit,
    onOpenComposePoetry: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedMomentForThoughts by remember { mutableStateOf<Moment?>(null) }

    val filteredMoments = remember(moments, feedStreamMode) {
        if (feedStreamMode == FeedStreamMode.FOLLOWING) {
            val followingList = moments.filter { it.isFollowingAuthor || it.authorName.contains("universe") }
            if (followingList.isEmpty()) moments else followingList
        } else {
            moments
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AuraBackground)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            // Top Feed Stream Switcher: For You | Following
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = AuraSurfaceElevated,
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = Brush.horizontalGradient(listOf(AuraBorder, AuraBorderLight))
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val isForYou = feedStreamMode == FeedStreamMode.FOR_YOU
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (isForYou) AuraVioletSecondary else Color.Transparent)
                                    .clickable { onStreamModeChange(FeedStreamMode.FOR_YOU) }
                                    .padding(horizontal = 18.dp, vertical = 6.dp)
                                    .testTag("feed_stream_for_you"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "For You",
                                    color = if (isForYou) Color.White else AuraTextMuted,
                                    fontSize = 12.sp,
                                    fontWeight = if (isForYou) FontWeight.Bold else FontWeight.Medium
                                )
                            }

                            val isFollowing = feedStreamMode == FeedStreamMode.FOLLOWING
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (isFollowing) AuraVioletSecondary else Color.Transparent)
                                    .clickable { onStreamModeChange(FeedStreamMode.FOLLOWING) }
                                    .padding(horizontal = 18.dp, vertical = 6.dp)
                                    .testTag("feed_stream_following"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Following",
                                    color = if (isFollowing) Color.White else AuraTextMuted,
                                    fontSize = 12.sp,
                                    fontWeight = if (isFollowing) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }

            // Your circle Header & Story avatars
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Your circle",
                        color = AuraTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "YOUR CIRCLE",
                        color = AuraTextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // + Your story circle
                    item {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onOpenCreateMoment() }
                                .padding(4.dp)
                                .testTag("add_story_item")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .border(1.5.dp, AuraVioletPrimary, CircleShape)
                                    .background(AuraSurfaceElevated),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Add your story",
                                    tint = AuraVioletPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Your story",
                                color = AuraTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Circle story items
                    items(stories) { story ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onOpenStory(story.id) }
                                .padding(4.dp)
                                .testTag("story_item_${story.id}")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .border(
                                        width = if (!story.isViewed) 2.dp else 1.dp,
                                        brush = if (!story.isViewed) {
                                            Brush.sweepGradient(
                                                listOf(
                                                    story.mood.accentColor,
                                                    AuraVioletPrimary,
                                                    story.mood.accentColor
                                                )
                                            )
                                        } else {
                                            Brush.linearGradient(listOf(AuraBorder, AuraBorder))
                                        },
                                        shape = CircleShape
                                    )
                                    .background(AuraSurfaceHighlight),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = story.mood.symbolEmoji,
                                    fontSize = 20.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = story.circleTag,
                                color = if (!story.isViewed) AuraLavender else AuraTextMuted,
                                fontSize = 11.sp,
                                fontWeight = if (!story.isViewed) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Quick Composer Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = AuraSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AuraBorder, RoundedCornerShape(16.dp))
                        .testTag("feed_composer_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onOpenCreateMoment() }
                                .padding(vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(listOf(AuraVioletSecondary, AuraVioletDark))
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "M",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "What does this moment feel like?",
                                color = AuraTextMuted,
                                fontSize = 14.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row {
                                OutlinedButton(
                                    onClick = { onOpenCreateMoment() },
                                    shape = RoundedCornerShape(20.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = AuraSurfaceElevated,
                                        contentColor = AuraLavender
                                    ),
                                    border = ButtonDefaults.outlinedButtonBorder.copy(
                                        brush = Brush.horizontalGradient(listOf(AuraBorder, AuraBorder))
                                    ),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Image,
                                        contentDescription = null,
                                        tint = AuraTextMuted,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = "Add a visual", fontSize = 11.sp)
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                OutlinedButton(
                                    onClick = { onOpenCreateMoment() },
                                    shape = RoundedCornerShape(20.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = AuraSurfaceElevated,
                                        contentColor = AuraLavender
                                    ),
                                    border = ButtonDefaults.outlinedButtonBorder.copy(
                                        brush = Brush.horizontalGradient(listOf(AuraBorder, AuraBorder))
                                    ),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Mood,
                                        contentDescription = null,
                                        tint = AuraTextMuted,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = "Add a mood", fontSize = 11.sp)
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                OutlinedButton(
                                    onClick = onOpenComposePoetry,
                                    shape = RoundedCornerShape(20.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = AuraVioletDark.copy(alpha = 0.5f),
                                        contentColor = AuraGold
                                    ),
                                    border = ButtonDefaults.outlinedButtonBorder.copy(
                                        brush = Brush.horizontalGradient(listOf(AuraGold.copy(alpha = 0.6f), AuraVioletSecondary))
                                    ),
                                    modifier = Modifier
                                        .height(32.dp)
                                        .testTag("feed_compose_poetry_button")
                                ) {
                                    Text(
                                        text = "Poetry ✨",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Button(
                                onClick = onOpenCreateMoment,
                                shape = RoundedCornerShape(20.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AuraVioletSecondary,
                                    contentColor = Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("feed_create_moment_button")
                            ) {
                                Text(
                                    text = "Create moment",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
            }

            // Cinematic Compose Poetry Sanctuary Banner
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = AuraSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = 1.dp,
                            brush = Brush.horizontalGradient(
                                listOf(
                                    AuraGold.copy(alpha = 0.4f),
                                    AuraBorder,
                                    AuraVioletSecondary.copy(alpha = 0.5f)
                                )
                            ),
                            shape = RoundedCornerShape(16.dp)
                        )
                        .clickable { onOpenComposePoetry() }
                        .testTag("feed_poetry_sanctuary_banner")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            listOf(AuraVioletDark, AuraVioletPrimary)
                                        )
                                    )
                                    .border(1.dp, AuraGold.copy(alpha = 0.6f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "✍",
                                    fontSize = 16.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Poetic Sanctuary",
                                        color = AuraTextPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Serif
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "NEW",
                                        color = AuraGold,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                }
                                Text(
                                    text = "Minimalist cinematic canvas · custom poetry fonts",
                                    color = AuraTextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = AuraVioletSecondary.copy(alpha = 0.35f),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = Brush.horizontalGradient(listOf(AuraVioletPrimary, AuraVioletSecondary))
                            )
                        ) {
                            Text(
                                text = "Compose",
                                color = AuraLavender,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
            }

            // Quick Reels Banner
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = AuraSurfaceElevated),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AuraBorder, RoundedCornerShape(16.dp))
                        .clickable { onNavigateToReels() }
                        .testTag("feed_reels_banner")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(listOf(AuraVioletSecondary, AuraVioletDark))
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Aura Motion Reels",
                                    color = AuraTextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Immersive atmospheric video & rain audio loops",
                                    color = AuraTextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Text(
                            text = "Watch 🎬",
                            color = AuraVioletPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))
            }

            // Made of moments Section Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (feedStreamMode == FeedStreamMode.FOLLOWING) "Following moments" else "Made of moments",
                        color = AuraTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif
                    )
                    Text(
                        text = "AURA / 01",
                        color = AuraTextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = 1.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            // Moments Feed List
            items(filteredMoments) { moment ->
                MomentCard(
                    moment = moment,
                    onFeelClick = { onFeelMoment(moment.id) },
                    onKeepClick = { onKeepMoment(moment.id) },
                    onThoughtClick = { selectedMomentForThoughts = moment },
                    onFollowClick = { onFollowAuthor(moment.authorName) },
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }
        }

        // Thoughts Bottom Sheet
        if (selectedMomentForThoughts != null) {
            ThoughtCommentsSheet(
                moment = selectedMomentForThoughts,
                onDismiss = { selectedMomentForThoughts = null },
                onAddThought = { text ->
                    selectedMomentForThoughts?.let { m ->
                        onAddThought(m.id, text)
                        selectedMomentForThoughts = moments.find { it.id == m.id }
                    }
                }
            )
        }
    }
}
