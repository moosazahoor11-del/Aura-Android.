package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aura Cosmic Dark Theme Palette
val AuraBackground = Color(0xFF0B0713)
val AuraSurface = Color(0xFF140D22)
val AuraSurfaceElevated = Color(0xFF1B112E)
val AuraSurfaceHighlight = Color(0xFF26183F)
val AuraBorder = Color(0xFF332154)
val AuraBorderLight = Color(0xFF4C3078)

// Accent & Luminous Colors
val AuraVioletPrimary = Color(0xFFC084FC)
val AuraVioletSecondary = Color(0xFFA855F7)
val AuraVioletDark = Color(0xFF7E22CE)
val AuraLavender = Color(0xFFE9D5FF)

val AuraGold = Color(0xFFF59E0B)
val AuraGoldLight = Color(0xFFFDE68A)
val AuraSkyBlue = Color(0xFF38BDF8)
val AuraRose = Color(0xFFF472B6)
val AuraEmerald = Color(0xFF34D399)

// Text Colors
val AuraTextPrimary = Color(0xFFF8FAFC)
val AuraTextSecondary = Color(0xFFC4B5FD)
val AuraTextMuted = Color(0xFF8B7AA8)

// Ambient Gradients
val AuraCardGradientStart = Color(0xFF281442)
val AuraCardGradientEnd = Color(0xFF120A1E)
val AuraSunsetGradientStart = Color(0xFF44243A)
val AuraSunsetGradientEnd = Color(0xFF1F122B)
