package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.AuraSampleData
import com.example.model.AuraSymbol
import com.example.model.BondGardenItem
import com.example.model.BondStreakItem
import com.example.model.ChatMessage
import com.example.model.InboxThread
import com.example.model.Moment
import com.example.model.MoodType
import com.example.model.ReelItem
import com.example.model.SoulProfile
import com.example.model.Story
import com.example.model.ThoughtComment
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

enum class AuraTab(val label: String, val iconDesc: String) {
    FEED("Feed", "Explore Moments"),
    REELS("Reels", "Aura Motion Reels"),
    DISCOVER("Discover", "Discover Souls"),
    STUDIO("Studio", "Aura Intelligence Studio"),
    INBOX("Inbox", "Mood Inbox"),
    ME("Me", "Your Aura")
}

enum class FeedStreamMode {
    FOR_YOU,
    FOLLOWING
}

data class AuraUiState(
    val currentTab: AuraTab = AuraTab.FEED,
    val feedStreamMode: FeedStreamMode = FeedStreamMode.FOR_YOU,
    val moments: List<Moment> = emptyList(),
    val stories: List<Story> = emptyList(),
    val reels: List<ReelItem> = emptyList(),
    val activeReelIndex: Int = 0,
    val souls: List<SoulProfile> = emptyList(),
    val discoverFilter: String = "For you",
    val threads: List<InboxThread> = emptyList(),
    val activeThreadId: String? = null,
    val activeStoryId: String? = null,
    val selectedSoulId: String? = null,
    val selectedSymbol: AuraSymbol? = null,
    val isCreateMomentDialogOpen: Boolean = false,
    val isCreateReelDialogOpen: Boolean = false,
    val isFollowingListDialogOpen: Boolean = false,
    val isFollowersListDialogOpen: Boolean = false,
    val selectedReelForThoughts: ReelItem? = null,
    val isSearchOpen: Boolean = false,
    val activeCall: com.example.model.ActiveCall? = null,
    // Studio State
    val studioPrompt: String = "",
    val studioMood: MoodType = MoodType.RAINY,
    val studioVisualRes: Int? = R.drawable.ambient_rainy_glow,
    val isSynthesizing: Boolean = false,
    val synthesizedMoment: Moment? = null,
    // Profile & Streaks State
    val creationStreakDays: Int = 1,
    val hasCheckedInToday: Boolean = false,
    val bondStreaks: List<BondStreakItem> = emptyList(),
    val bondGarden: List<BondGardenItem> = emptyList(),
    val rotatingAuraId: String = "AU-970-249",
    val auraIdTimeRemaining: String = "23:56:30",
    val userName: String = "Moosa Zahoor",
    val userHandle: String = "@moosa_aura",
    val userEmail: String = "moosa@aura.soul",
    val userBio: String = "Collecting moments, not numbers. Floating in ambient quietude.",
    val userAvatarUri: String? = null,
    val userPersonalityArchetype: String = "The Nocturnal Poet",
    val userPersonalityAesthetic: String = "Midnight rain, warm cinnamon tea & lofi frequencies",
    val userPersonalityTags: List<String> = listOf("Poetry", "Nocturnal Rain", "Ambient 432Hz", "Late Thoughts", "Quiet Art"),
    val userPrimaryMood: MoodType = MoodType.RAINY,
    val isSignedIn: Boolean = true,
    val isSignInDialogOpen: Boolean = false,
    val isEditProfileDialogOpen: Boolean = false,
    val isDemoAccountModalOpen: Boolean = false,
    val isOpeningAnimationVisible: Boolean = true,
    val isComposePoetryOpen: Boolean = false
)

class AuraViewModel(
    private val firestoreRepository: com.example.data.firebase.AuraFirestoreRepository? = null
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        AuraUiState(
            moments = AuraSampleData.initialMoments(),
            stories = AuraSampleData.initialStories(),
            reels = AuraSampleData.initialReels(),
            souls = AuraSampleData.initialSouls(),
            threads = AuraSampleData.initialThreads(),
            bondStreaks = AuraSampleData.initialStreaks(),
            bondGarden = AuraSampleData.initialBonds()
        )
    )
    val uiState: StateFlow<AuraUiState> = _uiState.asStateFlow()

    init {
        if (firestoreRepository != null) {
            viewModelScope.launch {
                try {
                    firestoreRepository.observeMoments().collect { cloudMoments ->
                        if (cloudMoments.isNotEmpty()) {
                            val mapped = cloudMoments.map { cm ->
                                Moment(
                                    id = cm.id,
                                    authorName = cm.authorName,
                                    authorHandle = cm.authorHandle,
                                    authorInitial = cm.authorName.take(1).uppercase(),
                                    timeAgo = "Cloud sync",
                                    shareType = if (cm.isPoetry) "Poetry Composition" else "Felt Moment",
                                    mood = runCatching { MoodType.valueOf(cm.mood) }.getOrDefault(MoodType.RAINY),
                                    ambientHeader = if (cm.isPoetry) "POETIC EXPRESSION" else "QUIET FREQUENCY",
                                    quoteText = cm.text,
                                    captionText = "Echoed through nocturnal frequencies",
                                    feelCount = cm.feelCount.toInt(),
                                    mediaUri = cm.mediaUri,
                                    mediaType = cm.mediaType,
                                    isVoiceNote = cm.isVoiceNote,
                                    voiceDurationSec = cm.voiceDurationSec,
                                    isPoetry = cm.isPoetry,
                                    fontOptionName = cm.fontOptionName
                                )
                            }
                            _uiState.update { state ->
                                val combined = (mapped + state.moments).distinctBy { it.id }
                                state.copy(moments = combined)
                            }
                        }
                    }
                } catch (e: Exception) {
                    android.util.Log.w("AuraViewModel", "Error observing cloud moments", e)
                }
            }
        }
    }

    fun selectTab(tab: AuraTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun setFeedStreamMode(mode: FeedStreamMode) {
        _uiState.update { it.copy(feedStreamMode = mode) }
    }

    // Following System
    fun toggleFollowAuthor(authorName: String) {
        _uiState.update { state ->
            val updatedSouls = state.souls.map { soul ->
                if (soul.name.equals(authorName, ignoreCase = true) || authorName.contains(soul.name, ignoreCase = true)) {
                    val newFollowing = !soul.isFollowing
                    val newCount = if (newFollowing) soul.followersCount + 1 else (soul.followersCount - 1).coerceAtLeast(0)
                    soul.copy(isFollowing = newFollowing, followersCount = newCount)
                } else soul
            }

            val isNowFollowing = updatedSouls.firstOrNull {
                it.name.equals(authorName, ignoreCase = true) || authorName.contains(it.name, ignoreCase = true)
            }?.isFollowing ?: true

            val updatedMoments = state.moments.map { m ->
                if (m.authorName.contains(authorName, ignoreCase = true) || authorName.contains(m.authorName, ignoreCase = true)) {
                    m.copy(isFollowingAuthor = isNowFollowing)
                } else m
            }

            val updatedReels = state.reels.map { r ->
                if (r.authorName.equals(authorName, ignoreCase = true) || authorName.contains(r.authorName, ignoreCase = true)) {
                    r.copy(isFollowingAuthor = isNowFollowing)
                } else r
            }

            state.copy(
                souls = updatedSouls,
                moments = updatedMoments,
                reels = updatedReels
            )
        }
    }

    fun toggleFollowSoul(soulId: String) {
        val soul = _uiState.value.souls.find { it.id == soulId } ?: return
        toggleFollowAuthor(soul.name)
    }

    fun openFollowingList() {
        _uiState.update { it.copy(isFollowingListDialogOpen = true) }
    }

    fun closeFollowingList() {
        _uiState.update { it.copy(isFollowingListDialogOpen = false) }
    }

    fun openFollowersList() {
        _uiState.update { it.copy(isFollowersListDialogOpen = true) }
    }

    fun closeFollowersList() {
        _uiState.update { it.copy(isFollowersListDialogOpen = false) }
    }

    // Reels System
    fun toggleFeelReel(reelId: String) {
        _uiState.update { state ->
            val updated = state.reels.map { r ->
                if (r.id == reelId) {
                    val newFelt = !r.isFelt
                    val newCount = if (newFelt) r.feelCount + 1 else (r.feelCount - 1).coerceAtLeast(0)
                    r.copy(isFelt = newFelt, feelCount = newCount)
                } else r
            }
            state.copy(reels = updated)
        }
    }

    fun toggleKeepReel(reelId: String) {
        _uiState.update { state ->
            val updated = state.reels.map { r ->
                if (r.id == reelId) r.copy(isKept = !r.isKept) else r
            }
            state.copy(reels = updated)
        }
    }

    fun openReelThoughts(reel: ReelItem) {
        _uiState.update { it.copy(selectedReelForThoughts = reel) }
    }

    fun closeReelThoughts() {
        _uiState.update { it.copy(selectedReelForThoughts = null) }
    }

    fun addReelThought(reelId: String, text: String) {
        if (text.isBlank()) return
        val newComment = ThoughtComment(
            id = "rc_${UUID.randomUUID()}",
            author = "You",
            authorInitial = "Y",
            text = text.trim(),
            timeAgo = "Just now"
        )
        _uiState.update { state ->
            val updated = state.reels.map { r ->
                if (r.id == reelId) {
                    r.copy(thoughts = listOf(newComment) + r.thoughts)
                } else r
            }
            state.copy(
                reels = updated,
                selectedReelForThoughts = updated.find { it.id == reelId }
            )
        }
    }

    fun openCreateReelDialog() {
        _uiState.update { it.copy(isCreateReelDialogOpen = true) }
    }

    fun closeCreateReelDialog() {
        _uiState.update { it.copy(isCreateReelDialogOpen = false) }
    }

    fun createReel(
        caption: String,
        audioTrack: String,
        mood: MoodType,
        visualRes: Int,
        mediaUri: String? = null
    ) {
        if (caption.isBlank() && mediaUri == null) return
        val newReel = ReelItem(
            id = "reel_${UUID.randomUUID()}",
            authorName = "You",
            authorHandle = "@your_aura",
            authorInitial = "M",
            caption = caption.trim().ifBlank { "Motion frequency · Aura" },
            audioTrack = audioTrack.ifBlank { "Ambient Rain & Piano · 432Hz" },
            mood = mood,
            feelCount = 1,
            isFelt = true,
            isKept = true,
            isFollowingAuthor = true,
            drawableRes = visualRes,
            mediaUri = mediaUri,
            thoughts = emptyList()
        )
        _uiState.update { state ->
            state.copy(
                reels = listOf(newReel) + state.reels,
                isCreateReelDialogOpen = false,
                currentTab = AuraTab.REELS
            )
        }
    }

    // Moments
    fun toggleFeelMoment(momentId: String) {
        _uiState.update { state ->
            val updated = state.moments.map { m ->
                if (m.id == momentId) {
                    val newFelt = !m.isFelt
                    val newCount = if (newFelt) m.feelCount + 1 else (m.feelCount - 1).coerceAtLeast(0)
                    m.copy(isFelt = newFelt, feelCount = newCount)
                } else m
            }
            state.copy(moments = updated)
        }
    }

    fun toggleKeepMoment(momentId: String) {
        _uiState.update { state ->
            val updated = state.moments.map { m ->
                if (m.id == momentId) {
                    m.copy(isKept = !m.isKept)
                } else m
            }
            state.copy(moments = updated)
        }
    }

    fun addThought(momentId: String, thoughtText: String) {
        if (thoughtText.isBlank()) return
        val newComment = ThoughtComment(
            id = "tc_${UUID.randomUUID()}",
            author = "You",
            authorInitial = "Y",
            text = thoughtText.trim(),
            timeAgo = "Just now"
        )
        _uiState.update { state ->
            val updated = state.moments.map { m ->
                if (m.id == momentId) {
                    m.copy(thoughts = listOf(newComment) + m.thoughts)
                } else m
            }
            state.copy(moments = updated)
        }
    }

    fun openCreateMomentDialog() {
        _uiState.update { it.copy(isCreateMomentDialogOpen = true) }
    }

    fun closeCreateMomentDialog() {
        _uiState.update { it.copy(isCreateMomentDialogOpen = false) }
    }

    fun createMoment(
        text: String,
        mood: MoodType,
        customHeader: String? = null,
        drawableRes: Int? = null,
        mediaUri: String? = null,
        mediaType: String? = null,
        isVoiceNote: Boolean = false,
        voiceDurationSec: Int = 0
    ) {
        if (text.isBlank() && mediaUri == null && !isVoiceNote) return
        val header = customHeader ?: when (mood) {
            MoodType.RAINY -> "A MOMENT IN AMBIENT LIGHT"
            MoodType.SUNSET -> "SUNSET GLOW / 19:10"
            MoodType.MIDNIGHT -> "MIDNIGHT WHISPER / 01:20"
            MoodType.BLOOMING -> "BLOOMING CADENCE / 14:05"
            MoodType.SERENE -> "SERENE RESONANCE / 16:30"
        }
        val newMoment = Moment(
            id = "m_${UUID.randomUUID()}",
            authorName = "Your universe",
            authorHandle = "@your_aura",
            authorInitial = "M",
            timeAgo = "Just now",
            shareType = if (isVoiceNote) "Voice Note" else if (mediaType == "video") "Uploaded Video" else if (mediaType == "photo") "Captured Photo" else "shared softly",
            mood = mood,
            ambientHeader = header,
            quoteText = text.trim().ifBlank {
                if (isVoiceNote) "Voice frequency recorded (${voiceDurationSec}s) 🎙️"
                else if (mediaType == "video") "Video moment captured 🎬"
                else "Photo moment preserved 📷"
            },
            captionText = if (isVoiceNote) "Listening to ambient frequencies." else "A feeling captured in stillness.",
            feelCount = 1,
            isFelt = true,
            isKept = true,
            isFollowingAuthor = true,
            drawableRes = drawableRes,
            mediaUri = mediaUri,
            mediaType = mediaType,
            isVoiceNote = isVoiceNote,
            voiceDurationSec = voiceDurationSec,
            thoughts = emptyList()
        )
        _uiState.update { state ->
            state.copy(
                moments = listOf(newMoment) + state.moments,
                isCreateMomentDialogOpen = false,
                creationStreakDays = state.creationStreakDays + (if (!state.hasCheckedInToday) 1 else 0),
                hasCheckedInToday = true
            )
        }
    }

    // App Opening Animation Controls
    fun dismissOpeningAnimation() {
        _uiState.update { it.copy(isOpeningAnimationVisible = false) }
    }

    fun replayOpeningAnimation() {
        _uiState.update { it.copy(isOpeningAnimationVisible = true) }
    }

    // Compose Poetry Controls
    fun openComposePoetry() {
        _uiState.update { it.copy(isComposePoetryOpen = true) }
    }

    fun closeComposePoetry() {
        _uiState.update { it.copy(isComposePoetryOpen = false) }
    }

    fun publishPoem(
        title: String,
        poemText: String,
        mood: MoodType,
        fontOptionName: String,
        backdropRes: Int?
    ) {
        if (poemText.isBlank()) return
        val header = if (title.isNotBlank()) title.trim().uppercase() else "POETRY / ${mood.circleLabel.uppercase()}"
        val newMoment = Moment(
            id = "poem_${UUID.randomUUID()}",
            authorName = "Your universe",
            authorHandle = "@your_aura",
            authorInitial = "M",
            timeAgo = "Just now",
            shareType = "Poetry Composition",
            mood = mood,
            ambientHeader = header,
            quoteText = poemText.trim(),
            captionText = "Penned in quiet cinematic stillness · $fontOptionName",
            feelCount = 1,
            isFelt = true,
            isKept = true,
            isFollowingAuthor = true,
            drawableRes = backdropRes,
            fontOptionName = fontOptionName,
            isPoetry = true,
            thoughts = emptyList()
        )
        _uiState.update { state ->
            state.copy(
                moments = listOf(newMoment) + state.moments,
                isComposePoetryOpen = false,
                currentTab = AuraTab.FEED,
                creationStreakDays = state.creationStreakDays + (if (!state.hasCheckedInToday) 1 else 0),
                hasCheckedInToday = true
            )
        }
    }

    // Story Management
    fun openStory(storyId: String) {
        _uiState.update { state ->
            val updated = state.stories.map {
                if (it.id == storyId) it.copy(isViewed = true) else it
            }
            state.copy(stories = updated, activeStoryId = storyId)
        }
    }

    fun closeStory() {
        _uiState.update { it.copy(activeStoryId = null) }
    }

    fun nextStory() {
        val currentStories = _uiState.value.stories
        val currentId = _uiState.value.activeStoryId ?: return
        val currentIndex = currentStories.indexOfFirst { it.id == currentId }
        if (currentIndex != -1 && currentIndex + 1 < currentStories.size) {
            openStory(currentStories[currentIndex + 1].id)
        } else {
            closeStory()
        }
    }

    fun prevStory() {
        val currentStories = _uiState.value.stories
        val currentId = _uiState.value.activeStoryId ?: return
        val currentIndex = currentStories.indexOfFirst { it.id == currentId }
        if (currentIndex > 0) {
            openStory(currentStories[currentIndex - 1].id)
        }
    }

    // Discover Souls
    fun setDiscoverFilter(filter: String) {
        _uiState.update { it.copy(discoverFilter = filter) }
    }

    fun selectSoul(soulId: String?) {
        _uiState.update { it.copy(selectedSoulId = soulId) }
    }

    fun sendHello(soulId: String) {
        _uiState.update { state ->
            val targetSoul = state.souls.find { it.id == soulId }
            val updatedSouls = state.souls.map {
                if (it.id == soulId) it.copy(helloSent = true, isFollowing = true) else it
            }
            // Ensure thread exists in Inbox
            val existingThread = state.threads.find { it.personName.equals(targetSoul?.name, ignoreCase = true) }
            val updatedThreads = if (existingThread == null && targetSoul != null) {
                val newThread = InboxThread(
                    id = "th_${UUID.randomUUID()}",
                    personName = targetSoul.name,
                    personInitial = targetSoul.initial,
                    moodTitle = "${targetSoul.moodCategory.circleLabel.replaceFirstChar { it.uppercase() }} connection",
                    mood = targetSoul.moodCategory,
                    lastSnippet = "Hello sent! Shared frequencies connecting.",
                    unread = false,
                    messages = listOf(
                        ChatMessage(
                            id = "msg_${UUID.randomUUID()}",
                            senderName = "You",
                            text = "Hello! Connected with your soul frequency ✨",
                            time = "Just now",
                            isFromMe = true
                        )
                    )
                )
                listOf(newThread) + state.threads
            } else state.threads

            state.copy(souls = updatedSouls, threads = updatedThreads)
        }
    }

    // Studio
    fun updateStudioPrompt(prompt: String) {
        _uiState.update { it.copy(studioPrompt = prompt) }
    }

    fun updateStudioMood(mood: MoodType) {
        _uiState.update { it.copy(studioMood = mood) }
    }

    fun updateStudioVisual(res: Int?) {
        _uiState.update { it.copy(studioVisualRes = res) }
    }

    fun setRandomStudioSpark() {
        val prompts = listOf(
            "A quiet walk after a difficult day, and the sky slowly turning gold...",
            "Listening to nocturnal rain tapping the window glass with warm cinnamon tea.",
            "Finding an old handwritten letter in an forgotten coat pocket.",
            "The calm stillness when everyone in the city is asleep and the world belongs to night.",
            "Watching the twilight clouds drift apart to reveal the first evening star."
        )
        val selected = prompts.random()
        val moods = MoodType.values()
        val randomMood = moods[Random.nextInt(moods.size)]
        _uiState.update { it.copy(studioPrompt = selected, studioMood = randomMood) }
    }

    fun synthesizeMoment() {
        val prompt = _uiState.value.studioPrompt.ifBlank {
            "A quiet walk after a difficult day, and the sky slowly turning gold..."
        }
        val mood = _uiState.value.studioMood
        val visual = _uiState.value.studioVisualRes

        _uiState.update { it.copy(isSynthesizing = true) }

        viewModelScope.launch {
            delay(1200)
            val poeticHeaders = when (mood) {
                MoodType.RAINY -> "AMBIENT CASCADE / 20:18"
                MoodType.SUNSET -> "GOLDEN HORIZON / 18:55"
                MoodType.MIDNIGHT -> "ASTRAL QUIETUDE / 02:14"
                MoodType.BLOOMING -> "SPRING AWAKENING / 10:20"
                MoodType.SERENE -> "STILL WATERS / 16:45"
            }
            val synthesized = Moment(
                id = "m_syn_${UUID.randomUUID()}",
                authorName = "Your synthesized Aura",
                authorHandle = "@your_aura",
                authorInitial = "M",
                timeAgo = "Synthesized just now",
                shareType = "Aura Intelligence",
                mood = mood,
                ambientHeader = poeticHeaders,
                quoteText = prompt,
                captionText = "Echoed through the quiet frequencies of your soul.",
                feelCount = 1,
                isFelt = true,
                isKept = true,
                isFollowingAuthor = true,
                drawableRes = visual,
                thoughts = emptyList()
            )
            _uiState.update {
                it.copy(
                    isSynthesizing = false,
                    synthesizedMoment = synthesized
                )
            }
        }
    }

    fun publishSynthesizedMoment() {
        val synthesized = _uiState.value.synthesizedMoment ?: return
        _uiState.update { state ->
            state.copy(
                moments = listOf(synthesized) + state.moments,
                synthesizedMoment = null,
                studioPrompt = "",
                currentTab = AuraTab.FEED,
                creationStreakDays = state.creationStreakDays + (if (!state.hasCheckedInToday) 1 else 0),
                hasCheckedInToday = true
            )
        }
    }

    // Inbox
    fun openThread(threadId: String) {
        _uiState.update { state ->
            val updated = state.threads.map {
                if (it.id == threadId) it.copy(unread = false) else it
            }
            state.copy(threads = updated, activeThreadId = threadId)
        }
    }

    fun closeThread() {
        _uiState.update { it.copy(activeThreadId = null) }
    }

    fun sendChatMessage(threadId: String, text: String) {
        if (text.isBlank()) return
        val newMsg = ChatMessage(
            id = "msg_${UUID.randomUUID()}",
            senderName = "You",
            text = text.trim(),
            time = "Just now",
            isFromMe = true
        )
        _uiState.update { state ->
            val updatedThreads = state.threads.map { thread ->
                if (thread.id == threadId) {
                    thread.copy(
                        lastSnippet = text.trim(),
                        messages = thread.messages + newMsg
                    )
                } else thread
            }
            state.copy(threads = updatedThreads)
        }
    }

    // Streaks, Rituals & Garden
    fun checkInDaily() {
        _uiState.update { state ->
            if (!state.hasCheckedInToday) {
                state.copy(
                    creationStreakDays = state.creationStreakDays + 1,
                    hasCheckedInToday = true
                )
            } else {
                state
            }
        }
    }

    fun sendAuraToFriend(streakId: String) {
        _uiState.update { state ->
            val updated = state.bondStreaks.map { item ->
                if (item.id == streakId) {
                    item.copy(
                        sentToday = true,
                        statusText = "Aura sent today · waiting for their Aura"
                    )
                } else item
            }
            state.copy(bondStreaks = updated)
        }
    }

    fun simulateFriendReply() {
        _uiState.update { state ->
            val updated = state.bondStreaks.map { item ->
                if (item.sentToday) {
                    item.copy(
                        friendRepliedToday = true,
                        streakCount = item.streakCount + 1,
                        statusText = "Mutual Aura received! Streak +1 🔥"
                    )
                } else item
            }
            state.copy(bondStreaks = updated)
        }
    }

    fun resetDemoStreaks() {
        _uiState.update { state ->
            state.copy(bondStreaks = AuraSampleData.initialStreaks())
        }
    }

    fun createBond(friendName: String, ideaText: String) {
        if (ideaText.isBlank()) return
        val newBond = BondGardenItem(
            id = "bg_${UUID.randomUUID()}",
            friendName = friendName,
            ideaText = ideaText.trim(),
            createdAgo = "Just created",
            bloomingStep = 1
        )
        _uiState.update { state ->
            state.copy(bondGarden = listOf(newBond) + state.bondGarden)
        }
    }

    fun rotateAuraIdNow() {
        val part1 = "AU"
        val part2 = Random.nextInt(100, 999).toString()
        val part3 = Random.nextInt(100, 999).toString()
        val newId = "$part1-$part2-$part3"
        _uiState.update {
            it.copy(
                rotatingAuraId = newId,
                auraIdTimeRemaining = "24:00:00"
            )
        }
    }

    fun updateBio(newBio: String) {
        _uiState.update { it.copy(userBio = newBio) }
    }

    fun selectSymbol(symbol: AuraSymbol?) {
        _uiState.update { it.copy(selectedSymbol = symbol) }
    }

    fun toggleDemoAccountModal(show: Boolean) {
        _uiState.update { it.copy(isDemoAccountModalOpen = show) }
    }

    // Search
    fun openSearch() {
        _uiState.update { it.copy(isSearchOpen = true) }
    }

    fun closeSearch() {
        _uiState.update { it.copy(isSearchOpen = false) }
    }

    // Video & Voice Call
    fun startCall(soulName: String, soulHandle: String, soulInitial: String, type: com.example.model.CallType) {
        val newCall = com.example.model.ActiveCall(
            id = "call_${UUID.randomUUID()}",
            soulName = soulName,
            soulHandle = soulHandle,
            soulInitial = soulInitial,
            type = type,
            durationSeconds = 0,
            isMuted = false,
            isCameraOn = true,
            isSpeakerOn = false
        )
        _uiState.update { it.copy(activeCall = newCall) }
    }

    fun endCall() {
        _uiState.update { it.copy(activeCall = null) }
    }

    // Voice Notes in Chat
    fun sendVoiceNote(threadId: String, durationSec: Int) {
        val newMsg = ChatMessage(
            id = "msg_vn_${UUID.randomUUID()}",
            senderName = "You",
            text = "Voice note · $durationSec sec",
            time = "Just now",
            isFromMe = true,
            isVoiceNote = true,
            voiceDurationSec = durationSec
        )
        _uiState.update { state ->
            val updatedThreads = state.threads.map { thread ->
                if (thread.id == threadId) {
                    thread.copy(
                        lastSnippet = "🎤 Voice note (0:${String.format("%02d", durationSec)})",
                        messages = thread.messages + newMsg
                    )
                } else thread
            }
            state.copy(threads = updatedThreads)
        }
    }

    // Photo & Video Attachments in Chat
    fun sendMediaMessage(threadId: String, mediaUri: String, type: String) {
        val newMsg = ChatMessage(
            id = "msg_media_${UUID.randomUUID()}",
            senderName = "You",
            text = if (type == "video") "Uploaded video reel" else "Uploaded photo",
            time = "Just now",
            isFromMe = true,
            mediaUri = mediaUri,
            mediaType = type
        )
        _uiState.update { state ->
            val updatedThreads = state.threads.map { thread ->
                if (thread.id == threadId) {
                    thread.copy(
                        lastSnippet = if (type == "video") "🎬 Video" else "📷 Photo",
                        messages = thread.messages + newMsg
                    )
                } else thread
            }
            state.copy(threads = updatedThreads)
        }
    }

    // Auth & Sign In Flow
    fun openSignInDialog() {
        _uiState.update { it.copy(isSignInDialogOpen = true) }
    }

    fun closeSignInDialog() {
        _uiState.update { it.copy(isSignInDialogOpen = false) }
    }

    fun signIn(
        name: String,
        handle: String,
        email: String = "",
        archetype: String = "The Nocturnal Poet",
        mood: MoodType = MoodType.RAINY,
        avatarUri: String? = null
    ) {
        val cleanHandle = if (handle.startsWith("@")) handle else "@$handle"
        _uiState.update {
            it.copy(
                userName = name.ifBlank { "Moosa Zahoor" },
                userHandle = cleanHandle.ifBlank { "@moosa_aura" },
                userEmail = email.ifBlank { "moosa@aura.soul" },
                userPersonalityArchetype = archetype,
                userPrimaryMood = mood,
                userAvatarUri = avatarUri ?: it.userAvatarUri,
                isSignedIn = true,
                isSignInDialogOpen = false
            )
        }
    }

    fun signOut() {
        _uiState.update {
            it.copy(
                isSignedIn = false,
                isSignInDialogOpen = true
            )
        }
    }

    // Edit Profile Flow
    fun openEditProfileDialog() {
        _uiState.update { it.copy(isEditProfileDialogOpen = true) }
    }

    fun closeEditProfileDialog() {
        _uiState.update { it.copy(isEditProfileDialogOpen = false) }
    }

    fun updateProfile(
        name: String,
        handle: String,
        bio: String,
        avatarUri: String?,
        archetype: String,
        aesthetic: String,
        tags: List<String>,
        primaryMood: MoodType
    ) {
        val cleanHandle = if (handle.startsWith("@")) handle else "@$handle"
        _uiState.update {
            it.copy(
                userName = name.trim().ifBlank { it.userName },
                userHandle = cleanHandle.trim().ifBlank { it.userHandle },
                userBio = bio.trim().ifBlank { it.userBio },
                userAvatarUri = avatarUri,
                userPersonalityArchetype = archetype,
                userPersonalityAesthetic = aesthetic.trim().ifBlank { it.userPersonalityAesthetic },
                userPersonalityTags = tags.ifEmpty { it.userPersonalityTags },
                userPrimaryMood = primaryMood,
                isEditProfileDialogOpen = false
            )
        }
    }

    fun updateAvatar(uri: String?) {
        _uiState.update { it.copy(userAvatarUri = uri) }
    }
}
