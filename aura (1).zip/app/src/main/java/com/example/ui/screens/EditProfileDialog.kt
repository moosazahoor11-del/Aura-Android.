package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.InputChip
import androidx.compose.material3.InputChipDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.model.MoodType
import com.example.ui.theme.AuraBackground
import com.example.ui.theme.AuraBorder
import com.example.ui.theme.AuraBorderLight
import com.example.ui.theme.AuraEmerald
import com.example.ui.theme.AuraGold
import com.example.ui.theme.AuraLavender
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraSurfaceHighlight
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletDark
import com.example.ui.theme.AuraVioletPrimary
import com.example.ui.theme.AuraVioletSecondary

val PRESET_SOUL_TAGS = listOf(
    "Poetry",
    "Nocturnal Rain",
    "Ambient 432Hz",
    "Late Thoughts",
    "Quiet Art",
    "Philosophy",
    "Star Gazing",
    "Lofi Beats",
    "Solitude",
    "Kindred Minds",
    "Analog Film",
    "Deep Walks"
)

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EditProfileDialog(
    isOpen: Boolean,
    currentName: String,
    currentHandle: String,
    currentBio: String,
    currentAvatarUri: String?,
    currentArchetype: String,
    currentAesthetic: String,
    currentTags: List<String>,
    currentMood: MoodType,
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        handle: String,
        bio: String,
        avatarUri: String?,
        archetype: String,
        aesthetic: String,
        tags: List<String>,
        primaryMood: MoodType
    ) -> Unit
) {
    if (!isOpen) return

    var name by remember(currentName) { mutableStateOf(currentName) }
    var handle by remember(currentHandle) { mutableStateOf(currentHandle) }
    var bio by remember(currentBio) { mutableStateOf(currentBio) }
    var avatarUri by remember(currentAvatarUri) { mutableStateOf(currentAvatarUri) }
    var archetype by remember(currentArchetype) { mutableStateOf(currentArchetype) }
    var aesthetic by remember(currentAesthetic) { mutableStateOf(currentAesthetic) }
    var tags by remember(currentTags) { mutableStateOf(currentTags.toMutableList()) }
    var primaryMood by remember(currentMood) { mutableStateOf(currentMood) }

    var newTagInput by remember { mutableStateOf("") }

    // Zero-permission Android Photo Picker for Profile DP
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            avatarUri = uri.toString()
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(AuraBackground)
                .imePadding(),
            color = AuraBackground
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                // Top Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(AuraSurfaceElevated)
                            .testTag("edit_profile_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = AuraTextPrimary
                        )
                    }

                    Text(
                        text = "EDIT SOUL PROFILE",
                        color = AuraTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )

                    Button(
                        onClick = {
                            onSave(
                                name,
                                handle,
                                bio,
                                avatarUri,
                                archetype,
                                aesthetic,
                                tags,
                                primaryMood
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AuraVioletSecondary),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("edit_profile_save_button")
                    ) {
                        Text("Save ✦", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentPadding = PaddingValues(bottom = 30.dp)
                ) {
                    // 1. Profile DP / Picture Section
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = AuraSurface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, AuraBorderLight, RoundedCornerShape(20.dp))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "PROFILE PICTURE (DP)",
                                    color = AuraLavender,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                // Avatar Preview with Camera Badge
                                Box(
                                    modifier = Modifier
                                        .size(100.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.radialGradient(
                                                listOf(AuraVioletSecondary, AuraVioletDark)
                                            )
                                        )
                                        .border(2.5.dp, AuraVioletPrimary, CircleShape)
                                        .clickable {
                                            photoPickerLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        }
                                        .testTag("edit_profile_dp_bubble"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (!avatarUri.isNullOrBlank()) {
                                        AsyncImage(
                                            model = avatarUri,
                                            contentDescription = "Profile Picture",
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    } else {
                                        Text(
                                            text = if (name.isNotBlank()) name.take(1).uppercase() else "A",
                                            color = Color.White,
                                            fontSize = 38.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    // Floating Camera Icon
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(AuraVioletPrimary)
                                            .border(1.5.dp, AuraBackground, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CameraAlt,
                                            contentDescription = "Change DP",
                                            tint = Color.White,
                                            modifier = Modifier.size(17.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            photoPickerLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                        shape = RoundedCornerShape(20.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AuraVioletPrimary),
                                        border = ButtonDefaults.outlinedButtonBorder.copy(
                                            brush = Brush.horizontalGradient(listOf(AuraVioletSecondary, AuraVioletPrimary))
                                        ),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                                        modifier = Modifier.testTag("edit_profile_change_photo_btn")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AddPhotoAlternate,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Choose from Gallery 📷", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }

                                    if (avatarUri != null) {
                                        TextButton(
                                            onClick = { avatarUri = null },
                                            modifier = Modifier.testTag("edit_profile_remove_dp_btn")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = null,
                                                tint = AuraTextMuted,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Reset DP", color = AuraTextMuted, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))
                    }

                    // 2. Name & Handle
                    item {
                        Text(
                            text = "SOUL IDENTITY",
                            color = AuraLavender,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Display Name") },
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = AuraVioletPrimary)
                            },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AuraVioletPrimary,
                                unfocusedBorderColor = AuraBorderLight,
                                focusedTextColor = AuraTextPrimary,
                                unfocusedTextColor = AuraTextPrimary,
                                focusedLabelColor = AuraVioletPrimary,
                                unfocusedLabelColor = AuraTextMuted,
                                focusedContainerColor = AuraSurfaceElevated,
                                unfocusedContainerColor = AuraSurface
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("edit_name_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = handle,
                            onValueChange = {
                                val clean = it.replace(" ", "_")
                                handle = if (clean.startsWith("@")) clean else "@$clean"
                            },
                            label = { Text("Soul Handle") },
                            placeholder = { Text("@moosa_aura") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AuraVioletPrimary,
                                unfocusedBorderColor = AuraBorderLight,
                                focusedTextColor = AuraTextPrimary,
                                unfocusedTextColor = AuraTextPrimary,
                                focusedLabelColor = AuraVioletPrimary,
                                unfocusedLabelColor = AuraTextMuted,
                                focusedContainerColor = AuraSurfaceElevated,
                                unfocusedContainerColor = AuraSurface
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("edit_handle_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = bio,
                            onValueChange = { bio = it },
                            label = { Text("Soul Bio & Philosophy") },
                            placeholder = { Text("Collecting moments, not numbers...") },
                            singleLine = false,
                            maxLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AuraVioletPrimary,
                                unfocusedBorderColor = AuraBorderLight,
                                focusedTextColor = AuraTextPrimary,
                                unfocusedTextColor = AuraTextPrimary,
                                focusedLabelColor = AuraVioletPrimary,
                                unfocusedLabelColor = AuraTextMuted,
                                focusedContainerColor = AuraSurfaceElevated,
                                unfocusedContainerColor = AuraSurface
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("edit_bio_input")
                        )

                        Spacer(modifier = Modifier.height(24.dp))
                    }

                    // 3. Personality Archetype Details
                    item {
                        Text(
                            text = "PERSONALITY ARCHETYPE DETAILS",
                            color = AuraLavender,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            SOUL_ARCHETYPES.forEach { item ->
                                val isSelected = archetype == item
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { archetype = item },
                                    label = {
                                        Text(
                                            item,
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    leadingIcon = if (isSelected) {
                                        {
                                            Icon(
                                                Icons.Default.Check,
                                                contentDescription = null,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    } else null,
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AuraVioletSecondary,
                                        selectedLabelColor = Color.White,
                                        containerColor = AuraSurfaceElevated,
                                        labelColor = AuraTextSecondary
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        borderColor = if (isSelected) AuraVioletPrimary else AuraBorderLight,
                                        enabled = true,
                                        selected = isSelected
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))
                    }

                    // 4. Primary Mood Frequency
                    item {
                        Text(
                            text = "PRIMARY MOOD FREQUENCY",
                            color = AuraLavender,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            MoodType.values().forEach { mood ->
                                val isSelected = primaryMood == mood
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(
                                            if (isSelected) AuraVioletSecondary else AuraSurfaceElevated
                                        )
                                        .border(
                                            1.dp,
                                            if (isSelected) AuraGold else AuraBorderLight,
                                            RoundedCornerShape(20.dp)
                                        )
                                        .clickable { primaryMood = mood }
                                        .padding(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    Text(
                                        text = "${mood.label} ${mood.symbol}",
                                        color = if (isSelected) Color.White else AuraTextSecondary,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))
                    }

                    // 5. Personality Aesthetic Description
                    item {
                        Text(
                            text = "PERSONALITY AESTHETIC",
                            color = AuraLavender,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = aesthetic,
                            onValueChange = { aesthetic = it },
                            label = { Text("Aesthetic & Vibe Description") },
                            placeholder = { Text("e.g. Midnight rain, warm cinnamon tea & lofi frequencies") },
                            singleLine = false,
                            maxLines = 3,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AuraVioletPrimary,
                                unfocusedBorderColor = AuraBorderLight,
                                focusedTextColor = AuraTextPrimary,
                                unfocusedTextColor = AuraTextPrimary,
                                focusedLabelColor = AuraVioletPrimary,
                                unfocusedLabelColor = AuraTextMuted,
                                focusedContainerColor = AuraSurfaceElevated,
                                unfocusedContainerColor = AuraSurface
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("edit_aesthetic_input")
                        )

                        Spacer(modifier = Modifier.height(20.dp))
                    }

                    // 6. Soul Resonance & Creative Interest Tags
                    item {
                        Text(
                            text = "SOUL RESONANCE & INTEREST TAGS",
                            color = AuraLavender,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Active tags
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            tags.forEach { tag ->
                                InputChip(
                                    selected = true,
                                    onClick = {
                                        tags.remove(tag)
                                        tags = tags.toMutableList()
                                    },
                                    label = { Text("#$tag", fontSize = 12.sp) },
                                    trailingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Remove tag",
                                            modifier = Modifier.size(14.dp)
                                        )
                                    },
                                    colors = InputChipDefaults.inputChipColors(
                                        selectedContainerColor = AuraVioletDark,
                                        selectedLabelColor = AuraLavender
                                    ),
                                    border = InputChipDefaults.inputChipBorder(
                                        borderColor = AuraVioletPrimary,
                                        enabled = true,
                                        selected = true
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Suggested Tags to add
                        Text(
                            text = "Suggested tags to tap & add:",
                            color = AuraTextMuted,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            PRESET_SOUL_TAGS.filterNot { tags.contains(it) }.forEach { suggestion ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(AuraSurfaceElevated)
                                        .border(1.dp, AuraBorderLight, RoundedCornerShape(12.dp))
                                        .clickable {
                                            tags.add(suggestion)
                                            tags = tags.toMutableList()
                                        }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text("+ $suggestion", color = AuraTextSecondary, fontSize = 11.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Add Custom Tag
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = newTagInput,
                                onValueChange = { newTagInput = it },
                                placeholder = { Text("Add custom tag (e.g. Ambient Jazz)") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AuraVioletPrimary,
                                    unfocusedBorderColor = AuraBorderLight,
                                    focusedTextColor = AuraTextPrimary,
                                    unfocusedTextColor = AuraTextPrimary,
                                    focusedContainerColor = AuraSurfaceElevated,
                                    unfocusedContainerColor = AuraSurface
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp)
                                    .testTag("new_tag_input")
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            Button(
                                onClick = {
                                    val cleaned = newTagInput.trim().removePrefix("#")
                                    if (cleaned.isNotBlank() && !tags.contains(cleaned)) {
                                        tags.add(cleaned)
                                        tags = tags.toMutableList()
                                        newTagInput = ""
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AuraVioletSecondary),
                                modifier = Modifier
                                    .height(52.dp)
                                    .testTag("add_tag_button")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Add Tag")
                            }
                        }

                        Spacer(modifier = Modifier.height(28.dp))

                        // Final Save Button
                        Button(
                            onClick = {
                                onSave(
                                    name,
                                    handle,
                                    bio,
                                    avatarUri,
                                    archetype,
                                    aesthetic,
                                    tags,
                                    primaryMood
                                )
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AuraVioletSecondary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("edit_profile_final_save_btn")
                        ) {
                            Text(
                                "Save Soul Profile ✦",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
