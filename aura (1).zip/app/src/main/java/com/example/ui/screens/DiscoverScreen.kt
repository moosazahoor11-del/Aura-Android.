package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WavingHand
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MoodType
import com.example.model.SoulProfile
import com.example.ui.theme.AuraBackground
import com.example.ui.theme.AuraBorder
import com.example.ui.theme.AuraBorderLight
import com.example.ui.theme.AuraCardGradientEnd
import com.example.ui.theme.AuraCardGradientStart
import com.example.ui.theme.AuraLavender
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraSurfaceHighlight
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletDark
import com.example.ui.theme.AuraVioletPrimary
import com.example.ui.theme.AuraVioletSecondary

@Composable
fun DiscoverScreen(
    souls: List<SoulProfile>,
    selectedFilter: String,
    onFilterChange: (String) -> Unit,
    onSendHello: (String) -> Unit,
    onSelectSoul: (String) -> Unit,
    onToggleFollowSoul: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val filterTabs = listOf("For you", "Rainy", "Midnight", "Hopeful")

    val filteredSouls = souls.filter { soul ->
        when (selectedFilter) {
            "Rainy" -> soul.moodCategory == MoodType.RAINY
            "Midnight" -> soul.moodCategory == MoodType.MIDNIGHT
            "Hopeful" -> soul.moodCategory == MoodType.SUNSET || soul.moodCategory == MoodType.BLOOMING
            else -> true
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AuraBackground)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp)
        ) {
            // Header
            item {
                Text(
                    text = "FIND YOUR FREQUENCY",
                    color = AuraTextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Discover Souls",
                        color = AuraTextPrimary,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "✨", fontSize = 22.sp)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Find people through shared moods and creative interests - not popularity scores. These are sample profiles for the prototype.",
                    color = AuraTextMuted,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Filter tabs
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(filterTabs) { tab ->
                        val isSelected = tab == selectedFilter
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (isSelected) AuraVioletSecondary else AuraSurfaceElevated,
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = Brush.linearGradient(
                                    listOf(
                                        if (isSelected) AuraVioletPrimary else AuraBorder,
                                        if (isSelected) AuraVioletDark else AuraBorder
                                    )
                                )
                            ),
                            modifier = Modifier
                                .clickable { onFilterChange(tab) }
                                .testTag("filter_tab_$tab")
                        ) {
                            Text(
                                text = tab,
                                color = if (isSelected) Color.White else AuraTextSecondary,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }

            // Soul Cards Grid / List
            items(filteredSouls) { soul ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = AuraSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 14.dp)
                        .border(1.dp, AuraBorder, RoundedCornerShape(16.dp))
                        .testTag("soul_card_${soul.id}")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.linearGradient(
                                                listOf(
                                                    soul.moodCategory.accentColor.copy(alpha = 0.5f),
                                                    AuraSurfaceHighlight
                                                )
                                            )
                                        )
                                        .border(1.5.dp, soul.moodCategory.accentColor, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = soul.moodCategory.symbolEmoji,
                                        fontSize = 20.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = soul.name,
                                            color = AuraTextPrimary,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = soul.moodCategory.symbolEmoji,
                                            fontSize = 14.sp
                                        )
                                    }
                                    Text(
                                        text = soul.frequencyVibe,
                                        color = AuraVioletPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = soul.bio,
                            color = AuraTextSecondary,
                            fontSize = 13.sp,
                            lineHeight = 19.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Action Buttons: Follow + Say Hello
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Follow / Following Button
                            OutlinedButton(
                                onClick = { onToggleFollowSoul(soul.id) },
                                shape = RoundedCornerShape(20.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (soul.isFollowing) AuraSurfaceHighlight else Color.Transparent,
                                    contentColor = if (soul.isFollowing) AuraLavender else AuraVioletPrimary
                                ),
                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                    brush = Brush.horizontalGradient(
                                        listOf(
                                            if (soul.isFollowing) AuraBorderLight else AuraVioletSecondary,
                                            if (soul.isFollowing) AuraBorderLight else AuraVioletPrimary
                                        )
                                    )
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("follow_soul_button_${soul.id}")
                            ) {
                                Text(
                                    text = if (soul.isFollowing) "Following ✓" else "+ Follow",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            // Say Hello Button
                            if (soul.helloSent) {
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = AuraSurfaceHighlight,
                                    border = ButtonDefaults.outlinedButtonBorder.copy(
                                        brush = Brush.horizontalGradient(listOf(AuraBorderLight, AuraBorderLight))
                                    ),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 10.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = AuraLavender,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Hello sent",
                                            color = AuraLavender,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            } else {
                                Button(
                                    onClick = { onSendHello(soul.id) },
                                    shape = RoundedCornerShape(20.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = AuraVioletSecondary,
                                        contentColor = Color.White
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("say_hello_button_${soul.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.WavingHand,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Say hello",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Footer disclaimer from prototype video
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Aura compatibility scores are intentionally not shown. Real discovery will require profiles, privacy controls, and moderation.",
                    color = AuraTextMuted,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 16.sp,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "AURA · CONNECTED SOUL · A concept prototype",
                    color = AuraTextMuted.copy(alpha = 0.6f),
                    fontSize = 10.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
