package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Moment
import com.example.model.MoodType
import com.example.ui.components.MomentCard
import com.example.ui.theme.AuraBackground
import com.example.ui.theme.AuraBorder
import com.example.ui.theme.AuraBorderLight
import com.example.ui.theme.AuraCardGradientEnd
import com.example.ui.theme.AuraCardGradientStart
import com.example.ui.theme.AuraLavender
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraSurfaceHighlight
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletDark
import com.example.ui.theme.AuraVioletPrimary
import com.example.ui.theme.AuraVioletSecondary

@Composable
fun StudioScreen(
    prompt: String,
    onPromptChange: (String) -> Unit,
    selectedMood: MoodType,
    onMoodChange: (MoodType) -> Unit,
    selectedVisualRes: Int?,
    onVisualChange: (Int?) -> Unit,
    isSynthesizing: Boolean,
    synthesizedMoment: Moment?,
    onSynthesize: () -> Unit,
    onPublish: () -> Unit,
    onRandomSpark: () -> Unit,
    modifier: Modifier = Modifier
) {
    var moodMenuExpanded by remember { mutableStateOf(false) }
    var visualMenuExpanded by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AuraBackground)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp)
        ) {
            // Header matching video
            item {
                Text(
                    text = "AURA INTELLIGENCE · STUDIO",
                    color = AuraVioletPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Every soul has a story",
                    color = AuraTextPrimary,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "A cinematic space for feelings, poetry, and the moments that stay with you. Synthesize your raw thought into an ambient moment card.",
                    color = AuraTextMuted,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(20.dp))
            }

            // Input card
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = AuraSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AuraBorder, RoundedCornerShape(18.dp))
                        .testTag("studio_input_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "What are you feeling?",
                                color = AuraTextSecondary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            TextButton(
                                onClick = onRandomSpark,
                                colors = ButtonDefaults.textButtonColors(contentColor = AuraVioletPrimary),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("Inspiration spark ✨", fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = prompt,
                            onValueChange = onPromptChange,
                            placeholder = {
                                Text(
                                    text = "e.g. A quiet walk after a difficult day, and the sky slowly turning gold...",
                                    color = AuraTextMuted,
                                    fontSize = 14.sp,
                                    lineHeight = 20.sp
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .testTag("studio_prompt_input"),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = AuraTextPrimary,
                                unfocusedTextColor = AuraTextPrimary,
                                focusedContainerColor = AuraSurfaceElevated,
                                unfocusedContainerColor = AuraSurfaceElevated,
                                focusedBorderColor = AuraVioletPrimary,
                                unfocusedBorderColor = AuraBorder
                            )
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Visual Attachment selector
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(AuraSurfaceElevated)
                                .clickable { visualMenuExpanded = true }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AddPhotoAlternate,
                                    contentDescription = null,
                                    tint = AuraVioletPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = if (selectedVisualRes != null) "Atmospheric visual attached ✓" else "Add an atmospheric visual (optional)",
                                    color = if (selectedVisualRes != null) AuraLavender else AuraTextMuted,
                                    fontSize = 13.sp
                                )
                            }
                            if (selectedVisualRes != null) {
                                Text(
                                    text = "Change",
                                    color = AuraVioletPrimary,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = visualMenuExpanded,
                            onDismissRequest = { visualMenuExpanded = false },
                            modifier = Modifier.background(AuraSurfaceElevated)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Rainy Cafe & Warm Window Tea ☕", color = AuraTextPrimary) },
                                onClick = {
                                    onVisualChange(R.drawable.ambient_rainy_glow)
                                    visualMenuExpanded = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Sunset Twilight City Horizon 🌅", color = AuraTextPrimary) },
                                onClick = {
                                    onVisualChange(R.drawable.ambient_sunset_glow)
                                    visualMenuExpanded = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Pure Cosmic Gradient (No photo) ✨", color = AuraTextPrimary) },
                                onClick = {
                                    onVisualChange(null)
                                    visualMenuExpanded = false
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Choose the feeling dropdown
                        Text(
                            text = "Choose the feeling",
                            color = AuraTextMuted,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = { moodMenuExpanded = true },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("studio_mood_dropdown"),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = AuraSurfaceElevated,
                                    contentColor = AuraLavender
                                ),
                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                    brush = Brush.horizontalGradient(listOf(AuraBorder, AuraBorderLight))
                                )
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${selectedMood.symbolEmoji}  ${selectedMood.title}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = "▾",
                                        fontSize = 14.sp,
                                        color = AuraTextMuted
                                    )
                                }
                            }

                            DropdownMenu(
                                expanded = moodMenuExpanded,
                                onDismissRequest = { moodMenuExpanded = false },
                                modifier = Modifier
                                    .fillMaxWidth(0.85f)
                                    .background(AuraSurfaceElevated)
                            ) {
                                MoodType.values().forEach { mood ->
                                    DropdownMenuItem(
                                        text = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(mood.symbolEmoji, fontSize = 16.sp)
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(mood.title, color = AuraTextPrimary, fontSize = 13.sp)
                                            }
                                        },
                                        onClick = {
                                            onMoodChange(mood)
                                            moodMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Your words stay in this local prototype.",
                                color = AuraTextMuted,
                                fontSize = 11.sp
                            )

                            Button(
                                onClick = onSynthesize,
                                enabled = !isSynthesizing,
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AuraVioletSecondary,
                                    contentColor = Color.White
                                ),
                                modifier = Modifier.testTag("synthesize_moment_button")
                            ) {
                                if (isSynthesizing) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Synthesizing...", fontSize = 13.sp)
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Synthesize moment",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }

            // Synthesized Result Preview
            if (synthesizedMoment != null) {
                item {
                    Text(
                        text = "SYNTHESIZED AURA MOMENT",
                        color = AuraVioletPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    MomentCard(
                        moment = synthesizedMoment,
                        onFeelClick = { },
                        onKeepClick = { },
                        onThoughtClick = { },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = onPublish,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AuraVioletDark,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("publish_synthesized_button")
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Publish to Feed & Circle",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}
