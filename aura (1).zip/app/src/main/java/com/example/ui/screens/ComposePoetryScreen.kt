package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.FormatAlignRight
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.MoodType
import com.example.ui.theme.AuraBackground
import com.example.ui.theme.AuraBorder
import com.example.ui.theme.AuraBorderLight
import com.example.ui.theme.AuraGold
import com.example.ui.theme.AuraLavender
import com.example.ui.theme.AuraRose
import com.example.ui.theme.AuraSkyBlue
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraSurfaceHighlight
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletDark
import com.example.ui.theme.AuraVioletPrimary
import com.example.ui.theme.AuraVioletSecondary
import com.example.ui.theme.CaveatFontFamily
import com.example.ui.theme.CinzelFontFamily
import com.example.ui.theme.CormorantGaramondFontFamily
import com.example.ui.theme.PlayfairDisplayFontFamily
import com.example.ui.theme.PoetryFontOption

enum class PoetryBackdrop(
    val title: String,
    val visualRes: Int?,
    val gradientColors: List<Color>?
) {
    VOID("Midnight Void", null, null),
    VELVET(
        "Velvet Indigo",
        null,
        listOf(Color(0xFF190C2C), Color(0xFF0B0713))
    ),
    RAIN("Rainy Window", R.drawable.ambient_rainy_glow, null),
    SUNSET("Golden Dusk", R.drawable.ambient_sunset_glow, null),
    FOG("Ethereal Fog", R.drawable.reel_midnight_fog, null)
}

enum class PoetryColorTone(
    val title: String,
    val color: Color
) {
    CELESTIAL("White", Color.White),
    GOLDEN("Golden", AuraGold),
    LAVENDER("Lavender", AuraLavender),
    ROSE("Rose Quartz", AuraRose),
    MOONLIGHT("Silver Mist", Color(0xFFD6D0E4))
}

@Composable
fun ComposePoetryScreen(
    onClose: () -> Unit,
    onPublish: (title: String, poemText: String, mood: MoodType, fontName: String, backdropRes: Int?) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onClose() }

    var poemTitle by remember { mutableStateOf("") }
    var poemBody by remember {
        mutableStateOf(
            "Some days, even the rain\nfeels like a soft place to land.\nA quiet breath, a fleeting light,\nand the universe remembers how to heal."
        )
    }

    var selectedFont by remember { mutableStateOf(PoetryFontOption.PLAYFAIR) }
    var selectedFontSize by remember { mutableFloatStateOf(20f) }
    var selectedLetterSpacing by remember { mutableFloatStateOf(1f) }
    var selectedLineHeightFactor by remember { mutableFloatStateOf(1.6f) }
    var selectedAlign by remember { mutableStateOf(TextAlign.Center) }
    var selectedMood by remember { mutableStateOf(MoodType.RAINY) }
    var selectedBackdrop by remember { mutableStateOf(PoetryBackdrop.VOID) }
    var selectedColorTone by remember { mutableStateOf(PoetryColorTone.CELESTIAL) }

    var isSanctuaryPreviewMode by remember { mutableStateOf(false) }
    var activeToolPanel by remember { mutableStateOf("font") } // "font", "style", "backdrop", "none"
    var showSparkNotice by remember { mutableStateOf(false) }
    var soundscapeActive by remember { mutableStateOf(true) }

    val infiniteTransition = rememberInfiniteTransition(label = "poetry_ambient")
    val ambientPulse by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ambient_pulse"
    )

    // Calculated metrics
    val lineCount = remember(poemBody) { poemBody.lines().size }
    val wordCount = remember(poemBody) {
        poemBody.trim().split("\\s+".toRegex()).count { it.isNotBlank() }
    }

    val poeticSparks = listOf(
        "And in the stillness of the midnight hour,\nwe hear the things words could never hold.",
        "The light returns in small, quiet ways first—\nnot like a storm, but like morning mist on velvet leaves.",
        "Between the thought and the memory,\nlies a sanctuary carved from breath and starlight.",
        "Raindrops trace ancient paths upon the glass,\neach one carrying a secret the sky could no longer keep.",
        "You do not have to be unbreakable.\nEven the constellations are made of empty space and longing."
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AuraBackground)
            .testTag("compose_poetry_screen")
    ) {
        // Atmospheric Backdrop Layer
        if (selectedBackdrop.visualRes != null) {
            Image(
                painter = painterResource(id = selectedBackdrop.visualRes!!),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Heavy cinematic dark scrim for distraction-free writing
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xDD0B0713),
                                Color(0xF50B0713),
                                Color(0xFF0B0713)
                            )
                        )
                    )
            )
        } else if (selectedBackdrop.gradientColors != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = selectedBackdrop.gradientColors!!
                        )
                    )
            )
        }

        // Ambient mystical glow behind poem
        Box(
            modifier = Modifier
                .size(360.dp)
                .scale(ambientPulse)
                .align(Alignment.Center)
                .background(
                    Brush.radialGradient(
                        listOf(
                            selectedMood.accentColor.copy(alpha = 0.12f),
                            Color.Transparent
                        )
                    )
                )
        )

        // Main Layout Column
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .imePadding()
        ) {
            // Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(AuraSurfaceElevated)
                            .testTag("poetry_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = AuraLavender,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = if (isSanctuaryPreviewMode) "Sanctuary View" else "Compose Poetry",
                            color = AuraTextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = CinzelFontFamily
                        )
                        Text(
                            text = "${selectedFont.displayName} · $lineCount lines · $wordCount words",
                            color = AuraTextMuted,
                            fontSize = 10.sp
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Preview / Sanctuary Mode Toggle
                    IconButton(
                        onClick = { isSanctuaryPreviewMode = !isSanctuaryPreviewMode },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (isSanctuaryPreviewMode) AuraVioletSecondary else AuraSurfaceElevated)
                            .testTag("poetry_preview_mode_toggle")
                    ) {
                        Icon(
                            imageVector = if (isSanctuaryPreviewMode) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = "Toggle Preview Mode",
                            tint = if (isSanctuaryPreviewMode) Color.White else AuraLavender,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Publish Button
                    Button(
                        onClick = {
                            if (poemBody.isNotBlank()) {
                                onPublish(
                                    poemTitle.ifBlank { "POETRY / ${selectedMood.circleLabel.uppercase()}" },
                                    poemBody,
                                    selectedMood,
                                    selectedFont.name,
                                    selectedBackdrop.visualRes
                                )
                            }
                        },
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AuraVioletSecondary),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("publish_poetry_button")
                    ) {
                        Text(
                            text = "Publish",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Interactive Canvas & Writing Scroll View
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    Spacer(modifier = Modifier.height(10.dp))

                    // Mood selector pills (Hidden in preview mode)
                    AnimatedVisibility(visible = !isSanctuaryPreviewMode) {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 14.dp)
                        ) {
                            items(MoodType.values()) { mood ->
                                val isSelected = selectedMood == mood
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = if (isSelected) mood.accentColor.copy(alpha = 0.2f) else AuraSurfaceElevated,
                                    border = ButtonDefaults.outlinedButtonBorder.copy(
                                        brush = Brush.horizontalGradient(
                                            listOf(
                                                if (isSelected) mood.accentColor else AuraBorder,
                                                if (isSelected) mood.accentColor.copy(alpha = 0.5f) else AuraBorder
                                            )
                                        )
                                    ),
                                    modifier = Modifier.clickable { selectedMood = mood }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(mood.symbolEmoji, fontSize = 12.sp)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = mood.title,
                                            color = if (isSelected) mood.accentColor else AuraTextSecondary,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // The Parchment Canvas Card
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = AuraSurface.copy(alpha = if (selectedBackdrop == PoetryBackdrop.VOID) 0.65f else 0.82f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                brush = Brush.verticalGradient(
                                    listOf(
                                        selectedMood.accentColor.copy(alpha = 0.4f),
                                        AuraBorderLight,
                                        AuraBorder
                                    )
                                ),
                                shape = RoundedCornerShape(20.dp)
                            )
                            .testTag("poetry_canvas_card")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 22.dp, vertical = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Header badge
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(selectedMood.accentColor)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "AURA SANCTUARY · ${selectedMood.circleLabel.uppercase()}",
                                    color = selectedMood.accentColor,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 2.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Poetry Title Input
                            OutlinedTextField(
                                value = poemTitle,
                                onValueChange = { poemTitle = it },
                                placeholder = {
                                    Text(
                                        text = "Poem title or whisper...",
                                        color = AuraTextMuted,
                                        fontSize = 16.sp,
                                        fontFamily = selectedFont.fontFamily,
                                        textAlign = selectedAlign,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                },
                                textStyle = TextStyle(
                                    color = selectedColorTone.color,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = selectedFont.fontFamily,
                                    letterSpacing = 1.5.sp,
                                    textAlign = selectedAlign
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("poetry_title_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color.Transparent,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent
                                ),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Delicate Divider
                            Box(
                                modifier = Modifier
                                    .width(60.dp)
                                    .height(1.dp)
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(
                                                Color.Transparent,
                                                selectedMood.accentColor.copy(alpha = 0.6f),
                                                Color.Transparent
                                            )
                                        )
                                    )
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Poetry Body Input
                            OutlinedTextField(
                                value = poemBody,
                                onValueChange = { poemBody = it },
                                placeholder = {
                                    Text(
                                        text = "Let feelings flow into words...\nIn this quiet space,\nevery verse breathes.",
                                        color = AuraTextMuted,
                                        fontSize = selectedFontSize.sp,
                                        fontFamily = selectedFont.fontFamily,
                                        textAlign = selectedAlign,
                                        lineHeight = (selectedFontSize * selectedLineHeightFactor).sp,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                },
                                textStyle = TextStyle(
                                    color = selectedColorTone.color,
                                    fontSize = selectedFontSize.sp,
                                    fontFamily = selectedFont.fontFamily,
                                    letterSpacing = selectedLetterSpacing.sp,
                                    lineHeight = (selectedFontSize * selectedLineHeightFactor).sp,
                                    textAlign = selectedAlign
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("poetry_body_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color.Transparent,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent
                                )
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            // Canvas Footer Sign-off
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (soundscapeActive) {
                                        Icon(
                                            imageVector = Icons.Default.GraphicEq,
                                            contentDescription = null,
                                            tint = AuraVioletPrimary,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Ambient rain · 432Hz",
                                            color = AuraTextMuted,
                                            fontSize = 10.sp
                                        )
                                    }
                                }

                                Text(
                                    text = "— Soul M",
                                    color = AuraLavender,
                                    fontFamily = selectedFont.fontFamily,
                                    fontSize = 12.sp,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Poetic Muse Spark Card
                    AnimatedVisibility(visible = !isSanctuaryPreviewMode) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = AuraSurfaceElevated,
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = Brush.horizontalGradient(listOf(AuraBorder, AuraBorderLight))
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val randomSpark = poeticSparks.random()
                                    poemBody = if (poemBody.isBlank()) randomSpark else "$poemBody\n\n$randomSpark"
                                    showSparkNotice = true
                                }
                                .testTag("poetry_spark_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = AuraGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Spark a poetic verse from the cosmos ✨",
                                    color = AuraLavender,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                }
            }

            // Bottom Styling & Customization Toolbar (Hidden in Sanctuary View)
            AnimatedVisibility(visible = !isSanctuaryPreviewMode) {
                Surface(
                    color = AuraSurface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = 0.8.dp,
                            color = AuraBorder,
                            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
                        )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        // Category Tabs: Fonts | Size & Layout | Atmosphere & Tone
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ToolTabItem(
                                title = "Font Style",
                                icon = Icons.Default.TextFields,
                                isSelected = activeToolPanel == "font",
                                onClick = { activeToolPanel = "font" }
                            )

                            ToolTabItem(
                                title = "Typography",
                                icon = Icons.Default.FormatAlignCenter,
                                isSelected = activeToolPanel == "style",
                                onClick = { activeToolPanel = "style" }
                            )

                            ToolTabItem(
                                title = "Atmosphere",
                                icon = Icons.Default.Palette,
                                isSelected = activeToolPanel == "backdrop",
                                onClick = { activeToolPanel = "backdrop" }
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Panel Content
                        when (activeToolPanel) {
                            "font" -> {
                                // Font Selector Pills
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    items(PoetryFontOption.values()) { fontOption ->
                                        val isSelected = selectedFont == fontOption
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = if (isSelected) AuraVioletSecondary else AuraSurfaceElevated,
                                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                                brush = Brush.horizontalGradient(
                                                    listOf(
                                                        if (isSelected) AuraVioletPrimary else AuraBorder,
                                                        if (isSelected) AuraVioletDark else AuraBorder
                                                    )
                                                )
                                            ),
                                            modifier = Modifier
                                                .clickable { selectedFont = fontOption }
                                                .testTag("font_option_${fontOption.name.lowercase()}")
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally
                                            ) {
                                                Text(
                                                    text = fontOption.displayName,
                                                    color = if (isSelected) Color.White else AuraTextPrimary,
                                                    fontFamily = fontOption.fontFamily,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = fontOption.subtitle,
                                                    color = if (isSelected) Color.White.copy(alpha = 0.7f) else AuraTextMuted,
                                                    fontSize = 9.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            "style" -> {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    // Alignment & Size row
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Alignment Toggles
                                        Row(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(AuraSurfaceElevated)
                                                .padding(2.dp)
                                        ) {
                                            listOf(
                                                TextAlign.Left to Icons.Default.FormatAlignLeft,
                                                TextAlign.Center to Icons.Default.FormatAlignCenter,
                                                TextAlign.Right to Icons.Default.FormatAlignRight
                                            ).forEach { (align, icon) ->
                                                val isSelected = selectedAlign == align
                                                Box(
                                                    modifier = Modifier
                                                        .size(32.dp)
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .background(if (isSelected) AuraVioletSecondary else Color.Transparent)
                                                        .clickable { selectedAlign = align },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = icon,
                                                        contentDescription = null,
                                                        tint = if (isSelected) Color.White else AuraTextMuted,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                            }
                                        }

                                        // Font Size Presets
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            listOf(16f to "16", 20f to "20", 24f to "24", 28f to "28").forEach { (sz, label) ->
                                                val isSelected = selectedFontSize == sz
                                                Box(
                                                    modifier = Modifier
                                                        .size(32.dp)
                                                        .clip(CircleShape)
                                                        .background(if (isSelected) AuraVioletSecondary else AuraSurfaceElevated)
                                                        .clickable { selectedFontSize = sz },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = label,
                                                        color = if (isSelected) Color.White else AuraTextSecondary,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    // Spacing controls: Letter spacing & Line height
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Letter Spacing", color = AuraTextMuted, fontSize = 11.sp)
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            listOf(0f to "Tight", 1.5f to "Poetic", 4f to "Astral").forEach { (spVal, label) ->
                                                val isSelected = selectedLetterSpacing == spVal
                                                Surface(
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = if (isSelected) AuraVioletSecondary else AuraSurfaceElevated,
                                                    modifier = Modifier.clickable { selectedLetterSpacing = spVal }
                                                ) {
                                                    Text(
                                                        text = label,
                                                        color = if (isSelected) Color.White else AuraTextMuted,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Medium,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            "backdrop" -> {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    // Text Color Tone Row
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Ink Tone", color = AuraTextMuted, fontSize = 11.sp)
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            PoetryColorTone.values().forEach { tone ->
                                                val isSelected = selectedColorTone == tone
                                                Box(
                                                    modifier = Modifier
                                                        .size(26.dp)
                                                        .clip(CircleShape)
                                                        .background(tone.color)
                                                        .border(
                                                            width = if (isSelected) 2.dp else 1.dp,
                                                            color = if (isSelected) AuraVioletPrimary else AuraBorder,
                                                            shape = CircleShape
                                                        )
                                                        .clickable { selectedColorTone = tone },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    if (isSelected) {
                                                        Box(
                                                            modifier = Modifier
                                                                .size(8.dp)
                                                                .clip(CircleShape)
                                                                .background(AuraBackground)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // Backdrop Wallpapers
                                    LazyRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        items(PoetryBackdrop.values()) { backdrop ->
                                            val isSelected = selectedBackdrop == backdrop
                                            Surface(
                                                shape = RoundedCornerShape(10.dp),
                                                color = if (isSelected) AuraVioletSecondary else AuraSurfaceElevated,
                                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                                    brush = Brush.horizontalGradient(
                                                        listOf(
                                                            if (isSelected) AuraVioletPrimary else AuraBorder,
                                                            if (isSelected) AuraVioletDark else AuraBorder
                                                        )
                                                    )
                                                ),
                                                modifier = Modifier.clickable { selectedBackdrop = backdrop }
                                            ) {
                                                Text(
                                                    text = backdrop.title,
                                                    color = if (isSelected) Color.White else AuraTextSecondary,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolTabItem(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) AuraVioletSecondary.copy(alpha = 0.25f) else Color.Transparent,
        border = if (isSelected) ButtonDefaults.outlinedButtonBorder.copy(
            brush = Brush.horizontalGradient(listOf(AuraVioletPrimary, AuraVioletSecondary))
        ) else null,
        modifier = Modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) AuraVioletPrimary else AuraTextMuted,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                color = if (isSelected) AuraTextPrimary else AuraTextMuted,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}
