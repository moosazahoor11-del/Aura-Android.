package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Moment
import com.example.model.ReelItem
import com.example.model.SoulProfile
import com.example.ui.theme.AuraBackground
import com.example.ui.theme.AuraBorder
import com.example.ui.theme.AuraBorderLight
import com.example.ui.theme.AuraLavender
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraSurfaceHighlight
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletDark
import com.example.ui.theme.AuraVioletPrimary
import com.example.ui.theme.AuraVioletSecondary

@Composable
fun SearchScreen(
    souls: List<SoulProfile>,
    moments: List<Moment>,
    reels: List<ReelItem>,
    onClose: () -> Unit,
    onSelectSoul: (SoulProfile) -> Unit,
    onSelectMoment: (Moment) -> Unit,
    onSelectReel: (ReelItem) -> Unit,
    onFollowSoul: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") } // "All", "Souls", "Moments", "Reels", "Audio"

    val categories = listOf("All", "Souls", "Moments", "Reels", "Audio")
    val trendingTags = listOf("#rain", "#midnight", "#goldenhour", "#lofi", "#poetry", "#tea")

    val matchingSouls = remember(searchQuery, souls) {
        if (searchQuery.isBlank()) emptyList()
        else souls.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                    it.bio.contains(searchQuery, ignoreCase = true) ||
                    it.handle.contains(searchQuery, ignoreCase = true)
        }
    }

    val matchingMoments = remember(searchQuery, moments) {
        if (searchQuery.isBlank()) emptyList()
        else moments.filter {
            it.quoteText.contains(searchQuery, ignoreCase = true) ||
                    it.captionText.contains(searchQuery, ignoreCase = true) ||
                    it.authorName.contains(searchQuery, ignoreCase = true) ||
                    it.ambientHeader.contains(searchQuery, ignoreCase = true)
        }
    }

    val matchingReels = remember(searchQuery, reels) {
        if (searchQuery.isBlank()) emptyList()
        else reels.filter {
            it.caption.contains(searchQuery, ignoreCase = true) ||
                    it.audioTrack.contains(searchQuery, ignoreCase = true) ||
                    it.authorName.contains(searchQuery, ignoreCase = true)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AuraBackground)
            .statusBarsPadding()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("search_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Search Input Top Bar
            Surface(
                color = AuraSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, AuraBorder, RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onClose,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = AuraTextPrimary
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search feelings, souls, poetry, audio...", color = AuraTextMuted, fontSize = 13.sp) },
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = null, tint = AuraVioletPrimary, modifier = Modifier.size(18.dp))
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear", tint = AuraTextMuted, modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(22.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("search_input_field"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = AuraTextPrimary,
                                unfocusedTextColor = AuraTextPrimary,
                                focusedContainerColor = AuraSurfaceElevated,
                                unfocusedContainerColor = AuraSurfaceElevated,
                                focusedBorderColor = AuraVioletPrimary,
                                unfocusedBorderColor = AuraBorder
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Categories pills
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(categories) { category ->
                            val isSelected = category == selectedCategory
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isSelected) AuraVioletSecondary else AuraSurfaceElevated,
                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                    brush = Brush.horizontalGradient(
                                        listOf(
                                            if (isSelected) AuraVioletPrimary else AuraBorder,
                                            if (isSelected) AuraVioletDark else AuraBorder
                                        )
                                    )
                                ),
                                modifier = Modifier
                                    .clickable { selectedCategory = category }
                                    .testTag("search_filter_$category")
                            ) {
                                Text(
                                    text = category,
                                    color = if (isSelected) Color.White else AuraTextSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Results / Empty / Trending Tags
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                if (searchQuery.isBlank()) {
                    // Trending Tags and Suggested Searches
                    item {
                        Text(
                            text = "TRENDING FREQUENCIES",
                            color = AuraVioletPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            trendingTags.take(3).forEach { tag ->
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = AuraSurfaceElevated,
                                    border = ButtonDefaults.outlinedButtonBorder.copy(
                                        brush = Brush.horizontalGradient(listOf(AuraBorder, AuraBorderLight))
                                    ),
                                    modifier = Modifier
                                        .clickable { searchQuery = tag.removePrefix("#") }
                                        .padding(vertical = 4.dp)
                                ) {
                                    Text(
                                        text = tag,
                                        color = AuraLavender,
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            trendingTags.drop(3).take(3).forEach { tag ->
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = AuraSurfaceElevated,
                                    border = ButtonDefaults.outlinedButtonBorder.copy(
                                        brush = Brush.horizontalGradient(listOf(AuraBorder, AuraBorderLight))
                                    ),
                                    modifier = Modifier
                                        .clickable { searchQuery = tag.removePrefix("#") }
                                        .padding(vertical = 4.dp)
                                ) {
                                    Text(
                                        text = tag,
                                        color = AuraLavender,
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(24.dp))
                    }

                    item {
                        Text(
                            text = "DISCOVERED SOULS",
                            color = AuraTextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    items(souls) { soul ->
                        SoulSearchItem(
                            soul = soul,
                            onClick = { onSelectSoul(soul) },
                            onFollow = { onFollowSoul(soul.name) }
                        )
                    }
                } else {
                    // Display Matching Results
                    val showSouls = selectedCategory in listOf("All", "Souls")
                    val showMoments = selectedCategory in listOf("All", "Moments")
                    val showReels = selectedCategory in listOf("All", "Reels", "Audio")

                    if (showSouls && matchingSouls.isNotEmpty()) {
                        item {
                            Text(
                                text = "SOULS (${matchingSouls.size})",
                                color = AuraVioletPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                        items(matchingSouls) { soul ->
                            SoulSearchItem(
                                soul = soul,
                                onClick = { onSelectSoul(soul) },
                                onFollow = { onFollowSoul(soul.name) }
                            )
                        }
                        item { Spacer(modifier = Modifier.height(16.dp)) }
                    }

                    if (showMoments && matchingMoments.isNotEmpty()) {
                        item {
                            Text(
                                text = "MOMENTS (${matchingMoments.size})",
                                color = AuraVioletPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                        items(matchingMoments) { moment ->
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = AuraSurface),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 10.dp)
                                    .border(1.dp, AuraBorder, RoundedCornerShape(14.dp))
                                    .clickable { onSelectMoment(moment) }
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(moment.authorName, color = AuraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(moment.mood.circleLabel, color = moment.mood.accentColor, fontSize = 11.sp)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "\"${moment.quoteText}\"",
                                        color = AuraLavender,
                                        fontSize = 13.sp,
                                        fontFamily = FontFamily.Serif,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                        item { Spacer(modifier = Modifier.height(16.dp)) }
                    }

                    if (showReels && matchingReels.isNotEmpty()) {
                        item {
                            Text(
                                text = "REELS & AUDIO (${matchingReels.size})",
                                color = AuraVioletPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                        items(matchingReels) { reel ->
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = AuraSurface),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 10.dp)
                                    .border(1.dp, AuraBorder, RoundedCornerShape(14.dp))
                                    .clickable { onSelectReel(reel) }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(AuraSurfaceHighlight),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, tint = AuraVioletPrimary)
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(reel.authorName, color = AuraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(reel.caption, color = AuraTextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.MusicNote, contentDescription = null, tint = AuraTextMuted, modifier = Modifier.size(11.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(reel.audioTrack, color = AuraTextMuted, fontSize = 10.sp, maxLines = 1)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (matchingSouls.isEmpty() && matchingMoments.isEmpty() && matchingReels.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No quiet echoes found matching \"$searchQuery\". Try searching for \"rain\", \"midnight\", or \"Zainab\".",
                                    color = AuraTextMuted,
                                    fontSize = 13.sp,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SoulSearchItem(
    soul: SoulProfile,
    onClick: () -> Unit,
    onFollow: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AuraSurface),
        modifier = modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .border(0.8.dp, AuraBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(listOf(AuraVioletSecondary, AuraVioletDark))
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(soul.initial, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(soul.name, color = AuraTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(soul.bio, color = AuraTextMuted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (soul.isFollowing) AuraSurfaceElevated else AuraVioletSecondary,
                modifier = Modifier
                    .clickable { onFollow() }
                    .padding(4.dp)
            ) {
                Text(
                    text = if (soul.isFollowing) "Following" else "Follow",
                    color = if (soul.isFollowing) AuraLavender else Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }
    }
}
