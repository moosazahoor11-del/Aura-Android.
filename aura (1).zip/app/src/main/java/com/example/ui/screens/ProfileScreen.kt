package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.AuraSampleData
import com.example.model.AuraSymbol
import com.example.model.BondGardenItem
import com.example.model.BondStreakItem
import com.example.model.MoodType
import com.example.ui.components.SymbolDetailDialog
import com.example.ui.theme.AuraBackground
import com.example.ui.theme.AuraBorder
import com.example.ui.theme.AuraBorderLight
import com.example.ui.theme.AuraCardGradientEnd
import com.example.ui.theme.AuraCardGradientStart
import com.example.ui.theme.AuraEmerald
import com.example.ui.theme.AuraGold
import com.example.ui.theme.AuraLavender
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraSurfaceHighlight
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletDark
import com.example.ui.theme.AuraVioletPrimary
import com.example.ui.theme.AuraVioletSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    userName: String,
    userBio: String,
    momentsCount: Int,
    keptCount: Int,
    followingCount: Int,
    followersCount: Int,
    onOpenFollowing: () -> Unit,
    onOpenFollowers: () -> Unit,
    creationStreakDays: Int,
    hasCheckedInToday: Boolean,
    onCheckIn: () -> Unit,
    bondStreaks: List<BondStreakItem>,
    onSendAura: (String) -> Unit,
    onSimulateReply: () -> Unit,
    onResetStreaks: () -> Unit,
    bondGarden: List<BondGardenItem>,
    onCreateBond: (friendName: String, idea: String) -> Unit,
    rotatingAuraId: String,
    auraIdTimeRemaining: String,
    onRotateAuraId: () -> Unit,
    onUpdateBio: (String) -> Unit,
    selectedSymbol: AuraSymbol?,
    onSelectSymbol: (AuraSymbol?) -> Unit,
    onReplayOpeningAnimation: () -> Unit = {},
    onOpenComposePoetry: () -> Unit = {},
    userHandle: String = "@moosa_aura",
    userAvatarUri: String? = null,
    userPersonalityArchetype: String = "The Nocturnal Poet",
    userPersonalityAesthetic: String = "Midnight rain, warm cinnamon tea & lofi frequencies",
    userPersonalityTags: List<String> = listOf("Poetry", "Nocturnal Rain", "Ambient 432Hz", "Late Thoughts", "Quiet Art"),
    userPrimaryMood: MoodType = MoodType.RAINY,
    isSignedIn: Boolean = true,
    onOpenEditProfile: () -> Unit = {},
    onOpenSignIn: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var editableBio by remember(userBio) { mutableStateOf(userBio) }
    var selectedFriendForBond by remember { mutableStateOf("Zainab") }
    var bondIdeaInput by remember { mutableStateOf("") }
    var friendDropdownExpanded by remember { mutableStateOf(false) }
    var previewSavedToast by remember { mutableStateOf(false) }

    val friendsList = listOf("Zainab", "Ayan", "Hira", "Ray")
    val symbols = remember { AuraSampleData.symbols() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AuraBackground)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp)
        ) {
            // Profile Header
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Avatar DP with camera icon and glow ring
                    Box(
                        modifier = Modifier
                            .size(92.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(AuraVioletSecondary, AuraVioletDark)
                                )
                            )
                            .border(2.5.dp, AuraVioletPrimary, CircleShape)
                            .clickable { onOpenEditProfile() }
                            .testTag("profile_avatar_dp"),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!userAvatarUri.isNullOrBlank()) {
                            AsyncImage(
                                model = userAvatarUri,
                                contentDescription = "Profile Picture",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Text(
                                text = if (userName.isNotBlank()) userName.take(1).uppercase() else "A",
                                color = Color.White,
                                fontSize = 36.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Floating camera badge
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(AuraVioletPrimary)
                                .border(1.5.dp, AuraBackground, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "Edit Profile DP",
                                tint = Color.White,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = userName,
                        color = AuraTextPrimary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = userHandle,
                            color = AuraLavender,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(text = "·", color = AuraTextMuted)
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = AuraSurfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(1.dp, AuraBorderLight)
                        ) {
                            Text(
                                text = "✦ $userPersonalityArchetype",
                                color = AuraGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "\"$userBio\"",
                        color = AuraTextSecondary,
                        fontSize = 13.sp,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 20.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Personality Aesthetic Banner
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = AuraSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, AuraBorderLight),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🌌", fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "Aesthetic Vibe · ${userPrimaryMood.label} ${userPrimaryMood.symbol}",
                                        color = AuraLavender,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = userPersonalityAesthetic,
                                        color = AuraTextPrimary,
                                        fontSize = 12.sp,
                                        maxLines = 2
                                    )
                                }
                            }
                            IconButton(
                                onClick = onOpenEditProfile,
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit Vibe",
                                    tint = AuraVioletPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Personality Tags Cloud
                    FlowRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        userPersonalityTags.forEach { tag ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = AuraSurfaceHighlight,
                                border = androidx.compose.foundation.BorderStroke(1.dp, AuraBorderLight)
                            ) {
                                Text(
                                    text = "#$tag",
                                    color = AuraTextSecondary,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Action Buttons Row: Edit Profile & Switch Soul
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onOpenEditProfile,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AuraVioletSecondary),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                                .testTag("profile_edit_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = null,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Edit Profile & DP",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        OutlinedButton(
                            onClick = onOpenSignIn,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AuraLavender),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = Brush.horizontalGradient(listOf(AuraBorderLight, AuraVioletSecondary))
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                                .testTag("profile_switch_soul_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = AuraGold,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Sign In / Soul",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Stat Counters Rows
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatCard(
                            title = "$momentsCount",
                            subtitle = "Moments",
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "$keptCount",
                            subtitle = "Kept",
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "$followingCount",
                            subtitle = "Following",
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onOpenFollowing() }
                                .testTag("profile_stat_following")
                        )
                        StatCard(
                            title = "$followersCount",
                            subtitle = "Followers",
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onOpenFollowers() }
                                .testTag("profile_stat_followers")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }

            // 1. Creation Streak (Gentle Daily Ritual)
            item {
                SectionCard(
                    title = "Creation Streak 💜",
                    badge = "GENTLE DAILY RITUAL",
                    testTag = "creation_streak_card"
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(AuraSurfaceHighlight),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "✨",
                                    fontSize = 22.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "$creationStreakDays days",
                                    color = AuraTextPrimary,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (hasCheckedInToday) "Checked in today · ritual maintained" else "One gentle check-in can start today's ritual.",
                                    color = AuraTextMuted,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Button(
                            onClick = onCheckIn,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (hasCheckedInToday) AuraSurfaceHighlight else AuraVioletSecondary,
                                contentColor = if (hasCheckedInToday) AuraLavender else Color.White
                            ),
                            modifier = Modifier.testTag("check_in_button")
                        ) {
                            if (hasCheckedInToday) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Done", fontSize = 12.sp)
                            } else {
                                Text("Check in", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Local demo: check-in progress is stored in this app session.",
                        color = AuraTextMuted,
                        fontSize = 11.sp
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))
            }

            // 2. Bond Streaks (Like Snapstreaks)
            item {
                SectionCard(
                    title = "Bond Streaks 💜",
                    badge = "LIKE SNAPSTREAKS",
                    testTag = "bond_streaks_card"
                ) {
                    Text(
                        text = "Keep a creative streak with a friend by both sharing an Aura (a photo, poem, voice note, or mood moment) within the same daily window. It grows through mutual participation - not just opening the app.",
                        color = AuraTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    bondStreaks.forEach { streak ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(AuraSurfaceElevated)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(AuraSurfaceHighlight),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = streak.friendInitial,
                                        color = AuraLavender,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = streak.friendName,
                                            color = AuraTextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "🔥 ${streak.streakCount}",
                                            color = AuraGold,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Text(
                                        text = streak.statusText,
                                        color = AuraTextMuted,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Button(
                                onClick = { onSendAura(streak.id) },
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (streak.sentToday) AuraSurfaceHighlight else AuraVioletSecondary,
                                    contentColor = if (streak.sentToday) AuraLavender else Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.testTag("send_aura_${streak.id}")
                            ) {
                                Text(
                                    text = if (streak.sentToday) "Aura sent ✓" else "Send Aura",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onSimulateReply,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("simulate_friend_reply_button"),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AuraLavender),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = Brush.horizontalGradient(listOf(AuraBorder, AuraVioletSecondary))
                            )
                        ) {
                            Text("Simulate friend reply", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = onResetStreaks,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AuraTextMuted),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = Brush.horizontalGradient(listOf(AuraBorder, AuraBorder))
                            )
                        ) {
                            Text("Reset", fontSize = 11.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))
            }

            // 3. Bond Garden 💜 (CREATE TO CONNECT)
            item {
                SectionCard(
                    title = "Bond Garden 💜",
                    badge = "CREATE TO CONNECT",
                    testTag = "bond_garden_card"
                ) {
                    Text(
                        text = "Create a shared creative prompt with someone to grow a bond through moments, poetry, photos, or playlists - not popularity scores.",
                        color = AuraTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Choose a demo connection",
                        color = AuraTextMuted,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { friendDropdownExpanded = true },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = AuraSurfaceElevated,
                                contentColor = AuraTextPrimary
                            )
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(selectedFriendForBond, fontSize = 13.sp)
                                Text("▾", color = AuraTextMuted)
                            }
                        }

                        DropdownMenu(
                            expanded = friendDropdownExpanded,
                            onDismissRequest = { friendDropdownExpanded = false },
                            modifier = Modifier.background(AuraSurfaceElevated)
                        ) {
                            friendsList.forEach { friend ->
                                DropdownMenuItem(
                                    text = { Text(friend, color = AuraTextPrimary) },
                                    onClick = {
                                        selectedFriendForBond = friend
                                        friendDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Shared creation idea",
                        color = AuraTextMuted,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    OutlinedTextField(
                        value = bondIdeaInput,
                        onValueChange = { bondIdeaInput = it },
                        placeholder = {
                            Text("A rainy-night poem, a photo pair...", color = AuraTextMuted, fontSize = 13.sp)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("bond_idea_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = AuraTextPrimary,
                            unfocusedTextColor = AuraTextPrimary,
                            focusedContainerColor = AuraSurfaceElevated,
                            unfocusedContainerColor = AuraSurfaceElevated,
                            focusedBorderColor = AuraVioletPrimary,
                            unfocusedBorderColor = AuraBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            if (bondIdeaInput.isNotBlank()) {
                                onCreateBond(selectedFriendForBond, bondIdeaInput)
                                bondIdeaInput = ""
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AuraVioletSecondary,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("create_bond_button")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Create a bond", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    if (bondGarden.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Blooming Bonds",
                            color = AuraLavender,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        bondGarden.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(AuraSurfaceElevated)
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🌸", fontSize = 18.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "With ${item.friendName} · Step ${item.bloomingStep}",
                                        color = AuraTextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = item.ideaText,
                                        color = AuraTextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))
            }

            // 4. Rotating Aura ID (24-Hour Demo)
            item {
                SectionCard(
                    title = "Your rotating Aura ID",
                    badge = "24-HOUR DEMO",
                    testTag = "rotating_aura_id_card"
                ) {
                    Text(
                        text = "Your public discovery ID changes every 24 hours to make long-term tracking harder. Your real account identity may stay stable behind the scenes.",
                        color = AuraTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(AuraSurfaceElevated)
                            .border(1.dp, AuraBorder, RoundedCornerShape(14.dp))
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = rotatingAuraId,
                                color = AuraTextPrimary,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 2.sp
                            )
                            Text(
                                text = "Changes in $auraIdTimeRemaining",
                                color = AuraTextMuted,
                                fontSize = 11.sp
                            )
                        }

                        Button(
                            onClick = onRotateAuraId,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AuraSurfaceHighlight,
                                contentColor = AuraLavender
                            ),
                            modifier = Modifier.testTag("rotate_aura_id_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Rotate now · demo", fontSize = 11.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))
            }

            // 5. AURA Signature Symbols (Visual Language)
            item {
                SectionCard(
                    title = "AURA Signature Symbols",
                    badge = "YOUR VISUAL LANGUAGE",
                    testTag = "signature_symbols_card"
                ) {
                    Text(
                        text = "A small family of original-feeling symbols for moods, bonds, identity, creativity, and private moments. Tap one to preview its meaning.",
                        color = AuraTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Grid of 6 symbols
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            symbols.take(3).forEach { sym ->
                                SymbolGridItem(
                                    symbol = sym,
                                    onClick = { onSelectSymbol(sym) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            symbols.drop(3).take(3).forEach { sym ->
                                SymbolGridItem(
                                    symbol = sym,
                                    onClick = { onSelectSymbol(sym) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))
            }

            // 6. Profile Settings (Local Demo)
            item {
                SectionCard(
                    title = "Profile settings",
                    badge = "LOCAL DEMO",
                    testTag = "profile_settings_card"
                ) {
                    Text(
                        text = "Your bio",
                        color = AuraTextMuted,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = editableBio,
                        onValueChange = { editableBio = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(90.dp)
                            .testTag("profile_bio_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = AuraTextPrimary,
                            unfocusedTextColor = AuraTextPrimary,
                            focusedContainerColor = AuraSurfaceElevated,
                            unfocusedContainerColor = AuraSurfaceElevated,
                            focusedBorderColor = AuraVioletPrimary,
                            unfocusedBorderColor = AuraBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                onUpdateBio(editableBio)
                                previewSavedToast = true
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AuraVioletSecondary,
                                contentColor = Color.White
                            ),
                            modifier = Modifier.testTag("save_profile_button")
                        ) {
                            Text(
                                text = if (previewSavedToast) "Saved ✓" else "Save profile preview",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        TextButton(
                            onClick = {
                                editableBio = "Collecting moments, not numbers. Floating in ambient quietude."
                                onUpdateBio(editableBio)
                            },
                            colors = ButtonDefaults.textButtonColors(contentColor = AuraTextMuted)
                        ) {
                            Text("Reset demo profile", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Profile edits stay in this app session. Persistent profiles need a database and real authentication.",
                        color = AuraTextMuted,
                        fontSize = 11.sp
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))
            }

            // 6. Cinematic Sanctuary & App Opening Animation
            item {
                SectionCard(
                    title = "Cinematic Sanctuary & Poetry",
                    badge = "EXPERIENCES",
                    testTag = "cinematic_experiences_card"
                ) {
                    Text(
                        text = "Immerse in soul-stirring animations and craft verses on the minimalist poetic canvas.",
                        color = AuraTextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Replay Opening Animation
                        OutlinedButton(
                            onClick = onReplayOpeningAnimation,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = AuraSurfaceElevated,
                                contentColor = AuraLavender
                            ),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = Brush.horizontalGradient(listOf(AuraBorder, AuraVioletSecondary))
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("replay_opening_button")
                        ) {
                            Text("Replay Opening ✨", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        }

                        // Write Poetry
                        Button(
                            onClick = onOpenComposePoetry,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AuraVioletSecondary,
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("profile_write_poetry_button")
                        ) {
                            Text("Compose Poetry ✍", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }

            // Footer
            item {
                Text(
                    text = "AURA · CONNECTED SOUL · A concept prototype",
                    color = AuraTextMuted.copy(alpha = 0.6f),
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(24.dp))
            }
        }

        // Symbol preview dialog
        if (selectedSymbol != null) {
            SymbolDetailDialog(
                symbol = selectedSymbol,
                onDismiss = { onSelectSymbol(null) }
            )
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AuraSurface),
        modifier = modifier.border(0.8.dp, AuraBorder, RoundedCornerShape(14.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                color = AuraTextPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = AuraTextMuted,
                fontSize = 10.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun SectionCard(
    title: String,
    badge: String,
    testTag: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = AuraSurface),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, AuraBorder, RoundedCornerShape(18.dp))
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = AuraTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif
                )
                Text(
                    text = badge,
                    color = AuraTextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun SymbolGridItem(
    symbol: AuraSymbol,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = AuraSurfaceElevated,
        border = ButtonDefaults.outlinedButtonBorder.copy(
            brush = Brush.horizontalGradient(listOf(AuraBorder, AuraBorderLight))
        ),
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(symbol.symbolChar, fontSize = 20.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = symbol.title,
                color = AuraTextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = symbol.subtitle,
                color = AuraTextMuted,
                fontSize = 9.sp,
                maxLines = 1,
                textAlign = TextAlign.Center
            )
        }
    }
}
